﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace yjkSystem_ver1
{
    public partial class OnlySelect : Form
    {
        public Label Info_Count { get; set; }           // 검색건수
        public Label Info_Message { get; set; }         // 하단 메세지

        public string button_status { get; set; }  // 버튼 상태 저장
        public OnlySelect()
        {
            InitializeComponent();
        }

        private void OnlySelect_Load(object sender, EventArgs e)
        {
            button_status = utility.SetFuncBtn(utility.buttons, "0");
            utility.ComBoxItemSet(search_pos, SQL.SQL_Unit.Select_POS);
            utility.conn = utility.SetOracleConnection();
            OracleDataAdapter da = new OracleDataAdapter(SQL.SQL_Img.SelectSQL, utility.conn);
            utility.img_table = new DataTable();
            da.Fill(utility.img_table);
        }
        #region 조회버튼 기능
        public void Search_Btn()
        {
            try
            {
                utility.conn = utility.SetOracleConnection();
                utility.cmd = utility.conn.CreateCommand();
                utility.cmd.CommandText = SQL.SQL_Bas.SelectSQL;
                utility.cmd.BindByName = true;
                utility.cmd.Parameters.Add("bas_empno", OracleDbType.Varchar2).Value = search_code.Text + "%";
                utility.cmd.Parameters.Add("bas_name", OracleDbType.Varchar2).Value = "%" + search_name.Text + "%";
                utility.cmd.Parameters.Add("bas_pos", OracleDbType.Varchar2).Value = "%" + utility.GetCode(search_pos.Text) + "%";
                utility.cmd.Parameters.Add("bas_dept", OracleDbType.Varchar2).Value = "%" + utility.GetCode(search_dept.Text) + "%";
                OracleDataAdapter da = new OracleDataAdapter(utility.cmd);
                utility.ds.Clear();
                da.Fill(utility.ds, "TAB");
                utility.table = utility.ds.Tables[0];
                dataGridView1.DataSource = utility.table;

                utility.cmd.ExecuteNonQuery();
                int i = 0;
                while (i < dataGridView1.Rows.Count)
                {
                    dataGridView1.Rows[i].Cells["bas_resno"].Value = dataGridView1.Rows[i].Cells["bas_resno"].Value.ToString().Substring(0, 7) + "-" + dataGridView1.Rows[i].Cells["bas_resno"].Value.ToString().Substring(6);
                    i++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            //--DB Handling(End)-------------------------------------
            /*var recCnt = dataGridView1.RowCount;
            Info_Count.Text = recCnt.ToString();
            if (recCnt == 0)
            {
                Info_Message.Text = "조건을 만족하는 자료가 없습니다.";
                return;
            }
            Info_Message.Text = "자료가 정상적으로 조회 되었습니다.";*/

        }
        #endregion

        private void sd_btn1_Click(object sender, EventArgs e)
        {
            String SelectSQL = SQL.SQL_Dept.Select_DPT;
            Control ctl = sender as Control;

            // a위치== out string result 변수는 호출될때 값이 없음
            if (ShowSearchCDWindow(SelectSQL, "프로그램코드", out string result) == true)
            {
                search_dept.Text = result;
            }
        }
        public bool ShowSearchCDWindow(string sql, string caption, out string result)
        {
            //여기서의 result 변수는 결국 a위치에서 만든 변수를 가르킴
            string search = search_dept.Text;
            var win = new Search_Dept(sql, search);
            win.Text = caption;
            if (win.ShowDialog() == DialogResult.OK)
            {

                //form2에 getResult 를 호출

                //
                result = win.GetResult;

                //결국 결과를 받아서 result 변수에 저장했기 때문에 a위치의 변수값이 설정되는것과
                //같은 현상
                win.Dispose();
                return true;
            }
            else
            {
                result = "";
                win.Dispose();
                return false;
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            User_Picture frm = new User_Picture();
            if (string.IsNullOrEmpty(dataGridView1.CurrentRow.Cells["status"].Value?.ToString())) // status A or U가 아닌 경우
            {
                if (!string.IsNullOrEmpty(dataGridView1.CurrentRow.Cells["image"].Value?.ToString())) // image => 이미지가 null이 아닌 경우
                {
                    // DataTable.Select() => Where문이랑 같다고 생각하면 됨
                    DataRow[] img_table = utility.img_table.Select("img_num = " + dataGridView1.CurrentRow.Cells["bas_empno"].Value?.ToString());
                    foreach (DataRow row in img_table)
                    {
                        if (row.Field<string>("img_num") == dataGridView1.CurrentRow.Cells["bas_empno"].Value?.ToString())
                        {
                            MemoryStream ms = new MemoryStream(row.Field<byte[]>("img_img"));
                            frm.pictureBox1.Image = Image.FromStream(ms);
                            break;
                        }
                    }
                }
                else
                {
                    frm.pictureBox1.Image = null;
                }
            }
            frm.Text = dataGridView1.CurrentRow.Cells["bas_name"].Value.ToString() +"님의 이미지";
            frm.Show();
        }
    }
}
