﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;//암호화/복호화
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yjkSystem_ver1
{
    public partial class Personal_Info : Form
    {
        private bool select_text_changed = false; //조회 시 텍스트 이벤트 제어
        private bool select_grid_changed = false; //조회 시 그리드뷰 이벤트 제어
        private bool select_img = false; //이미지가 비어있는지 확인

        byte[] encrypted = null;
        string decrypted = "";
        public string button_status { get; set; }  // 버튼 상태 저장

        public Label info_Count { get; set; }
        public Label info_Message { get; set; }
        public Personal_Info()
        {
            InitializeComponent();
            
            #region 유효성검사 넣기
            /*s_bas_empno.Validated += Input_Validation_Check;
            s_bas_name.Validated += Input_Validation_Check;
            s_bas_ename.Validated += Input_Validation_Check;
            s_bas_cname.Validated += Input_Validation_Check;
            s_bas_resno.Validated += Input_Validation_Check;
            s_bas_fix.SelectedIndexChanged += Input_Validation_Check;
            s_bas_hdpno.Validated += Input_Validation_Check;
            s_bas_email.Validated += Input_Validation_Check;
            s_bas_zip.Validated += Input_Validation_Check;
            s_bas_addr.Validated += Input_Validation_Check;
            s_bas_pos.SelectedIndexChanged += Input_Validation_Check;
            s_bas_dept.Validated += Input_Validation_Check;
            s_bas_dut.SelectedIndexChanged += Input_Validation_Check;
            s_bas_cont.SelectedIndexChanged += Input_Validation_Check;
            s_bas_emp_sdate.Validated += Input_Validation_Check;
            s_bas_emp_edate.Validated += Input_Validation_Check;
            s_bas_entdate.Validated += Input_Validation_Check;
            s_bas_resdate.Validated += Input_Validation_Check;
            s_bas_wsta.SelectedIndexChanged += Input_Validation_Check;
            s_bas_levdate.Validated += Input_Validation_Check;
            s_bas_reidate.Validated += Input_Validation_Check;
            s_bas_jkpdate.Validated += Input_Validation_Check;
            s_bas_dptdate.Validated += Input_Validation_Check;
            s_bas_posdate.Validated += Input_Validation_Check;
            s_bas_mil_sta.SelectedIndexChanged += Input_Validation_Check;
            s_bas_mil_mil.SelectedIndexChanged += Input_Validation_Check;
            s_bas_mil_rnk.SelectedIndexChanged += Input_Validation_Check;
            s_bas_acc_bank.SelectedIndexChanged += Input_Validation_Check;
            s_bas_acc_no.Validated += Input_Validation_Check;
            s_bas_acc_name.Validated += Input_Validation_Check;*/
            #endregion
        }

        private void Personal_Info_Load(object sender, EventArgs e)
        {
            button_status = utility.SetFuncBtn(utility.buttons, "1");
            utility.ComBoxItemSet(search_pos, SQL.SQL_Unit.Select_POS);
            utility.ComBoxItemSet(s_bas_pos, SQL.SQL_Unit.Select_POS);
            utility.ComBoxItemSet(s_bas_dut, SQL.SQL_Unit.Select_DUT);
            utility.ComBoxItemSet(s_bas_mil_mil, SQL.SQL_Unit.Select_MIL);
            utility.ComBoxItemSet(s_bas_mil_rnk, SQL.SQL_Unit.Select_RNK);
            utility.ComBoxItemSet(s_bas_acc_bank, SQL.SQL_Unit.Select_BNK);

            utility.conn = utility.SetOracleConnection();
            /*utility.cmd = utility.conn.CreateCommand();
            utility.cmd.CommandText = SQL.SQL_Img.SelectSQL;
            utility.cmd.BindByName = true;
            OracleDataAdapter da = new OracleDataAdapter(utility.cmd);*/
            OracleDataAdapter da = new OracleDataAdapter(SQL.SQL_Img.SelectSQL, utility.conn);
            utility.img_table = new DataTable();
            da.Fill(utility.img_table);



        }
        // object를 byte[]로 변환하는 메소드
        public static byte[] ObjectToByteArray(object obj)
        {
            if (obj == null)
                return null;

            BinaryFormatter formatter = new BinaryFormatter();

            using (MemoryStream stream = new MemoryStream())
            {
                formatter.Serialize(stream, obj);
                return stream.ToArray();
            }
        }
        #region 최초 DataTable 생성
        private void create_table()
        {
            try
            {
                if(utility.table != null) utility.table.Clear();
                utility.conn = utility.SetOracleConnection();
                utility.cmd = utility.conn.CreateCommand();
                utility.cmd.CommandText = SQL.SQL_Bas.CreateSQL;
                utility.cmd.BindByName = true;
                OracleDataAdapter da = new OracleDataAdapter(utility.cmd);
                da.Fill(utility.ds, "TAB"); // File(DataSet, 테이블이름)
                //DataSet에서 첫 번째 테이블 정보를 table에 기록 후 DataGridView에 table 설정
                utility.table = utility.ds.Tables[0];
                dataGridView1.DataSource = utility.table;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                if (utility.conn != null) utility.conn.Close();
            }
        }
        #endregion
        #region 조회버튼 기능
        public void Search_Btn()
        {
            //dataGridView1.Rows.Clear();
            
            try
            {
                utility.conn = utility.SetOracleConnection();
                utility.cmd = utility.conn.CreateCommand();
                utility.cmd.CommandText = SQL.SQL_Bas.SelectSQL;
                utility.cmd.BindByName = true;
                utility.cmd.Parameters.Add("bas_empno", OracleDbType.Varchar2).Value = search_code.Text + "%";
                utility.cmd.Parameters.Add("bas_name", OracleDbType.Varchar2).Value = "%" + search_name.Text + "%";
                utility.cmd.Parameters.Add("bas_pos", OracleDbType.Varchar2).Value = "%" + utility.GetCode(search_pos.Text) + "%";
                utility.cmd.Parameters.Add("bas_dept", OracleDbType.Varchar2).Value = "%" + utility.GetCode(search_dept.Text) + "%";
                OracleDataAdapter da = new OracleDataAdapter(utility.cmd);
                utility.ds.Clear();
                da.Fill(utility.ds, "TAB");
                utility.table = utility.ds.Tables[0];
                select_grid_changed = true;
                dataGridView1.DataSource = utility.table;
                
                utility.cmd.ExecuteNonQuery();
                utility.cmd.Parameters.Clear();
                //************************************************************************************************************************************
                //** 주민등록번호 복호화
                //************************************************************************************************************************************
                utility.cmd.CommandText = SQL.SQL_Bas.Encry_SelectSQL;
                utility.cmd.BindByName = true;
                OracleDataReader reader = utility.cmd.ExecuteReader();
                while (reader.Read())
                {
                    int i = 0;
                    while (i < dataGridView1.Rows.Count)
                    {
                        if ((string)dataGridView1.Rows[i].Cells["bas_empno"].Value == (string)reader["user_empno"])
                        {
                            /*encrypted = (byte[])reader["user_enresno"];
                            string deresno = DecryptStringFromBytes_Aes(encrypted, utility.key, utility.iv);
                            dataGridView1.Rows[i].Cells["bas_resno"].Value = deresno;*/
                            byte[] bytes = (byte[])reader["user_enresno"];
                            string text = Encoding.UTF8.GetString(bytes);
                            dataGridView1.Rows[i].Cells["bas_resno"].Value = utility.UnProtect(text);
                        }
                        i++;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                select_grid_changed = false;
                if (utility.conn != null) utility.conn.Close();
                if (dataGridView1.Rows.Count <= 0)
                {
                    MessageBox.Show("조회된 자료가 없습니다.");
                    info_Message.Text = "조회된 자료가 없습니다.";
                    utility.Panel_Clear(panel2);
                    utility.Panel_Clear(panel3);
                }
                else
                {
                    this.dataGridView1_SelectionChanged(null, null);
                    button_status = utility.SetFuncBtn(utility.buttons, "2");
                    info_Message.Text = "자료가 정상적으로 조회되었습니다.";
                    info_Count.Text = dataGridView1.Rows.Count.ToString();
                }
            }
        }
        #endregion
        #region 추가버튼 기능
        public void Insert_Btn()
        {

            var rowidx = dataGridView1.CurrentRow == null ? 0 : dataGridView1.CurrentRow.Index;

            if (dataGridView1.Rows.Count == 0)
            {
                //rowidx = dataGridView1.Rows.Add();
                create_table(); //테이블을 생성
                utility.table?.Rows.Add(utility.table?.NewRow());
            }
            else
            {
                rowidx++;
                utility.table?.Rows.InsertAt(utility.table?.NewRow(), rowidx);
                //dataGridView1.Rows.Insert(rowidx);
            }
            dataGridView1.Rows[rowidx].Cells["status"].Value = "A";
            dataGridView1.CurrentCell = dataGridView1.Rows[rowidx].Cells[1]; // 추가된 Row로 Focus
            pictureBox1.Image = null;
            s_bas_empno.ReadOnly = false;
            s_bas_empno.Focus();

            button_status = utility.SetFuncBtn(utility.buttons, "3");
        }
        #endregion
        #region 수정버튼 기능
        public void Update_Btn()
        {
            if (dataGridView1.SelectedRows.Count <= 0) return;
            DataGridViewRow row = dataGridView1.SelectedRows[0];
            if (string.IsNullOrEmpty(row.Cells["status"].Value?.ToString()))
            {
                row.Cells["status"].Value = "U";
                button_status = utility.SetFuncBtn(utility.buttons, "3");
            }
        }
        #endregion
        #region 삭제버튼 기능
        public void Delete_Btn()
        {
            if (dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("삭제할 자료를 선택하세요.", "삭제확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DataGridViewRow row = dataGridView1.CurrentRow;
            if (row.Cells["status"].Value?.ToString() == "A")
            {
                dataGridView1.Rows.RemoveAt(row.Index);
                return;
            }
            DialogResult result = MessageBox.Show(row.Cells["bas_empno"].Value + " 삭제하시겠습니까?", "삭제확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No) return;

            try
            {
                utility.conn = utility.SetOracleConnection();
                utility.cmd = utility.conn.CreateCommand();
                utility.cmd.BindByName = true;
                utility.cmd.CommandText = SQL.SQL_Bas.DeleteSQL;
                utility.cmd.Parameters.Add("bas_empno", OracleDbType.Varchar2).Value = row.Cells["bas_empno"].Value;
                utility.cmd.ExecuteNonQuery();

                utility.cmd.Parameters.Clear(); //파라미터값을 초기화 해야 다른 sql 이용가능

                utility.cmd.CommandText = SQL.SQL_Img.DeleteSQL;
                utility.cmd.Parameters.Add("img_num", OracleDbType.Varchar2).Value = row.Cells["bas_empno"].Value;
                utility.cmd.ExecuteNonQuery();

                dataGridView1.Rows.RemoveAt(row.Index);
                //MessageBox.Show("자료가 정상적으로 삭제되었습니다.");
                info_Message.Text = "자료가 정상적으로 삭제되었습니다.";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                if (utility.conn != null) utility.conn.Close();
            }
        }
        #endregion
        #region 저장버튼 기능
        public void Save_Btn()
        {
            DialogResult result = MessageBox.Show("자료를 저장하시겠습니까?", "저장확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No) return;
            if (!utility.InputErrorChk(dataGridView1)) return;

            OracleTransaction tran = null;
            try
            {
                utility.conn = utility.SetOracleConnection();
                tran = utility.conn.BeginTransaction(IsolationLevel.ReadCommitted); //트렌젝션 사용 하기 위함
                utility.cmd = utility.conn.CreateCommand();

                //BindByName 을 false 로 해두면 변수 이름은 무시되고 서수에 의해 맵핑된다
                utility.cmd.BindByName = true;
                utility.cmd.Transaction = tran;
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (string.IsNullOrEmpty(row.Cells["status"].Value?.ToString())) continue;
                    if (row.Cells["status"].Value.Equals("A")) // 추가
                    {
                        utility.cmd.CommandText = SQL.SQL_Bas.InsertSQL;
                    }
                    else // 수정
                    {
                        utility.cmd.CommandText = SQL.SQL_Bas.UpdateSQL;
                    }
                    /*bas_empno, bas_resno, bas_name, bas_cname, bas_ename, bas_fix, bas_zip, bas_addr, bas_hdpno, bas_telno, bas_email, 
                      bas_mil_sta, bas_mil_mil, bas_mil_rnk, bas_mar, bas_acc_bank, bas_acc_name, bas_acc_no, bas_cont, bas_emp_sdate, 
                      bas_emp_edate, bas_entdate, bas_resdate, bas_levdate, bas_reidate, bas_dptdate, bas_jkpdate, bas_posdate, bas_wsta, 
                      bas_pos, bas_dut, bas_dept, bas_rmk, datasys1, datasys2*/

                    utility.cmd.Parameters.Add("bas_empno", OracleDbType.Varchar2).Value = row.Cells["bas_empno"].Value?.ToString();
                    /*encrypted = EncryptStringToBytes_Aes(utility.Get_Date_Replace(row.Cells["bas_resno"].Value?.ToString()), utility.key, utility.iv);
                    utility.cmd.Parameters.Add("bas_resno", OracleDbType.Varchar2).Value = encrypted;*/
                    //utility.cmd.Parameters.Add("bas_resno", OracleDbType.Varchar2).Value = utility.Protect(row.Cells["bas_resno"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_resno", OracleDbType.Varchar2).Value = utility.Get_Date_Replace(row.Cells["bas_resno"].Value?.ToString()).Substring(0,7) +"*****";
                    utility.cmd.Parameters.Add("bas_name", OracleDbType.Varchar2).Value = row.Cells["bas_name"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_cname", OracleDbType.Varchar2).Value = row.Cells["bas_cname"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_ename", OracleDbType.Varchar2).Value = row.Cells["bas_ename"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_fix", OracleDbType.Varchar2).Value = row.Cells["bas_fix"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_zip", OracleDbType.Varchar2).Value = row.Cells["bas_zip"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_addr", OracleDbType.Varchar2).Value = row.Cells["bas_addr"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_hdpno", OracleDbType.Varchar2).Value = row.Cells["bas_hdpno"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_telno", OracleDbType.Varchar2).Value = row.Cells["bas_telno"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_email", OracleDbType.Varchar2).Value = row.Cells["bas_email"].Value?.ToString() + "@" + row.Cells["sub_email"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_mil_sta", OracleDbType.Varchar2).Value = row.Cells["bas_mil_sta"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_mil_mil", OracleDbType.Varchar2).Value = utility.GetCode((string)row.Cells["bas_mil_mil"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_mil_rnk", OracleDbType.Varchar2).Value = utility.GetCode((string)row.Cells["bas_mil_rnk"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_mar", OracleDbType.Varchar2).Value = utility.ChangedBoolType_CheckBox(row.Cells["bas_mar"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_acc_bank", OracleDbType.Varchar2).Value = utility.GetCode((string)row.Cells["bas_acc_bank"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_acc_name", OracleDbType.Varchar2).Value = row.Cells["bas_acc_name"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_acc_no", OracleDbType.Varchar2).Value = row.Cells["bas_acc_no"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_cont", OracleDbType.Varchar2).Value = row.Cells["bas_cont"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_emp_sdate", OracleDbType.Varchar2).Value = utility.Get_Date_Replace(row.Cells["bas_emp_sdate"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_emp_edate", OracleDbType.Varchar2).Value = utility.Get_Date_Replace(row.Cells["bas_emp_edate"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_entdate", OracleDbType.Varchar2).Value = utility.Get_Date_Replace(row.Cells["bas_entdate"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_resdate", OracleDbType.Varchar2).Value = utility.Get_Date_Replace(row.Cells["bas_resdate"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_levdate", OracleDbType.Varchar2).Value = utility.Get_Date_Replace(row.Cells["bas_levdate"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_reidate", OracleDbType.Varchar2).Value = utility.Get_Date_Replace(row.Cells["bas_reidate"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_dptdate", OracleDbType.Varchar2).Value = utility.Get_Date_Replace(row.Cells["bas_dptdate"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_jkpdate", OracleDbType.Varchar2).Value = utility.Get_Date_Replace(row.Cells["bas_jkpdate"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_posdate", OracleDbType.Varchar2).Value = utility.Get_Date_Replace(row.Cells["bas_posdate"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_wsta", OracleDbType.Varchar2).Value = row.Cells["bas_wsta"].Value?.ToString();
                    utility.cmd.Parameters.Add("bas_pos", OracleDbType.Varchar2).Value = utility.GetCode((string)row.Cells["bas_pos"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_dut", OracleDbType.Varchar2).Value = utility.GetCode((string)row.Cells["bas_dut"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_dept", OracleDbType.Varchar2).Value = utility.GetCode((string)row.Cells["bas_dept"].Value?.ToString());
                    utility.cmd.Parameters.Add("bas_rmk", OracleDbType.Varchar2).Value = row.Cells["bas_rmk"].Value?.ToString();
                    utility.cmd.Parameters.Add("datasys1", OracleDbType.Date).Value = DateTime.Now;
                    //utility.cmd.Parameters.Add("datasys2", OracleDbType.Varchar2).Value = row.Cells["status"].Value;

                    utility.cmd.ExecuteNonQuery();
                    utility.cmd.Parameters.Clear(); //파라미터값을 초기화 해야 다른 sql 이용가능

                    if (row.Cells["status"].Value.Equals("A")) // 추가
                    {
                        utility.cmd.CommandText = SQL.SQL_Bas.Encry_InsertSQL;
                    }
                    else // 수정
                    {
                        utility.cmd.CommandText = SQL.SQL_Bas.Encry_UpdateSQL;
                    }
                    utility.cmd.Parameters.Add("user_empno", OracleDbType.Varchar2).Value = row.Cells["bas_empno"].Value?.ToString();
                    //encrypted = EncryptStringToBytes_Aes(utility.Get_Date_Replace(row.Cells["bas_resno"].Value?.ToString()), utility.key, utility.iv);
                    //utility.cmd.Parameters.Add("user_enresno", OracleDbType.Blob).Value = encrypted;
                    utility.cmd.Parameters.Add("user_enresno", OracleDbType.Blob).Value = Encoding.UTF8.GetBytes(utility.Protect(row.Cells["bas_resno"].Value?.ToString()));
                    utility.cmd.ExecuteNonQuery();
                    utility.cmd.Parameters.Clear(); //파라미터값을 초기화 해야 다른 sql 이용가능

                    DataRow[] img_table = utility.img_table.Select("img_num = " + row.Cells["bas_empno"].Value?.ToString());

                    // img_table에 해당사원번호가 있으면 update 없으면 insert
                    if (img_table.Length == 0) // 0이면 해당 사원번호가 없음
                    {
                        utility.cmd.CommandText = SQL.SQL_Img.InsertSQL;
                    }
                    else // 수정
                    {
                        utility.cmd.CommandText = SQL.SQL_Img.UpdateSQL;
                    }
                    utility.cmd.Parameters.Add("img_num", OracleDbType.Varchar2).Value = row.Cells["bas_empno"].Value?.ToString();
                    utility.cmd.Parameters.Add("img_img", OracleDbType.Blob).Value = row.Cells["image"].Value;
                    utility.cmd.Parameters.Add("img_nam", OracleDbType.Varchar2).Value = row.Cells["imgnam"].Value?.ToString();
                    utility.cmd.ExecuteNonQuery();

                    OracleDataAdapter da = new OracleDataAdapter(SQL.SQL_Img.SelectSQL, utility.conn);
                    utility.img_table = new DataTable();
                    da.Fill(utility.img_table);

                    if (row.Cells["status"].Value.Equals("")) continue;
                }
                tran.Commit();


                int rowidx = 0;
                while (dataGridView1.Rows.Count > rowidx)
                {
                    dataGridView1.Rows[rowidx].Cells["status"].Value = "";
                    rowidx++;
                }
            }
            catch (Exception ex)
            {
                tran.Rollback();
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                if (utility.conn != null) utility.conn.Close();
            }
            button_status = utility.SetFuncBtn(utility.buttons, "2");
            info_Count.Text = dataGridView1.Rows.Count.ToString();
            info_Message.Text = "자료가 정상적으로 저장되었습니다.";
        }
        #endregion
        #region 취소버튼 기능
        public void Cancel_Btn()
        {
            int rowidx = 0;
            while (dataGridView1.Rows.Count > rowidx)
            {
                if (!string.IsNullOrEmpty(dataGridView1.Rows[rowidx].Cells["status"].Value?.ToString()))
                {
                    DialogResult result = MessageBox.Show("작업중인 자료를 취소하시겠습니까?", "취소확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.No) return;
                    Search_Btn();
                    button_status = utility.SetFuncBtn(utility.buttons, "2");
                    break;
                }
                rowidx++;
            }
        }
        #endregion
        #region 텍스트 변경 시 그리드뷰에 작성
        private void InputData_TextChanged(object sender, EventArgs e)
        {
            if (select_text_changed) return;
            if (dataGridView1.SelectedRows.Count == 0) return;

            utility.SetGridViewValue(dataGridView1, sender as Control);
            Input_Validation_Check(sender, e); //* Control 에 오류메세지 표시
            DataGridViewRow row = dataGridView1.CurrentRow;
            if (string.IsNullOrEmpty(row.Cells["status"].Value?.ToString()))
            {
                row.Cells["status"].Value = "U";
            }

            button_status = utility.SetFuncBtn(utility.buttons, "3");
        }
        #endregion
        #region DataGridView 선택 변경시 Control의 Value Set
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (select_grid_changed) return;
            if (dataGridView1.Rows.Count == 0) return;

            select_text_changed = true; // TextChange 이벤트와 충돌 방지
            utility.SetControlValue(dataGridView1, tableLayoutPanel2); // (DataGridView, Control)
            //************************************************************************************************************************************
            Input_Validation_Check(sender, e); //* Control 에 오류메세지 표시

            //************************************************************************************************************************************
            //** DataTable에 저장된 이미지 불러오기 (상태 : null 인 경우)
            //************************************************************************************************************************************
            if (string.IsNullOrEmpty(dataGridView1.CurrentRow.Cells["status"].Value?.ToString())) // status A or U가 아닌 경우
            {
                if (!string.IsNullOrEmpty(dataGridView1.CurrentRow.Cells["image"].Value?.ToString())) // image => 이미지가 null이 아닌 경우
                {
                    // DataTable.Select() => Where문이랑 같다고 생각하면 됨
                    DataRow[] img_table = utility.img_table.Select("img_num = " + dataGridView1.CurrentRow.Cells["bas_empno"].Value?.ToString());
                    foreach(DataRow row in img_table)
                    {
                        if (row.Field<string>("img_num") == dataGridView1.CurrentRow.Cells["bas_empno"].Value?.ToString())
                        {
                            MemoryStream ms = new MemoryStream(row.Field<byte[]>("img_img"));
                            pictureBox1.Image = Image.FromStream(ms);
                            break;
                        }
                    }
                }
                else
                {
                    pictureBox1.Image = null;
                }
            }
            else // status가 A or U 인경우
            {
                if (!string.IsNullOrEmpty(dataGridView1.CurrentRow.Cells["imgnam"].Value?.ToString())) // 이미지 경로가 비어있지 않는 경우
                {
                    Image image = Image.FromFile(dataGridView1.CurrentRow.Cells["imgnam"].Value?.ToString());
                    // PictureBox에 이미지 출력
                    pictureBox1.Image = image;
                }
                else
                {
                    pictureBox1.Image = null;
                }
            }
            //************************************************************************************************************************************

            select_text_changed = false; // TextChange 이벤트와 충돌 방지


            //MessageBox.Show(dataGridView1.SelectedRows[0].Cells["status"].Value?.ToString());
            if (dataGridView1.CurrentRow.Cells["status"].Value?.ToString() == "A")
            {
                s_bas_empno.ReadOnly = false;
            }
            else
            {
                s_bas_empno.ReadOnly = true;
            }

        }
        #endregion
        #region 유효성 검사(Error_Check)
        private void Input_Validation_Check(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count <= 0) return;
            string errmsg = "";

            if (s_bas_empno.Text == "")
            {
                errmsg = "사원번호를 반드시 입력하세요";
                errorProvider1.SetError(s_bas_empno, errmsg);
            }
            else if (s_bas_empno.TextLength != 5)
            {
                errmsg = "사원번호는 반드시 5자리로 입력하세요";
                errorProvider1.SetError(s_bas_empno, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_empno, "");
            }
            if (s_bas_name.Text == "")
            {
                errmsg = "성명을 반드시 입력하세요";
                errorProvider1.SetError(s_bas_name, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_name, "");
            }
            if (s_bas_ename.Text == "")
            {
                errmsg = "성명(영어)을 반드시 입력하세요";
                errorProvider1.SetError(s_bas_ename, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_ename, "");
            }
            if (s_bas_cname.Text == "")
            {
                errmsg = "성명(한자)을 반드시 입력하세요";
                errorProvider1.SetError(s_bas_cname, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_cname, "");
            }
            //if (utility.Get_Resno_IsEmpty(s_bas_resno.Text))
            if (utility.Get_Resno_IsEmpty(dataGridView1.CurrentRow.Cells["bas_resno"].Value?.ToString()))
            {
                errmsg = "주민등록번호를 반드시 입력하세요";
                errorProvider1.SetError(s_bas_resno, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_resno, "");
            }
            if (s_bas_fix.SelectedIndex == 0)
            {
                errmsg = "성별을 반드시 선택하세요";
                errorProvider1.SetError(s_bas_fix, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_fix, "");
            }
            if (utility.Get_Date_IsEmpty(s_bas_hdpno.Text))
            {
                errmsg = "휴대전화를 반드시 입력하세요";
                errorProvider1.SetError(s_bas_hdpno, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_hdpno, "");
            }
            if (s_bas_email.Text == "" || s_sub_email.Text =="")
            {
                errmsg = "이메일을 반드시 입력하세요";
                errorProvider1.SetError(s_sub_email, errmsg);
            }
            /*else if (!utility.IsValidEmail(s_bas_email.Text))
            {
                errmsg = "올바른 이메일 주소 형식이 아닙니다.";
                errorProvider1.SetError(s_bas_email, errmsg);
            }*/
            else
            {
                errorProvider1.SetError(s_sub_email, "");
            }
            if (s_bas_zip.Text == "")
            {
                errmsg = "우편번호를 반드시 입력하세요";
                errorProvider1.SetError(button4, errmsg);
            }
            else
            {
                errorProvider1.SetError(button4, "");
            }
            if (s_bas_addr.Text == "")
            {
                errmsg = "주소를 반드시 입력하세요";
                errorProvider1.SetError(s_bas_addr, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_addr, "");
            }
            if (s_bas_pos.SelectedIndex == 0)
            {
                errmsg = "직급을 반드시 선택하세요";
                errorProvider1.SetError(s_bas_pos, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_pos, "");
            }
            if (s_bas_dept.Text == "")
            {
                errmsg = "부서를 반드시 입력하세요";
                errorProvider1.SetError(sd_btn2, errmsg);
            }
            else
            {
                errorProvider1.SetError(sd_btn2, "");
            }
            if (s_bas_dut.SelectedIndex == 0)
            {
                errmsg = "직책을 반드시 선택하세요";
                errorProvider1.SetError(s_bas_dut, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_dut, "");
            }
            if (s_bas_cont.SelectedIndex == 0)
            {
                errmsg = "계약구분을 반드시 선택하세요";
                errorProvider1.SetError(s_bas_cont, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_cont, "");
            }
            if(s_bas_cont.Text == "계약직")
            {
                errorProvider1.SetError(s_bas_entdate, "");
                errorProvider1.SetError(s_bas_wsta, "");
                s_bas_wsta.SelectedIndex = 0;
                errorProvider1.SetError(s_bas_levdate, "");
                errorProvider1.SetError(s_bas_reidate, "");
                errorProvider1.SetError(s_bas_resdate, "");

                if (utility.Get_Date_IsEmpty(s_bas_emp_sdate.Text))
                {
                    errmsg = "계약시작일을 반드시 입력하세요";
                    errorProvider1.SetError(s_bas_emp_sdate, errmsg);
                }
                else if (utility.Check_Date_YYYYMMDD(s_bas_emp_sdate.Text) == false)
                {
                    errmsg = "날짜형식이 올바르지 않습니다.";
                    errorProvider1.SetError(s_bas_emp_sdate, errmsg);
                }
                else
                {
                    errorProvider1.SetError(s_bas_emp_sdate, "");
                }

                if (utility.Get_Date_IsEmpty(s_bas_emp_edate.Text))
                {
                    errmsg = "계약종료일을 반드시 입력하세요";
                    errorProvider1.SetError(s_bas_emp_edate, errmsg);
                }
                else if (utility.Check_Date_YYYYMMDD(s_bas_emp_edate.Text) == false)
                {
                    errmsg = "날짜형식이 올바르지 않습니다.";
                    errorProvider1.SetError(s_bas_emp_edate, errmsg);
                }
                else
                {
                    errorProvider1.SetError(s_bas_emp_edate, "");
                }
            }
            else if (s_bas_cont.Text == "정규직")
            {
                errorProvider1.SetError(s_bas_emp_sdate, "");
                errorProvider1.SetError(s_bas_emp_edate, "");

                if (utility.Get_Date_IsEmpty(s_bas_entdate.Text))
                {
                    errmsg = "입사일자을 반드시 입력하세요";
                    errorProvider1.SetError(s_bas_entdate, errmsg);
                }
                else if (utility.Check_Date_YYYYMMDD(s_bas_entdate.Text) == false)
                {
                    errmsg = "날짜형식이 올바르지 않습니다.";
                    errorProvider1.SetError(s_bas_entdate, errmsg);
                }
                else
                {
                    errorProvider1.SetError(s_bas_entdate, "");
                }
                if (s_bas_wsta.SelectedIndex == 0)
                {
                    errmsg = "재직상태를 반드시 선택하세요";
                    errorProvider1.SetError(s_bas_wsta, errmsg);
                }
                else
                {
                    errorProvider1.SetError(s_bas_wsta, "");
                }
                if (s_bas_wsta.Text == "휴직")
                {
                    errorProvider1.SetError(s_bas_resdate, "");
                    if (utility.Get_Date_IsEmpty(s_bas_levdate.Text))
                    {
                        errmsg = "휴직일자을 반드시 입력하세요";
                        errorProvider1.SetError(s_bas_levdate, errmsg);
                    }
                    else if (utility.Check_Date_YYYYMMDD(s_bas_levdate.Text) == false)
                    {
                        errmsg = "날짜형식이 올바르지 않습니다.";
                        errorProvider1.SetError(s_bas_levdate, errmsg);
                    }
                    else
                    {
                        errorProvider1.SetError(s_bas_levdate, "");
                    }
                    if (utility.Get_Date_IsEmpty(s_bas_reidate.Text))
                    {
                        errmsg = "복직일자을 반드시 입력하세요";
                        errorProvider1.SetError(s_bas_reidate, errmsg);
                    }
                    else if (utility.Check_Date_YYYYMMDD(s_bas_reidate.Text) == false)
                    {
                        errmsg = "날짜형식이 올바르지 않습니다.";
                        errorProvider1.SetError(s_bas_reidate, errmsg);
                    }
                    else
                    {
                        errorProvider1.SetError(s_bas_reidate, "");
                    }
                }
                else if (s_bas_wsta.Text == "퇴직")
                {
                    errorProvider1.SetError(s_bas_levdate, "");
                    errorProvider1.SetError(s_bas_reidate, "");
                    if (utility.Get_Date_IsEmpty(s_bas_resdate.Text))
                    {
                        errmsg = "퇴직일자을 반드시 입력하세요";
                        errorProvider1.SetError(s_bas_resdate, errmsg);
                    }
                    else if (utility.Check_Date_YYYYMMDD(s_bas_resdate.Text) == false)
                    {
                        errmsg = "날짜형식이 올바르지 않습니다.";
                        errorProvider1.SetError(s_bas_resdate, errmsg);
                    }
                    else
                    {
                        errorProvider1.SetError(s_bas_resdate, "");
                    }
                }
                else
                {
                    errorProvider1.SetError(s_bas_levdate, "");
                    errorProvider1.SetError(s_bas_reidate, "");
                    errorProvider1.SetError(s_bas_resdate, "");
                }
            }
            else
            {
                errorProvider1.SetError(s_bas_entdate, "");
                errorProvider1.SetError(s_bas_wsta, "");
                errorProvider1.SetError(s_bas_levdate, "");
                errorProvider1.SetError(s_bas_reidate, "");
                errorProvider1.SetError(s_bas_resdate, "");
                errorProvider1.SetError(s_bas_emp_sdate, "");
                errorProvider1.SetError(s_bas_emp_edate, "");
            }
            //-------------------------------------------------------------------------------------------------------------
            if (utility.Get_Date_IsEmpty(s_bas_jkpdate.Text))
            {
                errmsg = "현직급일자을 반드시 입력하세요";
                errorProvider1.SetError(s_bas_jkpdate, errmsg);
            }
            else if (utility.Check_Date_YYYYMMDD(s_bas_emp_sdate.Text) == false)
            {
                errmsg = "날짜형식이 올바르지 않습니다.";
                errorProvider1.SetError(s_bas_emp_sdate, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_jkpdate, "");
            }
            if (utility.Get_Date_IsEmpty(s_bas_dptdate.Text))
            {
                errmsg = "현부서일자을 반드시 입력하세요";
                errorProvider1.SetError(s_bas_dptdate, errmsg);
            }
            else if (utility.Check_Date_YYYYMMDD(s_bas_emp_sdate.Text) == false)
            {
                errmsg = "날짜형식이 올바르지 않습니다.";
                errorProvider1.SetError(s_bas_emp_sdate, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_dptdate, "");
            }
            if (utility.Get_Date_IsEmpty(s_bas_posdate.Text))
            {
                errmsg = "현직책일자을 반드시 입력하세요";
                errorProvider1.SetError(s_bas_posdate, errmsg);
            }
            else if (utility.Check_Date_YYYYMMDD(s_bas_emp_sdate.Text) == false)
            {
                errmsg = "날짜형식이 올바르지 않습니다.";
                errorProvider1.SetError(s_bas_emp_sdate, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_posdate, "");
            }
            //-------------------------------------------------------------------------------------------------------------
            if (s_bas_mil_sta.SelectedIndex == 0)
            {
                errmsg = "복무구분을 반드시 선택하세요";
                errorProvider1.SetError(s_bas_mil_sta, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_mil_sta, "");
            }
            if(s_bas_mil_sta.Text == "군필")
            {
                if (s_bas_mil_mil.SelectedIndex == 0)
                {
                    errmsg = "군별을 반드시 선택하세요";
                    errorProvider1.SetError(s_bas_mil_mil, errmsg);
                }
                else
                {
                    errorProvider1.SetError(s_bas_mil_mil, "");
                }
                if (s_bas_mil_rnk.SelectedIndex == 0)
                {
                    errmsg = "계급을 반드시 선택하세요";
                    errorProvider1.SetError(s_bas_mil_rnk, errmsg);
                }
                else
                {
                    errorProvider1.SetError(s_bas_mil_rnk, "");
                }
            }
            else
            {
                s_bas_mil_mil.SelectedIndex = 0;
                s_bas_mil_rnk.SelectedIndex = 0;
                errorProvider1.SetError(s_bas_mil_mil, "");
                errorProvider1.SetError(s_bas_mil_rnk, "");
            }
            //-------------------------------------------------------------------------------------------------------------
            if (s_bas_acc_bank.SelectedIndex == 0)
            {
                errmsg = "은행을 반드시 선택하세요";
                errorProvider1.SetError(s_bas_acc_bank, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_acc_bank, "");
            }
            if (s_bas_acc_no.Text == "")
            {
                errmsg = "계좌번호를 반드시 입력하세요";
                errorProvider1.SetError(s_bas_acc_no, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_acc_no, "");
            }
            if (s_bas_acc_name.Text == "")
            {
                errmsg = "예금주를 반드시 입력하세요";
                errorProvider1.SetError(s_bas_acc_name, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_bas_acc_name, "");
            }
            dataGridView1.SelectedRows[0].ErrorText = errmsg;

        }
        #endregion
        #region 폼간의 데이터 주고받기 (부서정보, 우편번호)
        private void button3_Click(object sender, EventArgs e)
        {
            String SelectSQL = SQL.SQL_Dept.Select_DPT;
            Control ctl = sender as Control;

            // a위치== out string result 변수는 호출될때 값이 없음
            if (ShowSearchCDWindow(SelectSQL, "프로그램코드", out string result) == true)
            {
                //if (dataGridView1.SelectedRows.Count < 1) return;
                if (ctl.Name == "sd_btn1") search_dept.Text = result;
                if (ctl.Name == "sd_btn2") s_bas_dept.Text = result;
            }
        }
        public bool ShowSearchCDWindow(string sql, string caption, out string result)
        {
            //여기서의 result 변수는 결국 a위치에서 만든 변수를 가르킴
            string search = s_bas_dept.Text;
            var win = new Search_Dept(sql, search);
            win.Text = caption;
            if (win.ShowDialog() == DialogResult.OK)
            {

                //form2에 getResult 를 호출

                //
                result = win.GetResult;

                //결국 결과를 받아서 result 변수에 저장했기 때문에 a위치의 변수값이 설정되는것과
                //같은 현상
                win.Dispose();
                return true;
            }
            else
            {
                result = "";
                win.Dispose();
                return false;
            }
        }
        //****************************************************************
        //**** 우편번호 API 사용 / 다른폼의 값 받아오기
        //****************************************************************
        private void button4_Click(object sender, EventArgs e)
        {
            if (SearchZipAddr(out string zip, out string addr) == true)
            {
                //if (dataGridView1.SelectedRows.Count < 1) return;
                s_bas_zip.Text = zip;
                s_bas_addr.Text = addr;
            }
        }
        public bool SearchZipAddr(out string zip, out string addr)
        {
            var win = new Address();
            if (win.ShowDialog() == DialogResult.OK)
            {

                //form2에 getResult 를 호출
                zip = win.GetZip;
                addr = win.GetAddr;
                //결국 결과를 받아서 result 변수에 저장했기 때문에 a위치의 변수값이 설정되는것과 같은 현상
                win.Dispose();
                return true;
            }
            else
            {
                zip = "";
                addr = "";
                win.Dispose();
                return false;
            }
        }
        #endregion
        #region MaskedTextBox 클릭 시 맨앞으로 이동
        private void MaskedTextBox_Click(object sender, EventArgs e)
        {
            MaskedTextBox mtxt = sender as MaskedTextBox;
            utility.SetMaskedTextBox_Cursor(mtxt);
        }
        #endregion
        #region DataGridView 행 삭제 시 버튼 처리
        private void dataGridView1_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if (dataGridView1.Rows.Count <= 0)
            {
                button_status = utility.SetFuncBtn(utility.buttons, "1");
                errorProvider1.Clear();
                return;
            }
            int rowidx = 0;
            while (dataGridView1.Rows.Count > rowidx)
            {
                if (!string.IsNullOrEmpty(dataGridView1.Rows[rowidx].Cells["status"].Value?.ToString())) return;
                rowidx++;
            }
            button_status = utility.SetFuncBtn(utility.buttons, "2");
        }
        #endregion
        #region 이미지 DB에 저장
        private void Save_Image()
        {
            if (dataGridView1.Rows.Count <= 0) return;
            if (string.IsNullOrEmpty(s_bas_empno.Text))
            {
                MessageBox.Show("사원번호를 입력 후 이미지 저장이 가능합니다.");
                return;
            }
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "이미지 파일 (*.jpg, *.jpeg, *.png, *.bmp)|*.jpg;*.jpeg;*.png;*.bmp";
                openFileDialog.RestoreDirectory = true;
                OracleTransaction tran = null;

                //초기 이미지상태확인
                if (pictureBox1.Image == null) { select_img = false; }
                else { select_img = true; }
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // 이미지 파일을 읽어와서 Image 객체로 변환
                        Image image = Image.FromFile(openFileDialog.FileName);
                        byte[] img = null;
                        // PictureBox에 이미지 출력
                        pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                        pictureBox1.Image = image;
                        FileStream fs = new FileStream(openFileDialog.FileName, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        dataGridView1.CurrentRow.Cells["image"].Value = img;
                        dataGridView1.CurrentRow.Cells["imgnam"].Value = openFileDialog.FileName;
                        /*//이미지 저장 및 수정
                        utility.conn = utility.SetOracleConnection();
                        tran = utility.conn.BeginTransaction(IsolationLevel.ReadCommitted); //트렌젝션 사용 하기 위함
                        utility.cmd = utility.conn.CreateCommand();

                        //BindByName 을 false 로 해두면 변수 이름은 무시되고 서수에 의해 맵핑된다
                        utility.cmd.BindByName = true;
                        utility.cmd.Transaction = tran;
                        if (!select_img) // 추가
                        {
                            utility.cmd.CommandText = SQL.SQL_Img.InsertSQL;
                        }
                        else // 수정
                        {
                            utility.cmd.CommandText = SQL.SQL_Img.UpdateSQL;
                        }
                        utility.cmd.Parameters.Add("img_num", OracleDbType.Varchar2).Value = dataGridView1.CurrentRow.Cells["bas_empno"].Value?.ToString();
                        utility.cmd.Parameters.Add("img_img", OracleDbType.Blob).Value = img;
                        utility.cmd.ExecuteNonQuery();

                        tran.Commit();
                        MessageBox.Show("이미지가 저장되었습니다, 조회 시 저장한 이미지로 변경됩니다.");

                        OracleDataAdapter da = new OracleDataAdapter(SQL.SQL_Img.SelectSQL, utility.conn);
                        utility.img_table = new DataTable();
                        da.Fill(utility.img_table);*/
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();
                        MessageBox.Show("이미지 로딩에 실패했습니다: " + ex.Message);
                    }
                    finally
                    {
                        if (utility.conn != null) utility.conn.Close();
                    }
                }
            }
        }
        #endregion
        #region 이미지 불러오기 버튼
        private void Search_Img_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count <= 0) return;
            if (string.IsNullOrEmpty(s_bas_empno.Text))
            {
                MessageBox.Show("사원번호를 입력 후 이미지 저장이 가능합니다.");
                s_bas_empno.Focus();
                return;
            }
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "이미지 파일 (*.jpg, *.jpeg, *.png, *.bmp)|*.jpg;*.jpeg;*.png;*.bmp";
                openFileDialog.RestoreDirectory = true;
                DataGridViewRow row = dataGridView1.CurrentRow;
                OracleTransaction tran = null;

                //초기 이미지상태확인
                if (pictureBox1.Image == null) { select_img = false; }
                else { select_img = true; }
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        if (string.IsNullOrEmpty(row.Cells["status"].Value?.ToString())) // 이미지 삽입 시 상태를 수정으로 변경
                        {
                            row.Cells["status"].Value = "U";
                            button_status = utility.SetFuncBtn(utility.buttons, "3");
                        }
                        // 이미지 파일을 읽어와서 Image 객체로 변환
                        Image image = Image.FromFile(openFileDialog.FileName);
                        byte[] img = null;
                        // PictureBox에 이미지 출력
                        pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                        pictureBox1.Image = image;
                        FileStream fs = new FileStream(openFileDialog.FileName, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        dataGridView1.CurrentRow.Cells["image"].Value = img;
                        dataGridView1.CurrentRow.Cells["imgnam"].Value = openFileDialog.FileName;
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();
                        MessageBox.Show("이미지 로딩에 실패했습니다: " + ex.Message);
                    }
                    finally
                    {
                        if (utility.conn != null) utility.conn.Close();
                    }
                }
            }
        }
        #endregion
        private void s_bas_emp_sdate_Leave(object sender, EventArgs e)
        {
            if (s_bas_cont.Text == "계약직")
            {
                s_bas_jkpdate.Text = s_bas_emp_sdate.Text;
                s_bas_posdate.Text = s_bas_emp_sdate.Text;
                s_bas_dptdate.Text = s_bas_emp_sdate.Text;
            }
            if(s_bas_cont.Text == "정규직")
            {
                s_bas_jkpdate.Text = s_bas_entdate.Text;
                s_bas_posdate.Text = s_bas_entdate.Text;
                s_bas_dptdate.Text = s_bas_entdate.Text;
            }
        }
        #region 주민등록번호 암호화 / 복호화 (AES)
        #region 주민등록번호 암호화
        static byte[] EncryptStringToBytes_Aes(string plainText, byte[] key, byte[] iv)
        {
            byte[] encrypted;

            using (Aes aesAlg = Aes.Create())
            {
                // AES 객체 초기화
                using (var encryptor = aesAlg.CreateEncryptor(key, iv))
                {
                    // 입력값을 byte[]로 변환하여 암호화
                    using (var msEncrypt = new MemoryStream())
                    {
                        using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                        {
                            using (var swEncrypt = new StreamWriter(csEncrypt))
                            {
                                swEncrypt.Write(plainText);
                            }
                            encrypted = msEncrypt.ToArray();
                        }
                    }
                }
            }
            return encrypted;
        }
        #endregion
        #region 주민등록번호 복호화
        static string DecryptStringFromBytes_Aes(byte[] cipherText, byte[] key, byte[] iv)
        {
            string plaintext = null;
            using (Aes aesAlg = Aes.Create())
            {
                // AES 객체 초기화
                using (var decryptor = aesAlg.CreateDecryptor(key, iv))
                {
                    // 암호화된 byte[]를 복호화하여 문자열로 변환
                    using (var msDecrypt = new MemoryStream(cipherText))
                    {
                        using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (var srDecrypt = new StreamReader(csDecrypt))
                            {
                                plaintext = srDecrypt.ReadToEnd();
                            }
                        }
                    }
                }
            }            
            return plaintext;
        }
        #endregion
        #endregion
        #region 암호화 / 복호화 (ProtectedData)
        public static string Protect(string origin) //암호화
        {
            /*
            CurrentUser - 보호된 데이터가 현재 사용자에 연결되어 있음. 현재 사용자 컨텍스트에서 실행되는 스레드에서만 데이터를 보호 해제 가능.
            LocalMachine - 보호된 데이터가 컴퓨터 컨텍스트에 연결되어 있음. 컴퓨터에서 실행되는 모든 프로세스에서 데이터를 보호 해제 가능.
                           일반적으로 이 열거형 값은 신뢰되지 않는 사용자의 액세스가 허용되지 않는 서버에서 실행되는 서버 관련 애플리케이션에 사용.
            */
            var ResnoProtect = Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(origin), null, DataProtectionScope.LocalMachine));
            return ResnoProtect;
        }
        public static string UnProtect(string origin) //복호화
        {
            var ResnoUnProtect = Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(origin), null, DataProtectionScope.LocalMachine));
            return ResnoUnProtect;
        }
        #endregion
    }
}
