﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yjkSystem_ver1
{
    public partial class Login : Form
    {
        private bool chk_userid_save; //아이디 저장확인
        private string saved_userid; // 저장된 아이디
        public Login()
        {
            InitializeComponent();
        }
        #region 로그인화면이 보여질 때
        private void Login_Shown(object sender, EventArgs e)
        {
            string userid_save = ConfigurationManager.AppSettings["userid_save"]; //app.config에 저장된 userid_save를 변수에 저장 (1인지 판별하는 변수)
            if (userid_save.Equals("1"))
            {
                checkBox1.Checked = true;
                user_id.Text = ConfigurationManager.AppSettings["userid"]; //1인경우 userid를 textbox에 input
                saved_userid = user_id.Text;
                chk_userid_save = true;
                user_pwd.Focus();
            }
            else
            {
                checkBox1.Checked = false;
                chk_userid_save = false;
                user_id.Focus();
            }
        }
        #endregion
        private void Login_Load(object sender, EventArgs e)
        {
        }

        #region 로그인 버튼 기능
        private void button1_Click(object sender, EventArgs e)
        {
            if ((user_id.Text == ""))
            {
                MessageBox.Show("사용자 ID를 입력하세요.", "로그인확인", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                user_id.Focus();
                return;
            }
            if (user_pwd.Text == "")
            {
                MessageBox.Show("사용자 PW를 입력하세요.", "로그인확인", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                user_pwd.Focus();
                return;
            }
            #region 사용자ID App.config에 저장
            /*-----사용자ID 저장 여부에 변경이 있을 때------------------------*/
            bool change_check = false;
            // 1. 체크되어있지만 저장은 안되어있는경우 첫번째 if문에서 true
            // 2. 체크되어있지만 같은 아이디를 저장한 경우 두번째 if문에서 false
            // 3. 체크박스가 체크되어 있지 않는 경우 배제 두번째 if문에서 false
            if (checkBox1.Checked != chk_userid_save) 
            {
                change_check = true;
            }
            else if ((checkBox1.Checked == true) & (user_id.Text != saved_userid)) 
            {
                change_check = true;
            }

            if (change_check == true)
            {
                try
                {
                    var configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                    var settings = configFile.AppSettings.Settings;
                    settings["userid"].Value = user_id.Text;
                    settings["userid_save"].Value = checkBox1.Checked == true ? "1" : "0"; //체크박스가 체크되어있는 경우 userid_save 값 = 1 , 아닌 경우 = 0
                    configFile.Save(ConfigurationSaveMode.Modified);
                    ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            #endregion
            #region 사용자 정보 확인 후 로그인
            try
            {
                utility.conn = utility.SetOracleConnection();
                utility.cmd = utility.conn.CreateCommand();
                utility.cmd.CommandText = SQL.SQL_User.SelectSQL;
                utility.cmd.BindByName = true;
                utility.cmd.Parameters.Add("user_id", OracleDbType.Varchar2).Value = user_id.Text;
                OracleDataReader reader = utility.cmd.ExecuteReader();
                if (!reader.Read())
                {
                    MessageBox.Show("아이디가 존재하지 않습니다.", "로그인확인", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }
                if (user_pwd.Text != reader.GetString(1))
                {
                    MessageBox.Show("비밀번호가 일치하지 않습니다.", "로그인확인", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }
                utility.user_nam = (string)reader["user_nam"];
                utility.user_grant = (string)reader["user_grant"];
                Main main = new Main();
                this.Hide();
                main.ShowDialog();
                this.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                if (utility.conn != null) utility.conn.Close();
            }
            //utility.result_login = true;
            /*this.DialogResult = DialogResult.OK;
            this.Close();*/
            #endregion
        }

        #endregion
    }
}
