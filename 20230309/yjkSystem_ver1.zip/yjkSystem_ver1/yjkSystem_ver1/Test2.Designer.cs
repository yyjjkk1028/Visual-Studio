﻿
namespace yjkSystem_ver1
{
    partial class Test2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.search_pos = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.search_name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.search_code = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bas_empno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_resno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_cname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_ename = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_fix = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_zip = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_addr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_hdpno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_telno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_mil_sta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_mil_mil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_mil_rnk = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_mar = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.bas_acc_bank = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_acc_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_acc_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_cont = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_emp_sdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_emp_edate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_entdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_resdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_levdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_reidate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_dptdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_jkpdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_posdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_wsta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_pos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_dut = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_dept = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_rmk = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datasys1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.s_bas_dut = new System.Windows.Forms.ComboBox();
            this.s_bas_reidate = new System.Windows.Forms.MaskedTextBox();
            this.s_bas_emp_edate = new System.Windows.Forms.MaskedTextBox();
            this.s_bas_entdate = new System.Windows.Forms.MaskedTextBox();
            this.s_bas_levdate = new System.Windows.Forms.MaskedTextBox();
            this.s_bas_resdate = new System.Windows.Forms.MaskedTextBox();
            this.s_bas_emp_sdate = new System.Windows.Forms.MaskedTextBox();
            this.s_bas_pos = new System.Windows.Forms.ComboBox();
            this.s_bas_wsta = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.s_bas_cont = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.s_bas_mar = new System.Windows.Forms.CheckBox();
            this.s_bas_addr = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.s_bas_zip = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.s_bas_email = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.s_bas_telno = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.s_bas_fix = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.s_bas_ename = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.s_bas_name = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.s_bas_hdpno = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.s_bas_resno = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.s_bas_cname = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.s_bas_dept = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.s_bas_empno = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.s_bas_acc_bank = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.s_bas_acc_name = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.s_bas_acc_no = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.s_bas_mil_rnk = new System.Windows.Forms.ComboBox();
            this.s_bas_mil_mil = new System.Windows.Forms.ComboBox();
            this.s_bas_mil_sta = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.s_bas_rmk = new System.Windows.Forms.RichTextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.s_bas_posdate = new System.Windows.Forms.MaskedTextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.s_bas_jkpdate = new System.Windows.Forms.MaskedTextBox();
            this.s_bas_dptdate = new System.Windows.Forms.MaskedTextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.17595F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.82405F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1067, 546);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // panel1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel1, 2);
            this.panel1.Controls.Add(this.search_pos);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.search_name);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.search_code);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1059, 50);
            this.panel1.TabIndex = 4;
            // 
            // search_pos
            // 
            this.search_pos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.search_pos.FormattingEnabled = true;
            this.search_pos.Location = new System.Drawing.Point(383, 13);
            this.search_pos.Name = "search_pos";
            this.search_pos.Size = new System.Drawing.Size(95, 20);
            this.search_pos.TabIndex = 184;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(734, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(27, 22);
            this.button1.TabIndex = 9;
            this.button1.Text = "※";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(537, 13);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(189, 21);
            this.textBox2.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(502, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 2;
            this.label4.Text = "부서";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(348, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "직급";
            // 
            // search_name
            // 
            this.search_name.Location = new System.Drawing.Point(227, 13);
            this.search_name.Name = "search_name";
            this.search_name.Size = new System.Drawing.Size(100, 21);
            this.search_name.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(192, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "성명";
            // 
            // search_code
            // 
            this.search_code.Location = new System.Drawing.Point(67, 13);
            this.search_code.Name = "search_code";
            this.search_code.Size = new System.Drawing.Size(100, 21);
            this.search_code.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "사원번호";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bas_empno,
            this.bas_resno,
            this.bas_name,
            this.bas_cname,
            this.bas_ename,
            this.bas_fix,
            this.bas_zip,
            this.bas_addr,
            this.bas_hdpno,
            this.bas_telno,
            this.bas_email,
            this.bas_mil_sta,
            this.bas_mil_mil,
            this.bas_mil_rnk,
            this.bas_mar,
            this.bas_acc_bank,
            this.bas_acc_name,
            this.bas_acc_no,
            this.bas_cont,
            this.bas_emp_sdate,
            this.bas_emp_edate,
            this.bas_entdate,
            this.bas_resdate,
            this.bas_levdate,
            this.bas_reidate,
            this.bas_dptdate,
            this.bas_jkpdate,
            this.bas_posdate,
            this.bas_wsta,
            this.bas_pos,
            this.bas_dut,
            this.bas_dept,
            this.bas_rmk,
            this.datasys1,
            this.status});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(4, 55);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(421, 487);
            this.dataGridView1.TabIndex = 2;
            // 
            // bas_empno
            // 
            this.bas_empno.DataPropertyName = "bas_empno";
            this.bas_empno.HeaderText = "사원번호";
            this.bas_empno.Name = "bas_empno";
            this.bas_empno.ReadOnly = true;
            this.bas_empno.Width = 80;
            // 
            // bas_resno
            // 
            this.bas_resno.DataPropertyName = "bas_resno";
            this.bas_resno.HeaderText = "주민등록번호";
            this.bas_resno.Name = "bas_resno";
            this.bas_resno.ReadOnly = true;
            // 
            // bas_name
            // 
            this.bas_name.DataPropertyName = "bas_name";
            this.bas_name.HeaderText = "성명";
            this.bas_name.Name = "bas_name";
            this.bas_name.ReadOnly = true;
            this.bas_name.Width = 80;
            // 
            // bas_cname
            // 
            this.bas_cname.DataPropertyName = "bas_cname";
            this.bas_cname.HeaderText = "성명(한자)";
            this.bas_cname.Name = "bas_cname";
            this.bas_cname.ReadOnly = true;
            // 
            // bas_ename
            // 
            this.bas_ename.DataPropertyName = "bas_cname";
            this.bas_ename.HeaderText = "성명(영어)";
            this.bas_ename.Name = "bas_ename";
            this.bas_ename.ReadOnly = true;
            // 
            // bas_fix
            // 
            this.bas_fix.DataPropertyName = "bas_fix";
            this.bas_fix.HeaderText = "성별";
            this.bas_fix.Name = "bas_fix";
            this.bas_fix.ReadOnly = true;
            // 
            // bas_zip
            // 
            this.bas_zip.DataPropertyName = "bas_zip";
            this.bas_zip.HeaderText = "우편번호";
            this.bas_zip.Name = "bas_zip";
            this.bas_zip.ReadOnly = true;
            // 
            // bas_addr
            // 
            this.bas_addr.DataPropertyName = "bas_addr";
            this.bas_addr.HeaderText = "주소";
            this.bas_addr.Name = "bas_addr";
            this.bas_addr.ReadOnly = true;
            // 
            // bas_hdpno
            // 
            this.bas_hdpno.DataPropertyName = "bas_hdpno";
            this.bas_hdpno.HeaderText = "휴대전화";
            this.bas_hdpno.Name = "bas_hdpno";
            this.bas_hdpno.ReadOnly = true;
            // 
            // bas_telno
            // 
            this.bas_telno.DataPropertyName = "bas_telno";
            this.bas_telno.HeaderText = "집전화";
            this.bas_telno.Name = "bas_telno";
            this.bas_telno.ReadOnly = true;
            // 
            // bas_email
            // 
            this.bas_email.DataPropertyName = "bas_email";
            this.bas_email.HeaderText = "이메일";
            this.bas_email.Name = "bas_email";
            this.bas_email.ReadOnly = true;
            // 
            // bas_mil_sta
            // 
            this.bas_mil_sta.DataPropertyName = "bas_mil_sta";
            this.bas_mil_sta.HeaderText = "복무구분";
            this.bas_mil_sta.Name = "bas_mil_sta";
            this.bas_mil_sta.ReadOnly = true;
            // 
            // bas_mil_mil
            // 
            this.bas_mil_mil.DataPropertyName = "bas_mil_mil";
            this.bas_mil_mil.HeaderText = "군별";
            this.bas_mil_mil.Name = "bas_mil_mil";
            this.bas_mil_mil.ReadOnly = true;
            // 
            // bas_mil_rnk
            // 
            this.bas_mil_rnk.DataPropertyName = "bas_mil_rnk";
            this.bas_mil_rnk.HeaderText = "계급";
            this.bas_mil_rnk.Name = "bas_mil_rnk";
            this.bas_mil_rnk.ReadOnly = true;
            // 
            // bas_mar
            // 
            this.bas_mar.DataPropertyName = "bas_mar";
            this.bas_mar.HeaderText = "결혼여부";
            this.bas_mar.Name = "bas_mar";
            this.bas_mar.ReadOnly = true;
            // 
            // bas_acc_bank
            // 
            this.bas_acc_bank.DataPropertyName = "bas_acc_bank";
            this.bas_acc_bank.HeaderText = "은행명";
            this.bas_acc_bank.Name = "bas_acc_bank";
            this.bas_acc_bank.ReadOnly = true;
            // 
            // bas_acc_name
            // 
            this.bas_acc_name.DataPropertyName = "bas_acc_name";
            this.bas_acc_name.HeaderText = "예금주";
            this.bas_acc_name.Name = "bas_acc_name";
            this.bas_acc_name.ReadOnly = true;
            // 
            // bas_acc_no
            // 
            this.bas_acc_no.DataPropertyName = "bas_acc_no";
            this.bas_acc_no.HeaderText = "계좌번호";
            this.bas_acc_no.Name = "bas_acc_no";
            this.bas_acc_no.ReadOnly = true;
            // 
            // bas_cont
            // 
            this.bas_cont.DataPropertyName = "bas_cont";
            this.bas_cont.HeaderText = "계약구분";
            this.bas_cont.Name = "bas_cont";
            this.bas_cont.ReadOnly = true;
            // 
            // bas_emp_sdate
            // 
            this.bas_emp_sdate.DataPropertyName = "bas_emp_sdate";
            this.bas_emp_sdate.HeaderText = "계약시작일";
            this.bas_emp_sdate.Name = "bas_emp_sdate";
            this.bas_emp_sdate.ReadOnly = true;
            // 
            // bas_emp_edate
            // 
            this.bas_emp_edate.DataPropertyName = "bas_emp_edate";
            this.bas_emp_edate.HeaderText = "계약종료일";
            this.bas_emp_edate.Name = "bas_emp_edate";
            this.bas_emp_edate.ReadOnly = true;
            // 
            // bas_entdate
            // 
            this.bas_entdate.DataPropertyName = "bas_entdate";
            this.bas_entdate.HeaderText = "입사일자";
            this.bas_entdate.Name = "bas_entdate";
            this.bas_entdate.ReadOnly = true;
            // 
            // bas_resdate
            // 
            this.bas_resdate.DataPropertyName = "bas_resdate";
            this.bas_resdate.HeaderText = "퇴사일자";
            this.bas_resdate.Name = "bas_resdate";
            this.bas_resdate.ReadOnly = true;
            // 
            // bas_levdate
            // 
            this.bas_levdate.DataPropertyName = "bas_levdate";
            this.bas_levdate.HeaderText = "휴직일자";
            this.bas_levdate.Name = "bas_levdate";
            this.bas_levdate.ReadOnly = true;
            // 
            // bas_reidate
            // 
            this.bas_reidate.DataPropertyName = "bas_reidate";
            this.bas_reidate.HeaderText = "복직일자";
            this.bas_reidate.Name = "bas_reidate";
            this.bas_reidate.ReadOnly = true;
            // 
            // bas_dptdate
            // 
            this.bas_dptdate.DataPropertyName = "bas_dptdate";
            this.bas_dptdate.HeaderText = "현부서일자";
            this.bas_dptdate.Name = "bas_dptdate";
            this.bas_dptdate.ReadOnly = true;
            // 
            // bas_jkpdate
            // 
            this.bas_jkpdate.DataPropertyName = "bas_jkpdate";
            this.bas_jkpdate.HeaderText = "현직급일자";
            this.bas_jkpdate.Name = "bas_jkpdate";
            this.bas_jkpdate.ReadOnly = true;
            // 
            // bas_posdate
            // 
            this.bas_posdate.DataPropertyName = "bas_posdate";
            this.bas_posdate.HeaderText = "현직책일자";
            this.bas_posdate.Name = "bas_posdate";
            this.bas_posdate.ReadOnly = true;
            // 
            // bas_wsta
            // 
            this.bas_wsta.DataPropertyName = "bas_wsta";
            this.bas_wsta.HeaderText = "재직상태";
            this.bas_wsta.Name = "bas_wsta";
            this.bas_wsta.ReadOnly = true;
            // 
            // bas_pos
            // 
            this.bas_pos.DataPropertyName = "bas_pos";
            this.bas_pos.HeaderText = "직급";
            this.bas_pos.Name = "bas_pos";
            this.bas_pos.ReadOnly = true;
            this.bas_pos.Width = 80;
            // 
            // bas_dut
            // 
            this.bas_dut.DataPropertyName = "bas_dut";
            this.bas_dut.HeaderText = "직책";
            this.bas_dut.Name = "bas_dut";
            this.bas_dut.ReadOnly = true;
            // 
            // bas_dept
            // 
            this.bas_dept.DataPropertyName = "bas_dept";
            this.bas_dept.HeaderText = "부서";
            this.bas_dept.Name = "bas_dept";
            this.bas_dept.ReadOnly = true;
            this.bas_dept.Width = 150;
            // 
            // bas_rmk
            // 
            this.bas_rmk.DataPropertyName = "bas_rmk";
            this.bas_rmk.HeaderText = "참고사항";
            this.bas_rmk.Name = "bas_rmk";
            this.bas_rmk.ReadOnly = true;
            // 
            // datasys1
            // 
            this.datasys1.DataPropertyName = "datasys1";
            this.datasys1.HeaderText = "자료처리일시";
            this.datasys1.Name = "datasys1";
            this.datasys1.ReadOnly = true;
            // 
            // status
            // 
            this.status.HeaderText = "상태";
            this.status.Name = "status";
            this.status.ReadOnly = true;
            this.status.Width = 70;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 88F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label7, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel3, 1, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(432, 55);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 76.08696F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.91304F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(631, 487);
            this.tableLayoutPanel2.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(4, 316);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 98);
            this.label6.TabIndex = 2;
            this.label6.Text = "발 령 일 자";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(4, 415);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 35);
            this.label7.TabIndex = 3;
            this.label7.Text = "병 역 사 항";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(4, 451);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 35);
            this.label8.TabIndex = 4;
            this.label8.Text = "계 좌 사 항";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.panel2, 4);
            this.panel2.Controls.Add(this.s_bas_dut);
            this.panel2.Controls.Add(this.s_bas_reidate);
            this.panel2.Controls.Add(this.s_bas_emp_edate);
            this.panel2.Controls.Add(this.s_bas_entdate);
            this.panel2.Controls.Add(this.s_bas_levdate);
            this.panel2.Controls.Add(this.s_bas_resdate);
            this.panel2.Controls.Add(this.s_bas_emp_sdate);
            this.panel2.Controls.Add(this.s_bas_pos);
            this.panel2.Controls.Add(this.s_bas_wsta);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.s_bas_cont);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.s_bas_mar);
            this.panel2.Controls.Add(this.s_bas_addr);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.s_bas_zip);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.s_bas_email);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.s_bas_telno);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.s_bas_fix);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.s_bas_ename);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.s_bas_name);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Controls.Add(this.s_bas_hdpno);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.s_bas_resno);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.s_bas_cname);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.s_bas_dept);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.s_bas_empno);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(4, 2);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(623, 312);
            this.panel2.TabIndex = 5;
            // 
            // s_bas_dut
            // 
            this.s_bas_dut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.s_bas_dut.FormattingEnabled = true;
            this.s_bas_dut.Location = new System.Drawing.Point(526, 200);
            this.s_bas_dut.Name = "s_bas_dut";
            this.s_bas_dut.Size = new System.Drawing.Size(80, 20);
            this.s_bas_dut.TabIndex = 187;
            // 
            // s_bas_reidate
            // 
            this.s_bas_reidate.Location = new System.Drawing.Point(526, 280);
            this.s_bas_reidate.Mask = "0000-00-00";
            this.s_bas_reidate.Name = "s_bas_reidate";
            this.s_bas_reidate.Size = new System.Drawing.Size(80, 21);
            this.s_bas_reidate.TabIndex = 186;
            this.s_bas_reidate.ValidatingType = typeof(System.DateTime);
            // 
            // s_bas_emp_edate
            // 
            this.s_bas_emp_edate.Location = new System.Drawing.Point(526, 225);
            this.s_bas_emp_edate.Mask = "0000-00-00";
            this.s_bas_emp_edate.Name = "s_bas_emp_edate";
            this.s_bas_emp_edate.Size = new System.Drawing.Size(80, 21);
            this.s_bas_emp_edate.TabIndex = 186;
            this.s_bas_emp_edate.ValidatingType = typeof(System.DateTime);
            // 
            // s_bas_entdate
            // 
            this.s_bas_entdate.Location = new System.Drawing.Point(243, 252);
            this.s_bas_entdate.Mask = "0000-00-00";
            this.s_bas_entdate.Name = "s_bas_entdate";
            this.s_bas_entdate.Size = new System.Drawing.Size(151, 21);
            this.s_bas_entdate.TabIndex = 185;
            this.s_bas_entdate.ValidatingType = typeof(System.DateTime);
            // 
            // s_bas_levdate
            // 
            this.s_bas_levdate.Location = new System.Drawing.Point(243, 280);
            this.s_bas_levdate.Mask = "0000-00-00";
            this.s_bas_levdate.Name = "s_bas_levdate";
            this.s_bas_levdate.Size = new System.Drawing.Size(151, 21);
            this.s_bas_levdate.TabIndex = 184;
            this.s_bas_levdate.ValidatingType = typeof(System.DateTime);
            // 
            // s_bas_resdate
            // 
            this.s_bas_resdate.Location = new System.Drawing.Point(526, 253);
            this.s_bas_resdate.Mask = "0000-00-00";
            this.s_bas_resdate.Name = "s_bas_resdate";
            this.s_bas_resdate.Size = new System.Drawing.Size(80, 21);
            this.s_bas_resdate.TabIndex = 184;
            this.s_bas_resdate.ValidatingType = typeof(System.DateTime);
            // 
            // s_bas_emp_sdate
            // 
            this.s_bas_emp_sdate.Location = new System.Drawing.Point(243, 225);
            this.s_bas_emp_sdate.Mask = "0000-00-00";
            this.s_bas_emp_sdate.Name = "s_bas_emp_sdate";
            this.s_bas_emp_sdate.Size = new System.Drawing.Size(151, 21);
            this.s_bas_emp_sdate.TabIndex = 184;
            this.s_bas_emp_sdate.ValidatingType = typeof(System.DateTime);
            // 
            // s_bas_pos
            // 
            this.s_bas_pos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.s_bas_pos.FormattingEnabled = true;
            this.s_bas_pos.Location = new System.Drawing.Point(74, 199);
            this.s_bas_pos.Name = "s_bas_pos";
            this.s_bas_pos.Size = new System.Drawing.Size(77, 20);
            this.s_bas_pos.TabIndex = 183;
            // 
            // s_bas_wsta
            // 
            this.s_bas_wsta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.s_bas_wsta.FormattingEnabled = true;
            this.s_bas_wsta.Items.AddRange(new object[] {
            "",
            "재직",
            "휴직",
            "퇴직"});
            this.s_bas_wsta.Location = new System.Drawing.Point(74, 280);
            this.s_bas_wsta.Name = "s_bas_wsta";
            this.s_bas_wsta.Size = new System.Drawing.Size(78, 20);
            this.s_bas_wsta.TabIndex = 182;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(15, 284);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(53, 12);
            this.label27.TabIndex = 181;
            this.label27.Text = "재직상태";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(457, 284);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 12);
            this.label25.TabIndex = 177;
            this.label25.Text = "복직일자";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(159, 284);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(53, 12);
            this.label26.TabIndex = 178;
            this.label26.Text = "휴직일자";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(457, 257);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 173;
            this.label23.Text = "퇴사일자";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(159, 257);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(53, 12);
            this.label24.TabIndex = 174;
            this.label24.Text = "입사일자";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(457, 229);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(65, 12);
            this.label28.TabIndex = 170;
            this.label28.Text = "계약종료일";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(159, 229);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 12);
            this.label29.TabIndex = 169;
            this.label29.Text = "계약시작일";
            // 
            // s_bas_cont
            // 
            this.s_bas_cont.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.s_bas_cont.FormattingEnabled = true;
            this.s_bas_cont.Items.AddRange(new object[] {
            "",
            "계약직",
            "정규직"});
            this.s_bas_cont.Location = new System.Drawing.Point(74, 225);
            this.s_bas_cont.Name = "s_bas_cont";
            this.s_bas_cont.Size = new System.Drawing.Size(78, 20);
            this.s_bas_cont.TabIndex = 168;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(15, 229);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(53, 12);
            this.label30.TabIndex = 167;
            this.label30.Text = "계약구분";
            // 
            // s_bas_mar
            // 
            this.s_bas_mar.AutoSize = true;
            this.s_bas_mar.Location = new System.Drawing.Point(243, 95);
            this.s_bas_mar.Name = "s_bas_mar";
            this.s_bas_mar.Size = new System.Drawing.Size(15, 14);
            this.s_bas_mar.TabIndex = 166;
            this.s_bas_mar.UseVisualStyleBackColor = true;
            // 
            // s_bas_addr
            // 
            this.s_bas_addr.Location = new System.Drawing.Point(243, 172);
            this.s_bas_addr.Name = "s_bas_addr";
            this.s_bas_addr.Size = new System.Drawing.Size(363, 21);
            this.s_bas_addr.TabIndex = 165;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(159, 175);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 164;
            this.label19.Text = "주소";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(399, 144);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(27, 22);
            this.button4.TabIndex = 163;
            this.button4.Text = "※";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // s_bas_zip
            // 
            this.s_bas_zip.Location = new System.Drawing.Point(243, 144);
            this.s_bas_zip.Name = "s_bas_zip";
            this.s_bas_zip.ReadOnly = true;
            this.s_bas_zip.Size = new System.Drawing.Size(150, 21);
            this.s_bas_zip.TabIndex = 162;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(159, 149);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 161;
            this.label20.Text = "우편번호";
            // 
            // s_bas_email
            // 
            this.s_bas_email.Location = new System.Drawing.Point(243, 117);
            this.s_bas_email.Name = "s_bas_email";
            this.s_bas_email.Size = new System.Drawing.Size(151, 21);
            this.s_bas_email.TabIndex = 158;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(161, 121);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 12);
            this.label22.TabIndex = 157;
            this.label22.Text = "이메일";
            // 
            // s_bas_telno
            // 
            this.s_bas_telno.Location = new System.Drawing.Point(526, 118);
            this.s_bas_telno.Name = "s_bas_telno";
            this.s_bas_telno.Size = new System.Drawing.Size(80, 21);
            this.s_bas_telno.TabIndex = 156;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(457, 121);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 12);
            this.label16.TabIndex = 155;
            this.label16.Text = "집전화";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(159, 97);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 153;
            this.label17.Text = "결혼여부";
            // 
            // s_bas_fix
            // 
            this.s_bas_fix.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.s_bas_fix.FormattingEnabled = true;
            this.s_bas_fix.Items.AddRange(new object[] {
            "",
            "남",
            "여"});
            this.s_bas_fix.Location = new System.Drawing.Point(526, 63);
            this.s_bas_fix.Name = "s_bas_fix";
            this.s_bas_fix.Size = new System.Drawing.Size(80, 20);
            this.s_bas_fix.TabIndex = 152;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(436, 67);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 151;
            this.label18.Text = "성별";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(428, 197);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(26, 22);
            this.button3.TabIndex = 150;
            this.button3.Text = "※";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // s_bas_ename
            // 
            this.s_bas_ename.Location = new System.Drawing.Point(526, 36);
            this.s_bas_ename.Name = "s_bas_ename";
            this.s_bas_ename.Size = new System.Drawing.Size(80, 21);
            this.s_bas_ename.TabIndex = 149;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(457, 41);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 12);
            this.label13.TabIndex = 148;
            this.label13.Text = "성명(영어)";
            // 
            // s_bas_name
            // 
            this.s_bas_name.Location = new System.Drawing.Point(526, 9);
            this.s_bas_name.Name = "s_bas_name";
            this.s_bas_name.Size = new System.Drawing.Size(80, 21);
            this.s_bas_name.TabIndex = 147;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(457, 14);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 12);
            this.label15.TabIndex = 146;
            this.label15.Text = "성명(한글)";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(17, 203);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(29, 12);
            this.label31.TabIndex = 144;
            this.label31.Text = "직급";
            // 
            // s_bas_hdpno
            // 
            this.s_bas_hdpno.Location = new System.Drawing.Point(526, 90);
            this.s_bas_hdpno.Name = "s_bas_hdpno";
            this.s_bas_hdpno.Size = new System.Drawing.Size(80, 21);
            this.s_bas_hdpno.TabIndex = 141;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(457, 95);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 140;
            this.label14.Text = "휴대전화";
            // 
            // s_bas_resno
            // 
            this.s_bas_resno.Location = new System.Drawing.Point(243, 63);
            this.s_bas_resno.Name = "s_bas_resno";
            this.s_bas_resno.Size = new System.Drawing.Size(150, 21);
            this.s_bas_resno.TabIndex = 139;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(159, 68);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 138;
            this.label11.Text = "주민등록번호";
            // 
            // s_bas_cname
            // 
            this.s_bas_cname.Location = new System.Drawing.Point(243, 36);
            this.s_bas_cname.Name = "s_bas_cname";
            this.s_bas_cname.Size = new System.Drawing.Size(150, 21);
            this.s_bas_cname.TabIndex = 137;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(159, 41);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 12);
            this.label9.TabIndex = 136;
            this.label9.Text = "성명(한자)";
            // 
            // s_bas_dept
            // 
            this.s_bas_dept.Location = new System.Drawing.Point(243, 198);
            this.s_bas_dept.Name = "s_bas_dept";
            this.s_bas_dept.Size = new System.Drawing.Size(183, 21);
            this.s_bas_dept.TabIndex = 134;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(159, 203);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 132;
            this.label10.Text = "부서";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(457, 203);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 133;
            this.label12.Text = "직책";
            // 
            // s_bas_empno
            // 
            this.s_bas_empno.Location = new System.Drawing.Point(243, 9);
            this.s_bas_empno.Name = "s_bas_empno";
            this.s_bas_empno.Size = new System.Drawing.Size(150, 21);
            this.s_bas_empno.TabIndex = 83;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(159, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 82;
            this.label5.Text = "사원번호";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(2, 155);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 36);
            this.button2.TabIndex = 1;
            this.button2.Text = "이미지 불러오기";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(148, 152);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.panel3, 3);
            this.panel3.Controls.Add(this.s_bas_acc_bank);
            this.panel3.Controls.Add(this.label39);
            this.panel3.Controls.Add(this.s_bas_acc_name);
            this.panel3.Controls.Add(this.label40);
            this.panel3.Controls.Add(this.s_bas_acc_no);
            this.panel3.Controls.Add(this.label41);
            this.panel3.Controls.Add(this.s_bas_mil_rnk);
            this.panel3.Controls.Add(this.s_bas_mil_mil);
            this.panel3.Controls.Add(this.s_bas_mil_sta);
            this.panel3.Controls.Add(this.label36);
            this.panel3.Controls.Add(this.label37);
            this.panel3.Controls.Add(this.label38);
            this.panel3.Controls.Add(this.s_bas_rmk);
            this.panel3.Controls.Add(this.label35);
            this.panel3.Controls.Add(this.s_bas_posdate);
            this.panel3.Controls.Add(this.label34);
            this.panel3.Controls.Add(this.s_bas_jkpdate);
            this.panel3.Controls.Add(this.s_bas_dptdate);
            this.panel3.Controls.Add(this.label32);
            this.panel3.Controls.Add(this.label33);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(90, 316);
            this.panel3.Margin = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.panel3.Name = "panel3";
            this.tableLayoutPanel2.SetRowSpan(this.panel3, 3);
            this.panel3.Size = new System.Drawing.Size(537, 170);
            this.panel3.TabIndex = 6;
            // 
            // s_bas_acc_bank
            // 
            this.s_bas_acc_bank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.s_bas_acc_bank.FormattingEnabled = true;
            this.s_bas_acc_bank.Items.AddRange(new object[] {
            "국민은행"});
            this.s_bas_acc_bank.Location = new System.Drawing.Point(77, 143);
            this.s_bas_acc_bank.Name = "s_bas_acc_bank";
            this.s_bas_acc_bank.Size = new System.Drawing.Size(78, 20);
            this.s_bas_acc_bank.TabIndex = 206;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(10, 146);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(41, 12);
            this.label39.TabIndex = 205;
            this.label39.Text = "은행명";
            // 
            // s_bas_acc_name
            // 
            this.s_bas_acc_name.Location = new System.Drawing.Point(440, 142);
            this.s_bas_acc_name.Name = "s_bas_acc_name";
            this.s_bas_acc_name.Size = new System.Drawing.Size(80, 21);
            this.s_bas_acc_name.TabIndex = 203;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(371, 145);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(41, 12);
            this.label40.TabIndex = 201;
            this.label40.Text = "예금주";
            // 
            // s_bas_acc_no
            // 
            this.s_bas_acc_no.Location = new System.Drawing.Point(237, 142);
            this.s_bas_acc_no.Name = "s_bas_acc_no";
            this.s_bas_acc_no.Size = new System.Drawing.Size(103, 21);
            this.s_bas_acc_no.TabIndex = 204;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(166, 146);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(53, 12);
            this.label41.TabIndex = 202;
            this.label41.Text = "계좌번호";
            // 
            // s_bas_mil_rnk
            // 
            this.s_bas_mil_rnk.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.s_bas_mil_rnk.FormattingEnabled = true;
            this.s_bas_mil_rnk.Location = new System.Drawing.Point(440, 106);
            this.s_bas_mil_rnk.Name = "s_bas_mil_rnk";
            this.s_bas_mil_rnk.Size = new System.Drawing.Size(80, 20);
            this.s_bas_mil_rnk.TabIndex = 200;
            // 
            // s_bas_mil_mil
            // 
            this.s_bas_mil_mil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.s_bas_mil_mil.FormattingEnabled = true;
            this.s_bas_mil_mil.Location = new System.Drawing.Point(237, 106);
            this.s_bas_mil_mil.Name = "s_bas_mil_mil";
            this.s_bas_mil_mil.Size = new System.Drawing.Size(103, 20);
            this.s_bas_mil_mil.TabIndex = 199;
            // 
            // s_bas_mil_sta
            // 
            this.s_bas_mil_sta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.s_bas_mil_sta.FormattingEnabled = true;
            this.s_bas_mil_sta.Location = new System.Drawing.Point(77, 106);
            this.s_bas_mil_sta.Name = "s_bas_mil_sta";
            this.s_bas_mil_sta.Size = new System.Drawing.Size(78, 20);
            this.s_bas_mil_sta.TabIndex = 198;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(9, 111);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(53, 12);
            this.label36.TabIndex = 197;
            this.label36.Text = "복무구분";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(371, 111);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(29, 12);
            this.label37.TabIndex = 195;
            this.label37.Text = "계급";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(166, 111);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(29, 12);
            this.label38.TabIndex = 196;
            this.label38.Text = "군별";
            // 
            // s_bas_rmk
            // 
            this.s_bas_rmk.Location = new System.Drawing.Point(77, 49);
            this.s_bas_rmk.Name = "s_bas_rmk";
            this.s_bas_rmk.Size = new System.Drawing.Size(443, 45);
            this.s_bas_rmk.TabIndex = 194;
            this.s_bas_rmk.Text = "";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(9, 52);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(53, 12);
            this.label35.TabIndex = 193;
            this.label35.Text = "참고사항";
            // 
            // s_bas_posdate
            // 
            this.s_bas_posdate.Location = new System.Drawing.Point(440, 14);
            this.s_bas_posdate.Mask = "0000-00-00";
            this.s_bas_posdate.Name = "s_bas_posdate";
            this.s_bas_posdate.Size = new System.Drawing.Size(80, 21);
            this.s_bas_posdate.TabIndex = 192;
            this.s_bas_posdate.ValidatingType = typeof(System.DateTime);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(371, 18);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(65, 12);
            this.label34.TabIndex = 191;
            this.label34.Text = "현직책일자";
            // 
            // s_bas_jkpdate
            // 
            this.s_bas_jkpdate.Location = new System.Drawing.Point(77, 14);
            this.s_bas_jkpdate.Mask = "0000-00-00";
            this.s_bas_jkpdate.Name = "s_bas_jkpdate";
            this.s_bas_jkpdate.Size = new System.Drawing.Size(78, 21);
            this.s_bas_jkpdate.TabIndex = 190;
            this.s_bas_jkpdate.ValidatingType = typeof(System.DateTime);
            // 
            // s_bas_dptdate
            // 
            this.s_bas_dptdate.Location = new System.Drawing.Point(237, 15);
            this.s_bas_dptdate.Mask = "0000-00-00";
            this.s_bas_dptdate.Name = "s_bas_dptdate";
            this.s_bas_dptdate.Size = new System.Drawing.Size(103, 21);
            this.s_bas_dptdate.TabIndex = 189;
            this.s_bas_dptdate.ValidatingType = typeof(System.DateTime);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(9, 18);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(65, 12);
            this.label32.TabIndex = 187;
            this.label32.Text = "현직급일자";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(166, 18);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(65, 12);
            this.label33.TabIndex = 188;
            this.label33.Text = "현부서일자";
            // 
            // Test2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 546);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Test2";
            this.Text = "Test2";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox search_pos;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox search_name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox search_code;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_empno;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_resno;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_cname;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_ename;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_fix;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_zip;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_addr;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_hdpno;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_telno;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_email;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_mil_sta;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_mil_mil;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_mil_rnk;
        private System.Windows.Forms.DataGridViewCheckBoxColumn bas_mar;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_acc_bank;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_acc_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_acc_no;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_cont;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_emp_sdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_emp_edate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_entdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_resdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_levdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_reidate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_dptdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_jkpdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_posdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_wsta;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_pos;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_dut;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_dept;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_rmk;
        private System.Windows.Forms.DataGridViewTextBoxColumn datasys1;
        private System.Windows.Forms.DataGridViewTextBoxColumn status;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox s_bas_dut;
        private System.Windows.Forms.MaskedTextBox s_bas_reidate;
        private System.Windows.Forms.MaskedTextBox s_bas_emp_edate;
        private System.Windows.Forms.MaskedTextBox s_bas_entdate;
        private System.Windows.Forms.MaskedTextBox s_bas_levdate;
        private System.Windows.Forms.MaskedTextBox s_bas_resdate;
        private System.Windows.Forms.MaskedTextBox s_bas_emp_sdate;
        private System.Windows.Forms.ComboBox s_bas_pos;
        private System.Windows.Forms.ComboBox s_bas_wsta;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox s_bas_cont;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.CheckBox s_bas_mar;
        private System.Windows.Forms.TextBox s_bas_addr;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox s_bas_zip;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox s_bas_email;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox s_bas_telno;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox s_bas_fix;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox s_bas_ename;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox s_bas_name;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox s_bas_hdpno;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox s_bas_resno;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox s_bas_cname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox s_bas_dept;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox s_bas_empno;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox s_bas_acc_bank;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox s_bas_acc_name;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox s_bas_acc_no;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox s_bas_mil_rnk;
        private System.Windows.Forms.ComboBox s_bas_mil_mil;
        private System.Windows.Forms.ComboBox s_bas_mil_sta;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.RichTextBox s_bas_rmk;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.MaskedTextBox s_bas_posdate;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.MaskedTextBox s_bas_jkpdate;
        private System.Windows.Forms.MaskedTextBox s_bas_dptdate;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
    }
}