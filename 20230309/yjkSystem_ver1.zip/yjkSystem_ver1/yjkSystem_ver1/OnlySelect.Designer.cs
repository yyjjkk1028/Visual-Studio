﻿
namespace yjkSystem_ver1
{
    partial class OnlySelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bas_empno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_resno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_cname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_ename = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_fix = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_zip = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_addr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_hdpno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_telno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sub_email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_mil_sta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_mil_mil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_mil_rnk = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_mar = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.bas_acc_bank = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_acc_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_acc_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_cont = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_emp_sdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_emp_edate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_entdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_resdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_levdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_reidate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_dptdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_jkpdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_posdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_wsta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_pos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_dut = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_dept = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_rmk = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datasys1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.image = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.search_pos = new System.Windows.Forms.ComboBox();
            this.sd_btn1 = new System.Windows.Forms.Button();
            this.search_dept = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.search_name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.search_code = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 523F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1080, 567);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.search_pos);
            this.panel1.Controls.Add(this.sd_btn1);
            this.panel1.Controls.Add(this.search_dept);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.search_name);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.search_code);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1072, 44);
            this.panel1.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bas_empno,
            this.bas_resno,
            this.bas_name,
            this.bas_cname,
            this.bas_ename,
            this.bas_fix,
            this.bas_zip,
            this.bas_addr,
            this.bas_hdpno,
            this.bas_telno,
            this.bas_email,
            this.sub_email,
            this.bas_mil_sta,
            this.bas_mil_mil,
            this.bas_mil_rnk,
            this.bas_mar,
            this.bas_acc_bank,
            this.bas_acc_name,
            this.bas_acc_no,
            this.bas_cont,
            this.bas_emp_sdate,
            this.bas_emp_edate,
            this.bas_entdate,
            this.bas_resdate,
            this.bas_levdate,
            this.bas_reidate,
            this.bas_dptdate,
            this.bas_jkpdate,
            this.bas_posdate,
            this.bas_wsta,
            this.bas_pos,
            this.bas_dut,
            this.bas_dept,
            this.bas_rmk,
            this.datasys1,
            this.status,
            this.image});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(4, 55);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1072, 517);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.TabStop = false;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // bas_empno
            // 
            this.bas_empno.DataPropertyName = "bas_empno";
            this.bas_empno.HeaderText = "사원번호";
            this.bas_empno.Name = "bas_empno";
            this.bas_empno.ReadOnly = true;
            this.bas_empno.Width = 80;
            // 
            // bas_resno
            // 
            this.bas_resno.DataPropertyName = "bas_resno";
            this.bas_resno.HeaderText = "주민등록번호";
            this.bas_resno.Name = "bas_resno";
            this.bas_resno.ReadOnly = true;
            // 
            // bas_name
            // 
            this.bas_name.DataPropertyName = "bas_name";
            this.bas_name.HeaderText = "성명";
            this.bas_name.Name = "bas_name";
            this.bas_name.ReadOnly = true;
            this.bas_name.Width = 80;
            // 
            // bas_cname
            // 
            this.bas_cname.DataPropertyName = "bas_cname";
            this.bas_cname.HeaderText = "성명(한자)";
            this.bas_cname.Name = "bas_cname";
            this.bas_cname.ReadOnly = true;
            // 
            // bas_ename
            // 
            this.bas_ename.DataPropertyName = "bas_cname";
            this.bas_ename.HeaderText = "성명(영어)";
            this.bas_ename.Name = "bas_ename";
            this.bas_ename.ReadOnly = true;
            // 
            // bas_fix
            // 
            this.bas_fix.DataPropertyName = "bas_fix";
            this.bas_fix.HeaderText = "성별";
            this.bas_fix.Name = "bas_fix";
            this.bas_fix.ReadOnly = true;
            // 
            // bas_zip
            // 
            this.bas_zip.DataPropertyName = "bas_zip";
            this.bas_zip.HeaderText = "우편번호";
            this.bas_zip.Name = "bas_zip";
            this.bas_zip.ReadOnly = true;
            // 
            // bas_addr
            // 
            this.bas_addr.DataPropertyName = "bas_addr";
            this.bas_addr.HeaderText = "주소";
            this.bas_addr.Name = "bas_addr";
            this.bas_addr.ReadOnly = true;
            // 
            // bas_hdpno
            // 
            this.bas_hdpno.DataPropertyName = "bas_hdpno";
            this.bas_hdpno.HeaderText = "휴대전화";
            this.bas_hdpno.Name = "bas_hdpno";
            this.bas_hdpno.ReadOnly = true;
            // 
            // bas_telno
            // 
            this.bas_telno.DataPropertyName = "bas_telno";
            this.bas_telno.HeaderText = "집전화";
            this.bas_telno.Name = "bas_telno";
            this.bas_telno.ReadOnly = true;
            // 
            // bas_email
            // 
            this.bas_email.DataPropertyName = "bas_email";
            this.bas_email.HeaderText = "이메일";
            this.bas_email.Name = "bas_email";
            this.bas_email.ReadOnly = true;
            // 
            // sub_email
            // 
            this.sub_email.DataPropertyName = "sub_email";
            this.sub_email.HeaderText = "이메일2";
            this.sub_email.Name = "sub_email";
            this.sub_email.ReadOnly = true;
            // 
            // bas_mil_sta
            // 
            this.bas_mil_sta.DataPropertyName = "bas_mil_sta";
            this.bas_mil_sta.HeaderText = "복무구분";
            this.bas_mil_sta.Name = "bas_mil_sta";
            this.bas_mil_sta.ReadOnly = true;
            // 
            // bas_mil_mil
            // 
            this.bas_mil_mil.DataPropertyName = "bas_mil_mil";
            this.bas_mil_mil.HeaderText = "군별";
            this.bas_mil_mil.Name = "bas_mil_mil";
            this.bas_mil_mil.ReadOnly = true;
            // 
            // bas_mil_rnk
            // 
            this.bas_mil_rnk.DataPropertyName = "bas_mil_rnk";
            this.bas_mil_rnk.HeaderText = "계급";
            this.bas_mil_rnk.Name = "bas_mil_rnk";
            this.bas_mil_rnk.ReadOnly = true;
            // 
            // bas_mar
            // 
            this.bas_mar.DataPropertyName = "bas_mar";
            this.bas_mar.FalseValue = "N";
            this.bas_mar.HeaderText = "결혼여부";
            this.bas_mar.Name = "bas_mar";
            this.bas_mar.ReadOnly = true;
            this.bas_mar.TrueValue = "Y";
            // 
            // bas_acc_bank
            // 
            this.bas_acc_bank.DataPropertyName = "bas_acc_bank";
            this.bas_acc_bank.HeaderText = "은행명";
            this.bas_acc_bank.Name = "bas_acc_bank";
            this.bas_acc_bank.ReadOnly = true;
            // 
            // bas_acc_name
            // 
            this.bas_acc_name.DataPropertyName = "bas_acc_name";
            this.bas_acc_name.HeaderText = "예금주";
            this.bas_acc_name.Name = "bas_acc_name";
            this.bas_acc_name.ReadOnly = true;
            // 
            // bas_acc_no
            // 
            this.bas_acc_no.DataPropertyName = "bas_acc_no";
            this.bas_acc_no.HeaderText = "계좌번호";
            this.bas_acc_no.Name = "bas_acc_no";
            this.bas_acc_no.ReadOnly = true;
            // 
            // bas_cont
            // 
            this.bas_cont.DataPropertyName = "bas_cont";
            this.bas_cont.HeaderText = "계약구분";
            this.bas_cont.Name = "bas_cont";
            this.bas_cont.ReadOnly = true;
            // 
            // bas_emp_sdate
            // 
            this.bas_emp_sdate.DataPropertyName = "bas_emp_sdate";
            this.bas_emp_sdate.HeaderText = "계약시작일";
            this.bas_emp_sdate.Name = "bas_emp_sdate";
            this.bas_emp_sdate.ReadOnly = true;
            // 
            // bas_emp_edate
            // 
            this.bas_emp_edate.DataPropertyName = "bas_emp_edate";
            this.bas_emp_edate.HeaderText = "계약종료일";
            this.bas_emp_edate.Name = "bas_emp_edate";
            this.bas_emp_edate.ReadOnly = true;
            // 
            // bas_entdate
            // 
            this.bas_entdate.DataPropertyName = "bas_entdate";
            this.bas_entdate.HeaderText = "입사일자";
            this.bas_entdate.Name = "bas_entdate";
            this.bas_entdate.ReadOnly = true;
            // 
            // bas_resdate
            // 
            this.bas_resdate.DataPropertyName = "bas_resdate";
            this.bas_resdate.HeaderText = "퇴사일자";
            this.bas_resdate.Name = "bas_resdate";
            this.bas_resdate.ReadOnly = true;
            // 
            // bas_levdate
            // 
            this.bas_levdate.DataPropertyName = "bas_levdate";
            this.bas_levdate.HeaderText = "휴직일자";
            this.bas_levdate.Name = "bas_levdate";
            this.bas_levdate.ReadOnly = true;
            // 
            // bas_reidate
            // 
            this.bas_reidate.DataPropertyName = "bas_reidate";
            this.bas_reidate.HeaderText = "복직일자";
            this.bas_reidate.Name = "bas_reidate";
            this.bas_reidate.ReadOnly = true;
            // 
            // bas_dptdate
            // 
            this.bas_dptdate.DataPropertyName = "bas_dptdate";
            this.bas_dptdate.HeaderText = "현부서일자";
            this.bas_dptdate.Name = "bas_dptdate";
            this.bas_dptdate.ReadOnly = true;
            // 
            // bas_jkpdate
            // 
            this.bas_jkpdate.DataPropertyName = "bas_jkpdate";
            this.bas_jkpdate.HeaderText = "현직급일자";
            this.bas_jkpdate.Name = "bas_jkpdate";
            this.bas_jkpdate.ReadOnly = true;
            // 
            // bas_posdate
            // 
            this.bas_posdate.DataPropertyName = "bas_posdate";
            this.bas_posdate.HeaderText = "현직책일자";
            this.bas_posdate.Name = "bas_posdate";
            this.bas_posdate.ReadOnly = true;
            // 
            // bas_wsta
            // 
            this.bas_wsta.DataPropertyName = "bas_wsta";
            this.bas_wsta.HeaderText = "재직상태";
            this.bas_wsta.Name = "bas_wsta";
            this.bas_wsta.ReadOnly = true;
            // 
            // bas_pos
            // 
            this.bas_pos.DataPropertyName = "bas_pos";
            this.bas_pos.HeaderText = "직급";
            this.bas_pos.Name = "bas_pos";
            this.bas_pos.ReadOnly = true;
            this.bas_pos.Width = 80;
            // 
            // bas_dut
            // 
            this.bas_dut.DataPropertyName = "bas_dut";
            this.bas_dut.HeaderText = "직책";
            this.bas_dut.Name = "bas_dut";
            this.bas_dut.ReadOnly = true;
            // 
            // bas_dept
            // 
            this.bas_dept.DataPropertyName = "bas_dept";
            this.bas_dept.HeaderText = "부서";
            this.bas_dept.Name = "bas_dept";
            this.bas_dept.ReadOnly = true;
            this.bas_dept.Width = 150;
            // 
            // bas_rmk
            // 
            this.bas_rmk.DataPropertyName = "bas_rmk";
            this.bas_rmk.HeaderText = "참고사항";
            this.bas_rmk.Name = "bas_rmk";
            this.bas_rmk.ReadOnly = true;
            // 
            // datasys1
            // 
            this.datasys1.DataPropertyName = "datasys1";
            this.datasys1.HeaderText = "자료처리일시";
            this.datasys1.Name = "datasys1";
            this.datasys1.ReadOnly = true;
            // 
            // status
            // 
            this.status.DataPropertyName = "status";
            this.status.HeaderText = "상태";
            this.status.Name = "status";
            this.status.ReadOnly = true;
            this.status.Width = 70;
            // 
            // image
            // 
            this.image.DataPropertyName = "image";
            this.image.HeaderText = "이미지";
            this.image.Name = "image";
            this.image.ReadOnly = true;
            // 
            // search_pos
            // 
            this.search_pos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.search_pos.FormattingEnabled = true;
            this.search_pos.Location = new System.Drawing.Point(402, 11);
            this.search_pos.Name = "search_pos";
            this.search_pos.Size = new System.Drawing.Size(95, 20);
            this.search_pos.TabIndex = 12;
            // 
            // sd_btn1
            // 
            this.sd_btn1.Location = new System.Drawing.Point(751, 11);
            this.sd_btn1.Name = "sd_btn1";
            this.sd_btn1.Size = new System.Drawing.Size(24, 22);
            this.sd_btn1.TabIndex = 14;
            this.sd_btn1.Text = "🍳";
            this.sd_btn1.UseVisualStyleBackColor = true;
            this.sd_btn1.Click += new System.EventHandler(this.sd_btn1_Click);
            // 
            // search_dept
            // 
            this.search_dept.Location = new System.Drawing.Point(556, 11);
            this.search_dept.Name = "search_dept";
            this.search_dept.Size = new System.Drawing.Size(189, 21);
            this.search_dept.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(521, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "부서";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(367, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 9;
            this.label3.Text = "직급";
            // 
            // search_name
            // 
            this.search_name.Location = new System.Drawing.Point(241, 11);
            this.search_name.Name = "search_name";
            this.search_name.Size = new System.Drawing.Size(100, 21);
            this.search_name.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(206, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 11;
            this.label2.Text = "성명";
            // 
            // search_code
            // 
            this.search_code.Location = new System.Drawing.Point(86, 11);
            this.search_code.Name = "search_code";
            this.search_code.Size = new System.Drawing.Size(100, 21);
            this.search_code.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "사원번호";
            // 
            // OnlySelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1084, 571);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "OnlySelect";
            this.Padding = new System.Windows.Forms.Padding(2);
            this.Text = "OnlySelect";
            this.Load += new System.EventHandler(this.OnlySelect_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_empno;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_resno;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_cname;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_ename;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_fix;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_zip;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_addr;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_hdpno;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_telno;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_email;
        private System.Windows.Forms.DataGridViewTextBoxColumn sub_email;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_mil_sta;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_mil_mil;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_mil_rnk;
        private System.Windows.Forms.DataGridViewCheckBoxColumn bas_mar;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_acc_bank;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_acc_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_acc_no;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_cont;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_emp_sdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_emp_edate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_entdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_resdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_levdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_reidate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_dptdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_jkpdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_posdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_wsta;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_pos;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_dut;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_dept;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_rmk;
        private System.Windows.Forms.DataGridViewTextBoxColumn datasys1;
        private System.Windows.Forms.DataGridViewTextBoxColumn status;
        private System.Windows.Forms.DataGridViewTextBoxColumn image;
        private System.Windows.Forms.ComboBox search_pos;
        private System.Windows.Forms.Button sd_btn1;
        private System.Windows.Forms.TextBox search_dept;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox search_name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox search_code;
        private System.Windows.Forms.Label label1;
    }
}