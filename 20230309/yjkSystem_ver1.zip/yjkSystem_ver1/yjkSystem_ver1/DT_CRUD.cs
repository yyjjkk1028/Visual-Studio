﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace yjkSystem_ver1
{
    
    public partial class DT_CRUD : Form
    {
        public string sql;
        public DT_CRUD()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            /*sql = SQL.SQL_Dept.SelectSQL;
            if (ShowSearchCDWindow(sql, "프로그램코드", out string result) == true)
            {
                textBox1.Text = result;
            }*/
        }
        /*static public bool ShowSearchCDWindow(string sql, string caption, out string result)
        {
            var win = new Search_Dept(sql);
            //var win = new SearchDept(sql);
            win.Text = caption;
            if (win.ShowDialog() == DialogResult.OK)
            {
                result = win.GetResult;
                win.Dispose();
                return true;
            }
            else
            {
                result = "";
                win.Dispose();
                return false;
            }
        }*/

        private void button3_Click(object sender, EventArgs e)
        {
            System.Threading.Thread.Sleep(500);

            SendKeys.Send("{PRTSC}");
            Image img = Clipboard.GetImage();

            pictureBox1.Image = img;
        }
    }
}
