﻿
namespace yjkSystem_ver1
{
    partial class GroupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.search_name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.search_code = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cdg_grpcd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cdg_grpnm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cdg_digit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cod_length = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cdg_use = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.input_panel = new System.Windows.Forms.Panel();
            this.s_cod_length = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.s_cdg_use = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.s_cdg_digit = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.s_cdg_grpnm = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.s_cdg_grpcd = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.input_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // errorProvider1
            // 
            this.errorProvider1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errorProvider1.ContainerControl = this;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.64356F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.35643F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.input_panel, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1024, 522);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // panel1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel1, 2);
            this.panel1.Controls.Add(this.search_name);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.search_code);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1016, 50);
            this.panel1.TabIndex = 4;
            // 
            // search_name
            // 
            this.search_name.Location = new System.Drawing.Point(265, 13);
            this.search_name.Name = "search_name";
            this.search_name.Size = new System.Drawing.Size(100, 21);
            this.search_name.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(194, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "그룹코드명";
            // 
            // search_code
            // 
            this.search_code.Location = new System.Drawing.Point(67, 13);
            this.search_code.Name = "search_code";
            this.search_code.Size = new System.Drawing.Size(100, 21);
            this.search_code.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "그룹코드";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cdg_grpcd,
            this.cdg_grpnm,
            this.cdg_digit,
            this.cod_length,
            this.cdg_use,
            this.status});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(4, 55);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(664, 463);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dataGridView1_RowsRemoved);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // cdg_grpcd
            // 
            this.cdg_grpcd.DataPropertyName = "cdg_grpcd";
            this.cdg_grpcd.HeaderText = "그룹코드";
            this.cdg_grpcd.Name = "cdg_grpcd";
            this.cdg_grpcd.ReadOnly = true;
            // 
            // cdg_grpnm
            // 
            this.cdg_grpnm.DataPropertyName = "cdg_grpnm";
            this.cdg_grpnm.HeaderText = "그룹코드명";
            this.cdg_grpnm.Name = "cdg_grpnm";
            this.cdg_grpnm.ReadOnly = true;
            // 
            // cdg_digit
            // 
            this.cdg_digit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cdg_digit.DataPropertyName = "cdg_digit";
            this.cdg_digit.HeaderText = "(단위)코드 길이";
            this.cdg_digit.MinimumWidth = 120;
            this.cdg_digit.Name = "cdg_digit";
            this.cdg_digit.ReadOnly = true;
            // 
            // cod_length
            // 
            this.cod_length.DataPropertyName = "cod_length";
            this.cod_length.HeaderText = "(단위)코드명 길이";
            this.cod_length.Name = "cod_length";
            this.cod_length.ReadOnly = true;
            this.cod_length.Width = 150;
            // 
            // cdg_use
            // 
            this.cdg_use.DataPropertyName = "cdg_use";
            this.cdg_use.FalseValue = "N";
            this.cdg_use.HeaderText = "사용여부";
            this.cdg_use.Name = "cdg_use";
            this.cdg_use.ReadOnly = true;
            this.cdg_use.TrueValue = "Y";
            this.cdg_use.Width = 80;
            // 
            // status
            // 
            this.status.HeaderText = "상태";
            this.status.Name = "status";
            this.status.ReadOnly = true;
            this.status.Width = 70;
            // 
            // input_panel
            // 
            this.input_panel.Controls.Add(this.s_cod_length);
            this.input_panel.Controls.Add(this.label7);
            this.input_panel.Controls.Add(this.s_cdg_use);
            this.input_panel.Controls.Add(this.label6);
            this.input_panel.Controls.Add(this.s_cdg_digit);
            this.input_panel.Controls.Add(this.label5);
            this.input_panel.Controls.Add(this.s_cdg_grpnm);
            this.input_panel.Controls.Add(this.label4);
            this.input_panel.Controls.Add(this.s_cdg_grpcd);
            this.input_panel.Controls.Add(this.label3);
            this.input_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.input_panel.Location = new System.Drawing.Point(675, 55);
            this.input_panel.Name = "input_panel";
            this.input_panel.Size = new System.Drawing.Size(345, 463);
            this.input_panel.TabIndex = 5;
            // 
            // s_cod_length
            // 
            this.s_cod_length.Location = new System.Drawing.Point(136, 138);
            this.s_cod_length.Name = "s_cod_length";
            this.s_cod_length.Size = new System.Drawing.Size(174, 21);
            this.s_cod_length.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(26, 143);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 12);
            this.label7.TabIndex = 10;
            this.label7.Text = "(단위)코드명 길이";
            // 
            // s_cdg_use
            // 
            this.s_cdg_use.AutoSize = true;
            this.s_cdg_use.Location = new System.Drawing.Point(136, 176);
            this.s_cdg_use.Name = "s_cdg_use";
            this.s_cdg_use.Size = new System.Drawing.Size(15, 14);
            this.s_cdg_use.TabIndex = 9;
            this.s_cdg_use.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 178);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "사용여부";
            // 
            // s_cdg_digit
            // 
            this.s_cdg_digit.Location = new System.Drawing.Point(136, 100);
            this.s_cdg_digit.Name = "s_cdg_digit";
            this.s_cdg_digit.Size = new System.Drawing.Size(174, 21);
            this.s_cdg_digit.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(26, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 12);
            this.label5.TabIndex = 6;
            this.label5.Text = "(단위)코드 길이";
            // 
            // s_cdg_grpnm
            // 
            this.s_cdg_grpnm.Location = new System.Drawing.Point(136, 63);
            this.s_cdg_grpnm.Name = "s_cdg_grpnm";
            this.s_cdg_grpnm.Size = new System.Drawing.Size(174, 21);
            this.s_cdg_grpnm.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "그룹코드명";
            // 
            // s_cdg_grpcd
            // 
            this.s_cdg_grpcd.Location = new System.Drawing.Point(136, 26);
            this.s_cdg_grpcd.MaxLength = 3;
            this.s_cdg_grpcd.Name = "s_cdg_grpcd";
            this.s_cdg_grpcd.Size = new System.Drawing.Size(174, 21);
            this.s_cdg_grpcd.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "그룹코드";
            // 
            // GroupForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 522);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "GroupForm";
            this.Text = "GroupForm";
            this.Load += new System.EventHandler(this.GroupForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.input_panel.ResumeLayout(false);
            this.input_panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox search_name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox search_code;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdg_grpcd;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdg_grpnm;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdg_digit;
        private System.Windows.Forms.DataGridViewTextBoxColumn cod_length;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cdg_use;
        private System.Windows.Forms.DataGridViewTextBoxColumn status;
        private System.Windows.Forms.Panel input_panel;
        private System.Windows.Forms.TextBox s_cod_length;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox s_cdg_use;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox s_cdg_digit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox s_cdg_grpnm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox s_cdg_grpcd;
        private System.Windows.Forms.Label label3;
    }
}