﻿
namespace yjkSystem_ver1
{
    partial class Test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.search_gcode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cdg_grpcd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cdg_grpnm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cdg_digit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cod_length = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.input_panel = new System.Windows.Forms.Panel();
            this.s_u_seq = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.s_u_use = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.s_u_nm2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.s_u_nm1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.s_u_cod = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.u_cod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.u_nm1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.u_nm2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.u_seq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.u_use = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.input_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.29792F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75.70207F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 273F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.input_panel, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.dataGridView2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 234F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1091, 527);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.search_gcode);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(191, 50);
            this.panel1.TabIndex = 4;
            // 
            // search_gcode
            // 
            this.search_gcode.Location = new System.Drawing.Point(84, 13);
            this.search_gcode.Name = "search_gcode";
            this.search_gcode.Size = new System.Drawing.Size(96, 21);
            this.search_gcode.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "그룹코드(명)";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cdg_grpcd,
            this.cdg_grpnm,
            this.cdg_digit,
            this.cod_length});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(4, 55);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 20;
            this.tableLayoutPanel1.SetRowSpan(this.dataGridView1, 2);
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(191, 468);
            this.dataGridView1.TabIndex = 2;
            // 
            // cdg_grpcd
            // 
            this.cdg_grpcd.DataPropertyName = "cdg_grpcd";
            this.cdg_grpcd.HeaderText = "그룹코드";
            this.cdg_grpcd.Name = "cdg_grpcd";
            this.cdg_grpcd.ReadOnly = true;
            this.cdg_grpcd.Width = 80;
            // 
            // cdg_grpnm
            // 
            this.cdg_grpnm.DataPropertyName = "cdg_grpnm";
            this.cdg_grpnm.HeaderText = "그룹코드명";
            this.cdg_grpnm.Name = "cdg_grpnm";
            this.cdg_grpnm.ReadOnly = true;
            // 
            // cdg_digit
            // 
            this.cdg_digit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cdg_digit.DataPropertyName = "cdg_digit";
            this.cdg_digit.HeaderText = "(단위)코드 길이";
            this.cdg_digit.MinimumWidth = 120;
            this.cdg_digit.Name = "cdg_digit";
            this.cdg_digit.ReadOnly = true;
            this.cdg_digit.Visible = false;
            // 
            // cod_length
            // 
            this.cod_length.DataPropertyName = "cod_length";
            this.cod_length.HeaderText = "(단위)코드명 길이";
            this.cod_length.Name = "cod_length";
            this.cod_length.ReadOnly = true;
            this.cod_length.Visible = false;
            this.cod_length.Width = 130;
            // 
            // input_panel
            // 
            this.input_panel.Controls.Add(this.s_u_seq);
            this.input_panel.Controls.Add(this.label7);
            this.input_panel.Controls.Add(this.s_u_use);
            this.input_panel.Controls.Add(this.label6);
            this.input_panel.Controls.Add(this.s_u_nm2);
            this.input_panel.Controls.Add(this.label5);
            this.input_panel.Controls.Add(this.s_u_nm1);
            this.input_panel.Controls.Add(this.label4);
            this.input_panel.Controls.Add(this.s_u_cod);
            this.input_panel.Controls.Add(this.label3);
            this.input_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.input_panel.Location = new System.Drawing.Point(819, 55);
            this.input_panel.Name = "input_panel";
            this.tableLayoutPanel1.SetRowSpan(this.input_panel, 2);
            this.input_panel.Size = new System.Drawing.Size(268, 468);
            this.input_panel.TabIndex = 5;
            // 
            // s_u_seq
            // 
            this.s_u_seq.Location = new System.Drawing.Point(120, 152);
            this.s_u_seq.Name = "s_u_seq";
            this.s_u_seq.Size = new System.Drawing.Size(131, 21);
            this.s_u_seq.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 157);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 12);
            this.label7.TabIndex = 10;
            this.label7.Text = "코드SEQ";
            // 
            // s_u_use
            // 
            this.s_u_use.AutoSize = true;
            this.s_u_use.Location = new System.Drawing.Point(120, 190);
            this.s_u_use.Name = "s_u_use";
            this.s_u_use.Size = new System.Drawing.Size(15, 14);
            this.s_u_use.TabIndex = 9;
            this.s_u_use.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "사용여부";
            // 
            // s_u_nm2
            // 
            this.s_u_nm2.Location = new System.Drawing.Point(120, 114);
            this.s_u_nm2.Name = "s_u_nm2";
            this.s_u_nm2.Size = new System.Drawing.Size(131, 21);
            this.s_u_nm2.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 12);
            this.label5.TabIndex = 6;
            this.label5.Text = "코드명(축약)";
            // 
            // s_u_nm1
            // 
            this.s_u_nm1.Location = new System.Drawing.Point(120, 77);
            this.s_u_nm1.Name = "s_u_nm1";
            this.s_u_nm1.Size = new System.Drawing.Size(131, 21);
            this.s_u_nm1.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "코드명(상세)";
            // 
            // s_u_cod
            // 
            this.s_u_cod.Location = new System.Drawing.Point(120, 40);
            this.s_u_cod.MaxLength = 3;
            this.s_u_cod.Name = "s_u_cod";
            this.s_u_cod.Size = new System.Drawing.Size(131, 21);
            this.s_u_cod.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "단위코드";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.u_cod,
            this.u_nm1,
            this.u_nm2,
            this.u_seq,
            this.u_use,
            this.status});
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(202, 55);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 20;
            this.tableLayoutPanel1.SetRowSpan(this.dataGridView2, 2);
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(610, 468);
            this.dataGridView2.TabIndex = 6;
            // 
            // u_cod
            // 
            this.u_cod.DataPropertyName = "u_cod";
            this.u_cod.HeaderText = "단위코드";
            this.u_cod.Name = "u_cod";
            this.u_cod.ReadOnly = true;
            this.u_cod.Width = 80;
            // 
            // u_nm1
            // 
            this.u_nm1.DataPropertyName = "u_nm1";
            this.u_nm1.HeaderText = "코드명(상세)";
            this.u_nm1.Name = "u_nm1";
            this.u_nm1.ReadOnly = true;
            this.u_nm1.Width = 150;
            // 
            // u_nm2
            // 
            this.u_nm2.DataPropertyName = "u_nm2";
            this.u_nm2.HeaderText = "코드명";
            this.u_nm2.Name = "u_nm2";
            this.u_nm2.ReadOnly = true;
            this.u_nm2.Width = 110;
            // 
            // u_seq
            // 
            this.u_seq.DataPropertyName = "u_seq";
            this.u_seq.HeaderText = "코드SEQ";
            this.u_seq.Name = "u_seq";
            this.u_seq.ReadOnly = true;
            this.u_seq.Width = 90;
            // 
            // u_use
            // 
            this.u_use.DataPropertyName = "u_use";
            this.u_use.FalseValue = "N";
            this.u_use.HeaderText = "사용여부";
            this.u_use.Name = "u_use";
            this.u_use.ReadOnly = true;
            this.u_use.TrueValue = "Y";
            this.u_use.Width = 80;
            // 
            // status
            // 
            this.status.HeaderText = "상태";
            this.status.Name = "status";
            this.status.ReadOnly = true;
            this.status.Width = 70;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(202, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(610, 44);
            this.panel2.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Image = global::yjkSystem_ver1.Properties.Resources.search;
            this.button1.Location = new System.Drawing.Point(386, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(41, 36);
            this.button1.TabIndex = 8;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(221, 10);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(149, 21);
            this.textBox1.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(175, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 6;
            this.label8.Text = "코드명";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(67, 10);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(85, 21);
            this.textBox2.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 4;
            this.label9.Text = "단위코드";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(819, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(268, 44);
            this.panel3.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(120, 12);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(131, 21);
            this.textBox3.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 12);
            this.label10.TabIndex = 4;
            this.label10.Text = "그룹코드정보";
            // 
            // Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1091, 527);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Test";
            this.Text = "Test";
            this.Load += new System.EventHandler(this.Test_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.input_panel.ResumeLayout(false);
            this.input_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox search_gcode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel input_panel;
        private System.Windows.Forms.TextBox s_u_seq;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox s_u_use;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox s_u_nm2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox s_u_nm1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox s_u_cod;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdg_grpcd;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdg_grpnm;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdg_digit;
        private System.Windows.Forms.DataGridViewTextBoxColumn cod_length;
        private System.Windows.Forms.DataGridViewTextBoxColumn u_cod;
        private System.Windows.Forms.DataGridViewTextBoxColumn u_nm1;
        private System.Windows.Forms.DataGridViewTextBoxColumn u_nm2;
        private System.Windows.Forms.DataGridViewTextBoxColumn u_seq;
        private System.Windows.Forms.DataGridViewCheckBoxColumn u_use;
        private System.Windows.Forms.DataGridViewTextBoxColumn status;
    }
}