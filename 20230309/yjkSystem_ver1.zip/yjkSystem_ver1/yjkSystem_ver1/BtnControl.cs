﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yjkSystem_ver1
{
    public partial class BtnControl : Form
    {
        public TabControl tabControl;
        public Panel form_launcher;
        public BtnControl()
        {
            InitializeComponent();
        }

        private void BtnControl_Load(object sender, EventArgs e)
        {
            utility.buttons = new Button[7] { btn_search, btn_insert, btn_update, btn_delete, btn_save, btn_cancel, btn_print };
            utility.SetFuncBtn2(utility.buttons, "0000000");
        }
        #region 버튼별 tag 메소드 변경 후 버튼 이벤트 처리
        private void BtnF_Click(object sender, EventArgs e)
        {
            string btn = (string)(sender as Button).Tag;
            Form form = null;
            if(tabControl != null)
            {
                if (tabControl.SelectedTab == null) return;
                if (tabControl.SelectedIndex == 0) return;

                form = (Form)tabControl.SelectedTab.Controls[0];
            }
            else
            {
                form = (Form)form_launcher.Controls[0];
            }
            Type type = form.GetType();
            MethodInfo mtd = type.GetMethod(btn);
            if (mtd == null) return;
            mtd.Invoke(form, null);
        }
        #endregion
    }
}
