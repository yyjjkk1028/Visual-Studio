﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yjkSystem_ver1
{
    public partial class UnitForm : Form
    {
        private bool select_text_changed = false; //조회 시 텍스트 이벤트 제어
        private bool select_grid_changed = false; //조회 시 그리드뷰 이벤트 제어
        public string button_status { get; set; }  // 버튼 상태 저장
        public Label info_Count { get; set; } // 그리드뷰 조회데이터 수
        public Label info_Message { get; set; } // Main폼에 전달할 메시지

        public UnitForm()
        {
            InitializeComponent();
            s_u_cod.TextChanged += InputData_TextChanged;
            s_u_nm1.TextChanged += InputData_TextChanged;
            s_u_nm2.TextChanged += InputData_TextChanged;
            s_u_seq.TextChanged += InputData_TextChanged;
            s_u_use.CheckedChanged += InputData_TextChanged;

            //erro 확인
            s_u_cod.Validated += Input_Validation_Check;
            s_u_nm1.Validated += Input_Validation_Check;
            s_u_nm2.Validated += Input_Validation_Check;
            s_u_seq.Validated += Input_Validation_Check;

            s_u_cod.KeyPress += TextBox_KeyPress;
        }

        private void UnitForm_Load(object sender, EventArgs e)
        {
            button_status = utility.SetFuncBtn(utility.buttons, "0");
        }
        #region 조회버튼 기능
        public void Search_Btn()
        {
            dataGridView1.Rows.Clear();
            dataGridView2.Rows.Clear();
            DataGridViewRow row;
            try
            {
                utility.conn = utility.SetOracleConnection();
                utility.cmd = utility.conn.CreateCommand();
                utility.cmd.CommandText = SQL.SQL_Group.SelectSQL1;
                utility.cmd.BindByName = true;
                utility.cmd.Parameters.Add("code", OracleDbType.Varchar2).Value = search_gcode.Text + "%";
                utility.cmd.Parameters.Add("name", OracleDbType.Varchar2).Value = "%" + search_gcode.Text + "%";
                OracleDataReader reader = utility.cmd.ExecuteReader();
                select_grid_changed = true;
                int rowidx = 0;
                while (reader.Read())
                {
                    dataGridView1.Rows.Add();
                    row = dataGridView1.Rows[rowidx];
                    row.Cells["cdg_grpcd"].Value = reader["cdg_grpcd"];
                    row.Cells["cdg_grpnm"].Value = reader["cdg_grpnm"];
                    row.Cells["cdg_digit"].Value = reader["cdg_digit"];
                    row.Cells["cod_length"].Value = reader["cod_length"];

                    rowidx++;

                }
                reader.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                select_grid_changed = false;
                if (utility.conn != null) utility.conn.Close();
                utility.Panel_Clear(input_panel);
                if (dataGridView1.Rows.Count <= 0)
                {
                    //MessageBox.Show("조회된 자료가 없습니다.");
                    info_Message.Text = "조회된 자료가 없습니다.";
                }
                else
                {
                    info_Count.Text = dataGridView1.Rows.Count.ToString();
                    info_Message.Text = "자료가 정상적으로 조회되었습니다.";
                }
            }

        }
        #endregion
        #region 그리드뷰 더블 클릭 시 조회
        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            if (select_grid_changed) return;
            if (dataGridView1.Rows.Count == 0) return;
            if (dataGridView1.SelectedRows.Count <= 0) return;
            int rowidx = 0;
            while (dataGridView2.Rows.Count > rowidx)
            {
                if (!string.IsNullOrEmpty(dataGridView2.Rows[rowidx].Cells["status"].Value?.ToString()))
                {
                    DialogResult result = MessageBox.Show("현재 작업중인 자료가 취소됩니다, 조회하시겠습니까?", "취소확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.No) return;
                    break;
                }
                rowidx++;
            }
            s_cdg_grpcd.Text = dataGridView1.CurrentRow.Cells["cdg_grpcd"].Value.ToString();
            s_cdg_grpnm.Text = dataGridView1.CurrentRow.Cells["cdg_grpnm"].Value.ToString();
            s_u_cod.MaxLength = int.Parse(dataGridView1.SelectedRows[0].Cells["cdg_digit"].Value.ToString());
            s_u_nm1.MaxLength = int.Parse(dataGridView1.SelectedRows[0].Cells["cod_length"].Value.ToString());
            select_grid();
        }
        public void select_grid()
        {
            dataGridView2.Rows.Clear();
            DataGridViewRow row;
            try
            {
                utility.conn = utility.SetOracleConnection();
                utility.cmd = utility.conn.CreateCommand();
                utility.cmd.CommandText = SQL.SQL_Unit.SelectSQL;
                utility.cmd.BindByName = true; //BindByName 을 false 로 해두면 변수 이름은 무시되고 서수에 의해 맵핑된다
                utility.cmd.Parameters.Add("code", OracleDbType.Varchar2).Value = s_cdg_grpcd.Text;
                utility.cmd.Parameters.Add("u_nm1", OracleDbType.Varchar2).Value = "%" + search_unit.Text + "%";

                OracleDataReader reader = utility.cmd.ExecuteReader();
                select_grid_changed = true;
                int rowidx = 0;
                while (reader.Read())
                {
                    dataGridView2.Rows.Add();
                    row = dataGridView2.Rows[rowidx];
                    //u_grpcd, u_cod, u_nm1, u_nm2, u_seq, u_use
                    row.Cells["u_cod"].Value = reader["u_cod"];
                    row.Cells["u_nm1"].Value = reader["u_nm1"];
                    row.Cells["u_nm2"].Value = reader["u_nm2"];
                    row.Cells["u_seq"].Value = reader["u_seq"];
                    row.Cells["u_use"].Value = reader["u_use"];
                    rowidx++;

                }
                reader.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                select_grid_changed = false;
                if (utility.conn != null) utility.conn.Close();
                if(dataGridView2.Rows.Count <= 0)
                {
                    //MessageBox.Show("조회된 자료가 없습니다.");
                    info_Message.Text = "조회된 자료가 없습니다.";

                    utility.Panel_Clear(input_panel);
                    button_status = utility.SetFuncBtn(utility.buttons, "1");
                }
                else
                {
                    button_status = utility.SetFuncBtn(utility.buttons, "2");
                    this.dataGridView2_SelectionChanged(null, null);
                    info_Message.Text = "자료가 정상적으로 조회되었습니다.";
                }
                info_Count.Text = dataGridView2.Rows.Count.ToString();
            }
        }
        #endregion
        #region 추가버튼 기능
        public void Insert_Btn()
        {

            var rowidx = dataGridView2.CurrentRow == null ? 0 : dataGridView2.CurrentRow.Index;

            if (dataGridView2.Rows.Count == 0)
            {
                rowidx = dataGridView2.Rows.Add();
            }
            else
            {
                rowidx++;
                dataGridView2.Rows.Insert(rowidx);
            }
            dataGridView2.Rows[rowidx].Cells["status"].Value = "A";
            dataGridView2.CurrentCell = dataGridView2.Rows[rowidx].Cells[1]; // 추가된 Row로 Focus
            s_u_cod.ReadOnly = false;
            s_u_cod.Focus();

            button_status = utility.SetFuncBtn(utility.buttons, "3");
        }
        #endregion
        #region 수정버튼 기능
        public void Update_Btn()
        {
            if (dataGridView2.SelectedRows.Count <= 0) return;
            DataGridViewRow row = dataGridView2.SelectedRows[0];
            if (string.IsNullOrEmpty(row.Cells["status"].Value?.ToString()))
            {
                row.Cells["status"].Value = "U";
                button_status = utility.SetFuncBtn(utility.buttons, "3");
            }
        }
        #endregion
        #region 삭제버튼 기능
        public void Delete_Btn()
        {
            if (dataGridView2.SelectedRows.Count < 1)
            {
                MessageBox.Show("삭제할 자료를 선택하세요.", "삭제확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DataGridViewRow row = dataGridView2.CurrentRow;
            if (row.Cells["status"].Value?.ToString() == "A")
            {
                dataGridView2.Rows.RemoveAt(row.Index);
                return;
            }
            DialogResult result = MessageBox.Show(row.Cells["u_cod"].Value + " 자료를 삭제하시겠습니까?", "삭제확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No) return;

            try
            {
                utility.conn = utility.SetOracleConnection();
                utility.cmd = utility.conn.CreateCommand();
                utility.cmd.BindByName = true;
                utility.cmd.CommandText = SQL.SQL_Unit.DeleteSQL;
                utility.cmd.Parameters.Add("u_cod", OracleDbType.Varchar2).Value = row.Cells["u_cod"].Value;
                utility.cmd.ExecuteNonQuery();
                dataGridView2.Rows.RemoveAt(row.Index);
                //MessageBox.Show("자료가 정상적으로 삭제되었습니다.");
                info_Message.Text = "자료가 정상적으롤 삭제되었습니다.";
                info_Count.Text = dataGridView2.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                if (utility.conn != null) utility.conn.Close();
            }
        }
        #endregion
        #region 저장버튼 기능
        public void Save_Btn()
        {
            DialogResult result = MessageBox.Show("자료를 저장하시겠습니까?", "저장확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No) return;
            if (!utility.InputErrorChk(dataGridView2)) return; // 그리드뷰에 오류있는지 확인

            OracleTransaction tran = null;
            try
            {

                utility.conn = utility.SetOracleConnection();
                tran = utility.conn.BeginTransaction(IsolationLevel.ReadCommitted); //트렌젝션 사용 하기 위함
                utility.cmd = utility.conn.CreateCommand();

                //BindByName 을 false 로 해두면 변수 이름은 무시되고 서수에 의해 맵핑된다
                utility.cmd.BindByName = true;
                utility.cmd.Transaction = tran;
                foreach (DataGridViewRow row in dataGridView2.Rows)
                {
                    if (string.IsNullOrEmpty(row.Cells["status"].Value?.ToString())) continue;
                    if (row.Cells["status"].Value.Equals("A")) // 추가
                    {
                        utility.cmd.CommandText = SQL.SQL_Unit.InsertSQL;
                    }
                    else // 수정
                    {
                        utility.cmd.CommandText = SQL.SQL_Unit.UpdateSQL;
                    }
                    //u_grpcd, u_cod, u_nm1, u_nm2, u_seq, u_use
                    utility.cmd.Parameters.Add("u_grpcd", OracleDbType.Varchar2).Value = s_cdg_grpcd.Text;
                    utility.cmd.Parameters.Add("u_cod", OracleDbType.Varchar2).Value = row.Cells["u_cod"].Value;
                    utility.cmd.Parameters.Add("u_nm1", OracleDbType.Varchar2).Value = row.Cells["u_nm1"].Value;
                    utility.cmd.Parameters.Add("u_nm2", OracleDbType.Varchar2).Value = row.Cells["u_nm2"].Value;
                    utility.cmd.Parameters.Add("u_seq", OracleDbType.Int32).Value = row.Cells["u_seq"].Value;
                    utility.cmd.Parameters.Add("u_use", OracleDbType.Varchar2).Value = utility.ChangedBoolType_CheckBox(row.Cells["u_use"].Value?.ToString());

                    utility.cmd.ExecuteNonQuery();
                    utility.cmd.Parameters.Clear(); //파라미터값을 초기화 해야 다른 sql 이용가능

                    if (row.Cells["status"].Value.Equals("")) continue;
                }
                int rowidx = 0;
                while (dataGridView2.Rows.Count > rowidx)
                {
                    dataGridView2.Rows[rowidx].Cells["status"].Value = "";
                    rowidx++;
                }
                tran.Commit();
            }
            catch (Exception ex)
            {
                tran.Rollback();
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                if (utility.conn != null) utility.conn.Close();
            }
            button_status = utility.SetFuncBtn(utility.buttons, "2");
            info_Count.Text = dataGridView2.Rows.Count.ToString();
            info_Message.Text = "자료가 정상적으로 저장되었습니다.";
        }
        #endregion
        #region 취소버튼 기능
        public void Cancel_Btn()
        {
            int rowidx = 0;
            while (dataGridView2.Rows.Count > rowidx)
            {
                if (!string.IsNullOrEmpty(dataGridView2.Rows[rowidx].Cells["status"].Value?.ToString()))
                {
                    DialogResult result = MessageBox.Show("작업중인 자료를 취소하시겠습니까?", "취소확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.No) return;
                    select_grid();
                    button_status = utility.SetFuncBtn(utility.buttons, "2");
                    break;
                }
                rowidx++;
            }
        }
        #endregion
        #region 텍스트 변경 시 그리드뷰에 작성
        private void InputData_TextChanged(object sender, EventArgs e)
        {
            if (select_text_changed) return;
            if (dataGridView2.SelectedRows.Count == 0) return;

            utility.SetGridViewValue(dataGridView2, sender as Control);

            DataGridViewRow row = dataGridView2.CurrentRow;
            if (string.IsNullOrEmpty(row.Cells["status"].Value?.ToString()))
            {
                row.Cells["status"].Value = "U";
            }

            button_status = utility.SetFuncBtn(utility.buttons, "3");
        }
        #endregion
        #region DataGridView 선택 변경시 Control의 Value Set
        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {
            if (select_grid_changed) return;
            if (dataGridView2.Rows.Count == 0) return;

            select_text_changed = true; // TextChange 이벤트와 충돌 방지
            utility.SetControlValue(dataGridView2, input_panel); // (DataGridView, Control)
            Input_Validation_Check(sender, e); //* Control 에 오류메세지 표시
            select_text_changed = false; // TextChange 이벤트와 충돌 방지
            //MessageBox.Show(dataGridView1.SelectedRows[0].Cells["status"].Value?.ToString());
            if (dataGridView2.CurrentRow.Cells["status"].Value?.ToString() == "A")
            {
                s_u_cod.ReadOnly = false;
            }
            else
            {
                s_u_cod.ReadOnly = true;
            }

        }
        #endregion
        #region 유효성 검사(Error_Check)
        private void Input_Validation_Check(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count <= 0) return;
            string errmsg = "";

            if (s_u_cod.Text == "")
            {
                errmsg = "단위코드를 반드시 입력하세요";
                errorProvider1.SetError(s_u_cod, errmsg);
            }
            else if(s_u_cod.TextLength != s_u_cod.MaxLength)
            {
                errmsg = "단위코드를 반드시 " + s_u_cod.MaxLength + "자리로 입력하세요";
                errorProvider1.SetError(s_u_cod, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_u_cod, "");
            }
            if (s_u_nm1.Text == "")
            {
                errmsg = "코드명(축약)을 반드시 입력하세요";
                errorProvider1.SetError(s_u_nm1, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_u_nm1, "");
            }
            if (s_u_nm2.Text == "")
            {
                errmsg = "코드명(상세)를 반드시 입력하세요";
                errorProvider1.SetError(s_u_nm2, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_u_nm2, "");
            }
            if (s_u_seq.Text == "")
            {
                errmsg = "코드SEQ를 반드시 입력하세요";
                errorProvider1.SetError(s_u_seq, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_u_seq, "");
            }
            dataGridView2.SelectedRows[0].ErrorText = errmsg;

        }
        #endregion
        #region DataGridView 행 삭제 시 버튼 처리
        private void dataGridView2_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if (dataGridView2.Rows.Count <= 0)
            {
                button_status = utility.SetFuncBtn(utility.buttons, "1");
                errorProvider1.Clear();
                return;
            }
            int rowidx = 0;
            while (dataGridView2.Rows.Count > rowidx)
            {
                if (!string.IsNullOrEmpty(dataGridView2.Rows[rowidx].Cells["status"].Value?.ToString())) return;
                rowidx++;
            }
            button_status = utility.SetFuncBtn(utility.buttons, "2");
        }
        #endregion
        #region 숫자만 입력 가능
        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if ((!char.IsDigit(e.KeyChar)) || (e.KeyChar == Convert.ToChar(Keys.Back)))
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)))
            {
                e.Handled = true;
            }
        }
        #endregion

        #region 검색어 조회
        private void button1_Click(object sender, EventArgs e)
        {
            select_grid();
        }

        private void search_unit_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Enter 키 이벤트
            if (e.KeyChar == (char)13)
            {
                e.Handled = true;
                select_grid();
            }

        }
        #endregion
    }
}
