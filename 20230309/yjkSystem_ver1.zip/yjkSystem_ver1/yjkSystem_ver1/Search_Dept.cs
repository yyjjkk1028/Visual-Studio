﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yjkSystem_ver1
{
    
    public partial class Search_Dept : Form
    {
        private string result;
        private string sql;
        private string search;
        public string GetResult
        {
            get { return result; }
        }
        public Search_Dept()
        {
            InitializeComponent();
        }
        public Search_Dept(string sql,string search)
        {
            this.sql = sql;
            this.search = search;
            InitializeComponent();
        }

        private void searchText_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                e.Handled = true;

                try
                {
                    utility.conn = utility.SetOracleConnection();
                    utility.cmd = utility.conn.CreateCommand();
                    utility.cmd.CommandText = sql;
                    utility.cmd.Parameters.Add("condition", OracleDbType.Varchar2).Value = "%" + searchText.Text + "%";

                    OracleDataAdapter da = new OracleDataAdapter(utility.cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds, "TAB");
                    dataGridView1.DataSource = ds.Tables["TAB"].DefaultView;
                    //MessageBox.Show("조회되었습니다.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    if (utility.conn != null) utility.conn.Close();
                }
            }
        }

        private void Search_Dept_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) return;
            result = (string)dataGridView1.Rows[e.RowIndex].Cells[0].Value + ":" +
                     (string)dataGridView1.Rows[e.RowIndex].Cells[1].Value;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
