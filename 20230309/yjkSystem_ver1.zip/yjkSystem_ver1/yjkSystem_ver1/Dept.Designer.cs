﻿
namespace yjkSystem_ver1
{
    partial class Dept
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.search_dept = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.search_name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dept_code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dept_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dept_name_detail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dept_use = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.input_panel = new System.Windows.Forms.Panel();
            this.s_dept_use = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.s_dept_name_detail = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.s_dept_name = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.s_dept_code = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.input_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // search_dept
            // 
            this.search_dept.Location = new System.Drawing.Point(88, 15);
            this.search_dept.Name = "search_dept";
            this.search_dept.Size = new System.Drawing.Size(100, 21);
            this.search_dept.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "부서코드";
            // 
            // panel1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel1, 2);
            this.panel1.Controls.Add(this.search_name);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.search_dept);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(881, 50);
            this.panel1.TabIndex = 4;
            // 
            // search_name
            // 
            this.search_name.Location = new System.Drawing.Point(262, 15);
            this.search_name.Name = "search_name";
            this.search_name.Size = new System.Drawing.Size(100, 21);
            this.search_name.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(215, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "부서명";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 62.1422F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.8578F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.input_panel, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(889, 413);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dept_code,
            this.dept_name,
            this.dept_name_detail,
            this.dept_use,
            this.status});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(4, 55);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(544, 354);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dataGridView1_RowsRemoved);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // dept_code
            // 
            this.dept_code.DataPropertyName = "dept_code";
            this.dept_code.HeaderText = "부서코드";
            this.dept_code.Name = "dept_code";
            this.dept_code.ReadOnly = true;
            // 
            // dept_name
            // 
            this.dept_name.DataPropertyName = "dept_name";
            this.dept_name.HeaderText = "부서명";
            this.dept_name.Name = "dept_name";
            this.dept_name.ReadOnly = true;
            // 
            // dept_name_detail
            // 
            this.dept_name_detail.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dept_name_detail.DataPropertyName = "dept_name_detail";
            this.dept_name_detail.HeaderText = "부서명(상세)";
            this.dept_name_detail.MinimumWidth = 200;
            this.dept_name_detail.Name = "dept_name_detail";
            this.dept_name_detail.ReadOnly = true;
            // 
            // dept_use
            // 
            this.dept_use.DataPropertyName = "dept_use";
            this.dept_use.FalseValue = "N";
            this.dept_use.HeaderText = "사용여부";
            this.dept_use.Name = "dept_use";
            this.dept_use.ReadOnly = true;
            this.dept_use.TrueValue = "Y";
            this.dept_use.Width = 80;
            // 
            // status
            // 
            this.status.HeaderText = "상태";
            this.status.Name = "status";
            this.status.ReadOnly = true;
            // 
            // input_panel
            // 
            this.input_panel.Controls.Add(this.s_dept_use);
            this.input_panel.Controls.Add(this.label6);
            this.input_panel.Controls.Add(this.s_dept_name_detail);
            this.input_panel.Controls.Add(this.label5);
            this.input_panel.Controls.Add(this.s_dept_name);
            this.input_panel.Controls.Add(this.label4);
            this.input_panel.Controls.Add(this.s_dept_code);
            this.input_panel.Controls.Add(this.label3);
            this.input_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.input_panel.Location = new System.Drawing.Point(555, 55);
            this.input_panel.Name = "input_panel";
            this.input_panel.Size = new System.Drawing.Size(330, 354);
            this.input_panel.TabIndex = 5;
            // 
            // s_dept_use
            // 
            this.s_dept_use.AutoSize = true;
            this.s_dept_use.Location = new System.Drawing.Point(122, 145);
            this.s_dept_use.Name = "s_dept_use";
            this.s_dept_use.Size = new System.Drawing.Size(15, 14);
            this.s_dept_use.TabIndex = 9;
            this.s_dept_use.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "사용여부";
            // 
            // s_dept_name_detail
            // 
            this.s_dept_name_detail.Location = new System.Drawing.Point(122, 100);
            this.s_dept_name_detail.Name = "s_dept_name_detail";
            this.s_dept_name_detail.Size = new System.Drawing.Size(174, 21);
            this.s_dept_name_detail.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 12);
            this.label5.TabIndex = 6;
            this.label5.Text = "부서명(상세)";
            // 
            // s_dept_name
            // 
            this.s_dept_name.Location = new System.Drawing.Point(122, 63);
            this.s_dept_name.Name = "s_dept_name";
            this.s_dept_name.Size = new System.Drawing.Size(174, 21);
            this.s_dept_name.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "부서명";
            // 
            // s_dept_code
            // 
            this.s_dept_code.Location = new System.Drawing.Point(122, 26);
            this.s_dept_code.MaxLength = 3;
            this.s_dept_code.Name = "s_dept_code";
            this.s_dept_code.Size = new System.Drawing.Size(174, 21);
            this.s_dept_code.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "부서코드";
            // 
            // errorProvider1
            // 
            this.errorProvider1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errorProvider1.ContainerControl = this;
            // 
            // Dept
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 413);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Dept";
            this.Text = "Dept";
            this.Load += new System.EventHandler(this.Dept_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.input_panel.ResumeLayout(false);
            this.input_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox search_dept;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox search_name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel input_panel;
        private System.Windows.Forms.CheckBox s_dept_use;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox s_dept_name_detail;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox s_dept_name;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox s_dept_code;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dept_code;
        private System.Windows.Forms.DataGridViewTextBoxColumn dept_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn dept_name_detail;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dept_use;
        private System.Windows.Forms.DataGridViewTextBoxColumn status;
    }
}