﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Xamarin.Essentials;

namespace yjkSystem_ver1
{
    public partial class Main : Form
    {
        Point _imageLocation = new Point(20, 8);
        Point _imgHitArea = new Point(20, 8);
        public Main()
        {
            InitializeComponent();
        }


        private void Main_Load(object sender, EventArgs e)
        {
            /*// 로그인 화면 불러오기
            Login login = new Login();
            login.ShowDialog();
            //if (!utility.result_login) Application.Exit();
            if (login.DialogResult != DialogResult.OK) Application.Exit();*/

            // 버튼 불러오기
            BtnControl bc = new BtnControl() { TopLevel = false, TopMost = true };
            btn_panel.Controls.Add(bc);
            bc.Show();
            bc.tabControl = this.tabControl1;

            user_nam.Text = utility.user_nam;
            int i = 0;
            while (i < treeView1.Nodes.Count)
            {
                if (utility.user_grant != "manager")
                {
                    if(treeView1.Nodes[i].Tag != null && treeView1.Nodes[i].Tag.ToString() == "manager")
                    {
                        treeView1.Nodes[i].Remove();
                    }
                }
                i++;
            }
        }
        #region 트리뷰 더블 클릭 시 폼 가져오기
        private void treeView1_DoubleClick(object sender, EventArgs e)
        {
            // tag 정보 [프로그램id, 폼이름, 폼넓이, 폼높이, 폼전체화면여부, 프로그램이름]

            String tag = (string)(sender as TreeView).SelectedNode.Tag;
            if (tag == null)
            {
                return;
            }
            if(tag == "manager") { return; }

            String[] tag_arr = tag.Split(':');
            Type formType = Assembly.GetExecutingAssembly().GetTypes()
               .Where(a => a.BaseType == typeof(Form) && a.Name == tag_arr[1])
               .FirstOrDefault();
            if (formType == null)
            {
                return;
            }

            Form form = (Form)Activator.CreateInstance(formType);  // 동적생성(폼)

            if (form == null)
            {
                MessageBox.Show("해당메뉴 수행 프로그램이 존재하지 않습니다.");
                return;
            }

            if(checkBox1.Checked)
            {
                //using Xamarin.Essentials; 설치
                var launcher = new Launcher();
                launcher.LoadingPgmId = tag_arr[0];
                launcher.LoadingPgmName = tag_arr[5];
                launcher.LoadingFormName = tag_arr[1];
                if (tag_arr[4].Equals("Y"))
                {
                    launcher.WindowState = System.Windows.Forms.FormWindowState.Maximized;
                }
                launcher.Width = Convert.ToInt32(tag_arr[2]) + 10;
                launcher.Height = Convert.ToInt32(tag_arr[3]) + 95 + 12;
                launcher.Show();
            }
            else
            {
                // 탭페이지 키 값확인
                TabPage tabPage = tabControl1.TabPages[tag_arr[5]];
                if (tabPage != null)
                {
                    //확인된 키값화면으로 이동
                    tabControl1.SelectTab(tabPage);
                    return;
                }

                form.TopLevel = false;
                form.FormBorderStyle = FormBorderStyle.None;
                if (tag_arr[4].Equals("Y"))
                {
                    form.Dock = DockStyle.Fill;
                }
                // (탭페이지text, tabpage key)
                tabControl1.TabPages.Add(tag_arr[5], tag_arr[5]);
                // 마지막 페이지에 form추가
                tabControl1.TabPages[tabControl1.TabPages.Count - 1].Controls.Add(form);
                // 마지막 페이지를 선택클릭
                tabControl1.SelectTab(tabControl1.TabPages.Count - 1);
                form.Tag = tag_arr[0];

                form.Show();

                now_page.Text = tag_arr[5];
            }


        }
        #endregion

        private void tabControl1_MouseClick(object sender, MouseEventArgs e)
        {
            TabControl tabControl = (TabControl)sender;
            if (tabControl.SelectedIndex == 0) return;

            Point p = e.Location; // 마우스 클릭한 좌표

            int _tabWidth = 0;
            _tabWidth = this.tabControl1.GetTabRect(tabControl.SelectedIndex).Width - (_imgHitArea.X); // x이미지 넓이
            Rectangle r = this.tabControl1.GetTabRect(tabControl.SelectedIndex); //선택된 tabpage사이즈
            r.Offset(_tabWidth, _imgHitArea.Y); // x이미지 크기에 맞게 위치조정

            /*r.Width = 16;
            r.Height = 16;*/
            if (r.Contains(p))
            {

                TabPage tabPage = (TabPage)tabControl.TabPages[tabControl.SelectedIndex];
                //*--Page 삭제 前에 Form Close-----------
                Form form = (Form)tabPage.Controls[0];
                form.Close();
                //*--------------------------------------

                tabControl.TabPages.Remove(tabPage);
            }
            now_page.Text = tabControl1.SelectedTab.Name;

        }

        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
            Rectangle r = e.Bounds;
            r = this.tabControl1.GetTabRect(e.Index);
            r.Offset(5, 5);
            Brush TitleBrush = new SolidBrush(Color.Black);
            Font f = this.Font;
            string title = this.tabControl1.TabPages[e.Index].Text;
            e.Graphics.DrawString(title, f, TitleBrush, new PointF(r.X, r.Y));

            if (e.Index == 0) return;
            if (e.Index != this.tabControl1.SelectedIndex) return;  //선택된 Page에서만 Close Image 표시
            //Resource.Desinger.cs 에서 
            // internal static System.Drawing.Bitmap close

            Image img = new Bitmap(Properties.Resources.close);
            e.Graphics.DrawImage(img, new Point(r.X + (this.tabControl1.GetTabRect(e.Index).Width - _imageLocation.X), _imageLocation.Y));
        }

        #region 해당페이지의 버튼상태 불러오기
        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            if(tabControl1.SelectedIndex == 0)
            {
                utility.SetFuncBtn2(utility.buttons, "0000000");
                return;
            }
            Form form = (Form)tabControl1.SelectedTab.Controls[0];
            Type type = form.GetType();
            PropertyInfo pi = type.GetProperty("button_status");
            if(pi != null)
            {
                utility.SetFuncBtn2(utility.buttons, pi.GetValue(form) as string);
            }
            type.GetProperty("info_Count")?.SetValue(form, info_cnt); // 리플렉션 사용하여 info_Count의 속성값을 설정
            type.GetProperty("info_Message")?.SetValue(form, info_msg); // 리플렉션 사용하여 info_Message의 속성값을 설정
            
        }
        #endregion
    }
}
