﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yjkSystem_ver1
{
    public partial class Dept : Form
    {
        private bool select_text_changed = false; //조회 시 텍스트 이벤트 제어
        private bool select_grid_changed = false; //조회 시 그리드뷰 이벤트 제어
        public string button_status { get; set; }  // 버튼 상태 저장
        public Label info_Count { get; set; } // 그리드뷰 조회데이터 수
        public Label info_Message { get; set; } // Main폼에 전달할 메시지
        public Dept()
        {
            InitializeComponent();
            // Value Change 이벤트
            s_dept_code.TextChanged += InputData_TextChanged;
            s_dept_name.TextChanged += InputData_TextChanged;
            s_dept_name_detail.TextChanged += InputData_TextChanged;
            s_dept_use.CheckedChanged += InputData_TextChanged;

            // 유효성 검사 (Error 확인)
            s_dept_code.Validated += Input_Validation_Check;
            s_dept_name.Validated += Input_Validation_Check;
            s_dept_name_detail.Validated += Input_Validation_Check;

            //숫자만 입력가능
            s_dept_code.KeyPress += TextBox_KeyPress;
        }

        private void Dept_Load(object sender, EventArgs e)
        {
            button_status = utility.SetFuncBtn(utility.buttons, "1");
        }
        #region 조회버튼 기능
        public void Search_Btn()
        {
            dataGridView1.Rows.Clear();
            DataGridViewRow row;
            try
            {
                utility.conn = utility.SetOracleConnection();
                utility.cmd = utility.conn.CreateCommand();
                utility.cmd.CommandText = SQL.SQL_Dept.SelectSQL;
                utility.cmd.BindByName = true;
                utility.cmd.Parameters.Add("dept_code", OracleDbType.Varchar2).Value = search_dept.Text + "%";
                utility.cmd.Parameters.Add("dept_name", OracleDbType.Varchar2).Value = "%" + search_name.Text + "%";
                
                //데이터 추가 및 수정이 불가
                /*OracleDataAdapter da = new OracleDataAdapter(utility.cmd);
                DataSet ds = new DataSet();
                da.Fill(ds, "TAB");
                dataGridView1.DataSource = ds.Tables["TAB"];*/

                OracleDataReader reader = utility.cmd.ExecuteReader();
                select_grid_changed = true;
                int rowidx = 0;
                while (reader.Read())
                {
                    dataGridView1.Rows.Add();
                    row = dataGridView1.Rows[rowidx];
                    row.Cells["dept_code"].Value = reader["dept_code"];
                    row.Cells["dept_name"].Value = reader["dept_name"];
                    row.Cells["dept_name_detail"].Value = reader["dept_name_detail"];
                    row.Cells["dept_use"].Value = reader["dept_use"];

                    rowidx++;

                }
                reader.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                select_grid_changed = false;
                if (utility.conn != null) utility.conn.Close();
                if (dataGridView1.Rows.Count <= 0)
                {
                    //MessageBox.Show("조회된 자료가 없습니다.");
                    info_Message.Text = "조회된 자료가 없습니다.";
                }
                else
                {
                    this.dataGridView1_SelectionChanged(null, null);
                    button_status = utility.SetFuncBtn(utility.buttons, "2");
                    info_Count.Text = dataGridView1.Rows.Count.ToString();
                    info_Message.Text = "자료가 정상적으로 조회되었습니다.";
                }
            }
        }
        #endregion
        #region 추가버튼 기능
        public void Insert_Btn()
        {
            
            var rowidx = dataGridView1.CurrentRow == null ? 0 : dataGridView1.CurrentRow.Index;

            if(dataGridView1.Rows.Count == 0)
            {
                rowidx = dataGridView1.Rows.Add();
            }
            else
            {
                rowidx++;
                dataGridView1.Rows.Insert(rowidx);
            }
            dataGridView1.Rows[rowidx].Cells["status"].Value = "A";
            dataGridView1.CurrentCell = dataGridView1.Rows[rowidx].Cells[1]; // 추가된 Row로 Focus
            s_dept_code.ReadOnly = false;
            s_dept_code.Focus();

            button_status = utility.SetFuncBtn(utility.buttons, "3");
        }
        #endregion
        #region 수정버튼 기능
        public void Update_Btn()
        {
            if (dataGridView1.SelectedRows.Count <= 0) return;
            DataGridViewRow row = dataGridView1.SelectedRows[0];
            if (string.IsNullOrEmpty(row.Cells["status"].Value?.ToString()))
            {
                row.Cells["status"].Value = "U";
                button_status = utility.SetFuncBtn(utility.buttons, "3");
            }
        }
        #endregion
        #region 삭제버튼 기능
        public void Delete_Btn()
        {
            if(dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("삭제할 자료를 선택하세요.", "삭제확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DataGridViewRow row = dataGridView1.CurrentRow;
            if(row.Cells["status"].Value?.ToString() == "A")
            {
                dataGridView1.Rows.RemoveAt(row.Index);
                return;
            }
            DialogResult result = MessageBox.Show(row.Cells["dept_code"].Value + " 자료를 삭제하시겠습니까?","삭제확인",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if (result == DialogResult.No) return;

            try
            {
                utility.conn = utility.SetOracleConnection();
                utility.cmd = utility.conn.CreateCommand();
                utility.cmd.BindByName = true;
                utility.cmd.CommandText = SQL.SQL_Dept.DeleteSQL;
                utility.cmd.Parameters.Add("dept_code", OracleDbType.Varchar2).Value = row.Cells["dept_code"].Value;
                utility.cmd.ExecuteNonQuery();
                dataGridView1.Rows.RemoveAt(row.Index);
                //MessageBox.Show("자료가 정상적으로 삭제되었습니다.");
                info_Message.Text = "자료가 정상적으로 삭제되었습니다.";
                info_Count.Text = dataGridView1.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                if (utility.conn != null) utility.conn.Close();
            }
        }
        #endregion
        #region 저장버튼 기능
        public void Save_Btn()
        {
            DialogResult result = MessageBox.Show("자료를 저장하시겠습니까?", "저장확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No) return;
            if (!utility.InputErrorChk(dataGridView1)) return; // 그리드뷰에 오류있는지 확인

            OracleTransaction tran = null;
            try
            {
                utility.conn = utility.SetOracleConnection();
                tran = utility.conn.BeginTransaction(IsolationLevel.ReadCommitted);
                utility.cmd = utility.conn.CreateCommand();

                
                utility.cmd.BindByName = true; //BindByName 을 false 로 해두면 변수 이름은 무시되고 서수에 의해 맵핑된다
                utility.cmd.Transaction = tran;
                foreach(DataGridViewRow row in dataGridView1.Rows)
                {
                    if (string.IsNullOrEmpty(row.Cells["status"].Value?.ToString())) continue;
                    if (row.Cells["status"].Value.Equals("A")) // 추가
                    {
                        utility.cmd.CommandText = SQL.SQL_Dept.InsertSQL;
                    }
                    else // 수정
                    {
                        utility.cmd.CommandText = SQL.SQL_Dept.UpdateSQL;
                    }
                    utility.cmd.Parameters.Add("dept_code", OracleDbType.Varchar2).Value = row.Cells["dept_code"].Value;
                    utility.cmd.Parameters.Add("dept_name", OracleDbType.Varchar2).Value = row.Cells["dept_name"].Value;
                    utility.cmd.Parameters.Add("dept_name_detail", OracleDbType.Varchar2).Value = row.Cells["dept_name_detail"].Value;
                    /*utility.cmd.Parameters.Add("dept_use", OracleDbType.Varchar2).Value = utility.ChangedBoolType(row.Cells["dept_use"].Value, "chkbox");*/
                    utility.cmd.Parameters.Add("dept_use", OracleDbType.Varchar2).Value = utility.ChangedBoolType_CheckBox(row.Cells["dept_use"].Value?.ToString());
                    utility.cmd.ExecuteNonQuery();
                    utility.cmd.Parameters.Clear(); //파라미터값을 초기화 해야 다른 sql 이용가능

                    if (row.Cells["status"].Value.Equals("")) continue;
                }
                int rowidx = 0;
                while (dataGridView1.Rows.Count > rowidx)
                {
                    dataGridView1.Rows[rowidx].Cells["status"].Value = "";
                    rowidx++;
                }
                tran.Commit();
            }
            catch (Exception ex)
            {
                tran.Rollback();
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                if (utility.conn != null) utility.conn.Close();
            }
            button_status = utility.SetFuncBtn(utility.buttons, "2");
            info_Count.Text = dataGridView1.Rows.Count.ToString();
            info_Message.Text = "자료가 정상적으로 저장되었습니다.";
        }
        #endregion
        #region 취소버튼 기능
        public void Cancel_Btn()
        {
            int rowidx = 0;
            while (dataGridView1.Rows.Count > rowidx)
            {
                if (!string.IsNullOrEmpty(dataGridView1.Rows[rowidx].Cells["status"].Value?.ToString()))
                {
                    DialogResult result = MessageBox.Show("작업중인 자료를 취소하시겠습니까?", "취소확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.No) return;
                    Search_Btn();
                    button_status = utility.SetFuncBtn(utility.buttons, "2");
                    break;
                }
                rowidx++;
            }
        }
        #endregion
        #region 인쇄버튼 기능
        public void Print_Btn()
        {
            MessageBox.Show("인쇄버튼 클릭");
        }
        #endregion
        #region 텍스트 변경 시 그리드뷰에 작성
        private void InputData_TextChanged(object sender, EventArgs e)
        {
            if (select_text_changed) return;
            if (dataGridView1.SelectedRows.Count == 0) return;

            utility.SetGridViewValue(dataGridView1, sender as Control);

            DataGridViewRow row = dataGridView1.CurrentRow;
            if (string.IsNullOrEmpty(row.Cells["status"].Value?.ToString()))
            {
                row.Cells["status"].Value = "U";
            }
            button_status = utility.SetFuncBtn(utility.buttons, "3");
        }
        #endregion
        #region 유효성 검사(Error_Check)
        private void Input_Validation_Check(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count <= 0) return;
            string errmsg = "";

            if(s_dept_code.Text == "")
            {
                errmsg = "부서코드를 반드시 입력하세요";
                errorProvider1.SetError(s_dept_code, errmsg);
            }
            else if (s_dept_code.TextLength != 3)
            {
                errmsg = "부서코드를 반드시 3자리로 입력하세요";
                errorProvider1.SetError(s_dept_code, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_dept_code, "");
            }
            if (s_dept_name.Text == "")
            {
                errmsg = "부서명을 반드시 입력하세요";
                errorProvider1.SetError(s_dept_name, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_dept_name, "");
            }
            if (s_dept_name_detail.Text == "")
            {
                errmsg = "부서명(상세)를 반드시 입력하세요";
                errorProvider1.SetError(s_dept_name_detail, errmsg);
            }
            else
            {
                errorProvider1.SetError(s_dept_name_detail, "");
            }
            dataGridView1.SelectedRows[0].ErrorText = errmsg;

        }
        #endregion
        #region DataGridView 선택 변경시 Control의 Value Set
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (select_grid_changed) return;
            if (dataGridView1.Rows.Count == 0) return;

            select_text_changed = true; // TextChange 이벤트와 충돌 방지
            utility.SetControlValue(dataGridView1, input_panel); // (DataGridView, Control)
            Input_Validation_Check(sender, e); //* Control 에 오류메세지 표시
            select_text_changed = false; // TextChange 이벤트와 충돌 방지
            if (dataGridView1.CurrentRow.Cells["status"].Value?.ToString() == "A")
            {
                s_dept_code.ReadOnly = false;
            }
            else
            {
                s_dept_code.ReadOnly = true;
            }

        }
        #endregion
        #region DataGridView 행 삭제 시 버튼 처리
        private void dataGridView1_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if(dataGridView1.Rows.Count <= 0)
            {
                button_status = utility.SetFuncBtn(utility.buttons, "1");
                errorProvider1.Clear();
                return;
            }
            int rowidx = 0;
            while (dataGridView1.Rows.Count > rowidx)
            {
                if (!string.IsNullOrEmpty(dataGridView1.Rows[rowidx].Cells["status"].Value?.ToString())) return;
                rowidx++;
            }
            button_status = utility.SetFuncBtn(utility.buttons, "2");
        }
        #endregion
        #region 숫자만 입력 가능
        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)))
            {
                e.Handled = true;
            }
        }
        #endregion
    }
}
