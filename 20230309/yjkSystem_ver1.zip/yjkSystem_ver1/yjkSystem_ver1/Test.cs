﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yjkSystem_ver1
{
    public partial class Test : Form
    {
        public Test()
        {
            InitializeComponent();
        }

        private void Test_Load(object sender, EventArgs e)
        {
            utility.SetFuncBtn(utility.buttons, "1");
        }
        public void Search_Btn()
        {
            dataGridView2.Rows.Clear();
            DataGridViewRow row;
            try
            {
                utility.conn = utility.SetOracleConnection();
                utility.cmd = utility.conn.CreateCommand();
                utility.cmd.CommandText = SQL.SQL_Unit.SelectSQL;
                utility.cmd.Parameters.Add("code", OracleDbType.Varchar2).Value = "POS";
                utility.cmd.BindByName = true;
                OracleDataReader reader = utility.cmd.ExecuteReader();
                int rowidx = 0;
                while (reader.Read())
                {
                    dataGridView2.Rows.Add();
                    row = dataGridView2.Rows[rowidx];
                    //u_grpcd, u_cod, u_nm1, u_nm2, u_seq, u_use
                    //row.Cells["u_grpcd"].Value = reader["u_grpcd"];
                    row.Cells["u_cod"].Value = reader["u_cod"];
                    row.Cells["u_nm1"].Value = reader["u_nm1"];
                    row.Cells["u_nm2"].Value = reader["u_nm2"];
                    row.Cells["u_seq"].Value = reader["u_seq"];
                    row.Cells["u_use"].Value = utility.ChangedBoolType(reader["u_use"].ToString());
                    rowidx++;

                }
                reader.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                //select_grid_changed = false;
                if (utility.conn != null) utility.conn.Close();
            }

        }
    }
}
