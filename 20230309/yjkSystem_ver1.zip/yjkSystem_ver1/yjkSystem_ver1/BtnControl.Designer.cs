﻿namespace yjkSystem_ver1
{
    partial class BtnControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_print = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_print
            // 
            this.btn_print.BackColor = System.Drawing.Color.White;
            this.btn_print.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_print.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btn_print.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_print.ForeColor = System.Drawing.Color.White;
            this.btn_print.Image = global::yjkSystem_ver1.Properties.Resources.print;
            this.btn_print.Location = new System.Drawing.Point(451, 7);
            this.btn_print.Margin = new System.Windows.Forms.Padding(0);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(70, 60);
            this.btn_print.TabIndex = 21;
            this.btn_print.Tag = "Print_Btn";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Click += new System.EventHandler(this.BtnF_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.White;
            this.btn_cancel.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_cancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btn_cancel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btn_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancel.ForeColor = System.Drawing.Color.White;
            this.btn_cancel.Image = global::yjkSystem_ver1.Properties.Resources.cancel;
            this.btn_cancel.Location = new System.Drawing.Point(377, 7);
            this.btn_cancel.Margin = new System.Windows.Forms.Padding(0);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(70, 60);
            this.btn_cancel.TabIndex = 20;
            this.btn_cancel.Tag = "Cancel_Btn";
            this.btn_cancel.UseVisualStyleBackColor = false;
            this.btn_cancel.Click += new System.EventHandler(this.BtnF_Click);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.White;
            this.btn_save.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btn_save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.ForeColor = System.Drawing.Color.White;
            this.btn_save.Image = global::yjkSystem_ver1.Properties.Resources.save;
            this.btn_save.Location = new System.Drawing.Point(303, 7);
            this.btn_save.Margin = new System.Windows.Forms.Padding(0);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(70, 60);
            this.btn_save.TabIndex = 19;
            this.btn_save.Tag = "Save_Btn";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.BtnF_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.White;
            this.btn_delete.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_delete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btn_delete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.ForeColor = System.Drawing.Color.White;
            this.btn_delete.Image = global::yjkSystem_ver1.Properties.Resources.delete;
            this.btn_delete.Location = new System.Drawing.Point(229, 7);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(0);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(70, 60);
            this.btn_delete.TabIndex = 18;
            this.btn_delete.Tag = "Delete_Btn";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.BtnF_Click);
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.White;
            this.btn_update.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_update.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btn_update.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btn_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_update.ForeColor = System.Drawing.Color.White;
            this.btn_update.Image = global::yjkSystem_ver1.Properties.Resources.update;
            this.btn_update.Location = new System.Drawing.Point(155, 7);
            this.btn_update.Margin = new System.Windows.Forms.Padding(0);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(70, 60);
            this.btn_update.TabIndex = 17;
            this.btn_update.Tag = "Update_Btn";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.BtnF_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.BackColor = System.Drawing.Color.White;
            this.btn_insert.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_insert.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btn_insert.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btn_insert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_insert.ForeColor = System.Drawing.Color.White;
            this.btn_insert.Image = global::yjkSystem_ver1.Properties.Resources.add;
            this.btn_insert.Location = new System.Drawing.Point(81, 7);
            this.btn_insert.Margin = new System.Windows.Forms.Padding(0);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(70, 60);
            this.btn_insert.TabIndex = 16;
            this.btn_insert.Tag = "Insert_Btn";
            this.btn_insert.UseVisualStyleBackColor = false;
            this.btn_insert.Click += new System.EventHandler(this.BtnF_Click);
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.White;
            this.btn_search.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_search.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btn_search.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btn_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search.ForeColor = System.Drawing.Color.White;
            this.btn_search.Image = global::yjkSystem_ver1.Properties.Resources.search;
            this.btn_search.Location = new System.Drawing.Point(7, 7);
            this.btn_search.Margin = new System.Windows.Forms.Padding(0);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(70, 60);
            this.btn_search.TabIndex = 15;
            this.btn_search.Tag = "Search_Btn";
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.BtnF_Click);
            // 
            // BtnControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(531, 72);
            this.Controls.Add(this.btn_print);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_search);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BtnControl";
            this.Text = "BtnControl";
            this.Load += new System.EventHandler(this.BtnControl_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.Button btn_search;
    }
}