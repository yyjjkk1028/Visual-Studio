﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yjkSystem_ver1.SQL
{
    class SQL_User
    {
        public static string
            SelectSQL = "select user_id, user_pwd, user_nam, user_grant from yjk_user where user_id=:user_id ";
    }
}
