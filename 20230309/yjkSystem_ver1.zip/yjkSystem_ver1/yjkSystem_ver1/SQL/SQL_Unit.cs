﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yjkSystem_ver1.SQL
{
    class SQL_Unit
    {
        public static string
            SelectSQL = @"select u_grpcd, u_cod, u_nm1, u_nm2, u_seq, u_use from yjk_unit_code 
                            where u_grpcd = :code and u_nm1 like :u_nm1 order by u_seq ";
        public static string 
            Select_POS = @" select u_cod||':'||u_nm1 from yjk_unit_code where u_use ='Y' and u_grpcd ='POS' ";

        public static string
            Select_RNK = @" select u_cod||':'||u_nm1 from yjk_unit_code where u_use ='Y' and u_grpcd ='RNK' ";

        public static string
            Select_DUT = @" select u_cod||':'||u_nm1 from yjk_unit_code where u_use ='Y' and u_grpcd ='DUT' ";

        public static string
            Select_MIL = @" select u_cod||':'||u_nm1 from yjk_unit_code where u_use ='Y' and u_grpcd ='MIL' ";

        public static string
            Select_BNK = @" select u_cod||':'||u_nm1 from yjk_unit_code where u_use ='Y' and u_grpcd ='BNK' ";

        public static string
            InsertSQL = @"insert into yjk_unit_code(u_grpcd, u_cod, u_nm1, u_nm2, u_seq, u_use)
                                             values(:u_grpcd, :u_cod, :u_nm1, :u_nm2, :u_seq, :u_use) ";

        public static string
            UpdateSQL = @"update yjk_unit_code set u_nm1 = :u_nm1, u_nm2 = :u_nm2, u_seq = :u_seq, u_use = :u_use where u_cod = :u_cod ";

        public static string
            DeleteSQL = @"delete from yjk_unit_code where u_cod = :u_cod ";

        public static string
            DeleteSQL1 = @"delete from yjk_unit_code where u_grpcd = :u_grpcd ";
    }
}
