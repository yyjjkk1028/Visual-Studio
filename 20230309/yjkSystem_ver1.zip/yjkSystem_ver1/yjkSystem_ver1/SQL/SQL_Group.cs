﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yjkSystem_ver1.SQL
{
    class SQL_Group
    {
        public static string
            SelectSQL = @"select cdg_grpcd, cdg_grpnm, cdg_digit, cod_length, cdg_use from yjk_group_code 
                             where cdg_grpcd like :code and cdg_grpnm like :name ";

        public static string
            SelectSQL1 = @"select cdg_grpcd, cdg_grpnm, cdg_digit, cod_length, cdg_use from yjk_group_code 
                             where cdg_use='Y' and (cdg_grpcd like :code or cdg_grpnm like :name) ";

        public static string
            InsertSQL = @"insert into yjk_group_code(cdg_grpcd, cdg_grpnm, cdg_digit, cod_length, cdg_use)
                                       values(:cdg_grpcd, :cdg_grpnm, :cdg_digit, :cod_length, :cdg_use)";

        public static string
            UpdateSQL = @"update yjk_group_code set cdg_grpnm=:cdg_grpnm, cdg_digit=:cdg_digit, cod_length=:cod_length, cdg_use=:cdg_use 
                              where cdg_grpcd= :cdg_grpcd ";

        public static string
            DeleteSQL = @"delete from yjk_group_code where cdg_grpcd = :cdg_grpcd ";
    }
}
