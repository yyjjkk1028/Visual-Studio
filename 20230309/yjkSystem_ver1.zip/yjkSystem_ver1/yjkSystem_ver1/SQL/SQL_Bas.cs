﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yjkSystem_ver1.SQL
{
    class SQL_Bas
    {
        public static string //, img.img_img as image 
            SelectSQL = @"SELECT bas_empno, bas_resno, bas_name, bas_cname, bas_ename, bas_fix, bas_zip, bas_addr, bas_hdpno, bas_telno, substr(bas_email,1, instr(bas_email,'@')-1)as bas_email, substr(bas_email,instr(bas_email,'@')+1)as sub_email,
                                 bas_mil_sta, bas_mil_mil||':'||mil.u_nm1 as bas_mil_mil, bas_mil_rnk||':'||rnk.u_nm1 as bas_mil_rnk, bas_mar, bas_acc_bank||':'||bnk.u_nm1 as bas_acc_bank, bas_acc_name, bas_acc_no, bas_cont, bas_emp_sdate, 
                                 bas_emp_edate, bas_entdate, bas_resdate, bas_levdate, bas_reidate, bas_dptdate, bas_jkpdate, bas_posdate,bas_wsta, 
                                 bas_pos||':'||pos.u_nm1 as bas_pos, bas_dut||':'||dut.u_nm1 as bas_dut, bas_dept||':'||dept_name_detail as bas_dept, bas_rmk, datasys1, datasys2 as status, img.img_img as image, img.img_nam as imgnam 
                            FROM yjk_bas 
                            JOIN yjk_dept ON bas_dept=dept_code 
                            JOIN (SELECT u_cod,u_nm1 FROM yjk_unit_code WHERE u_grpcd ='POS') pos ON bas_pos=pos.u_cod 
                            LEFT JOIN (SELECT u_cod,u_nm1 FROM yjk_unit_code WHERE u_grpcd ='RNK') rnk ON bas_mil_rnk=rnk.u_cod
                            JOIN (SELECT u_cod,u_nm1 FROM yjk_unit_code WHERE u_grpcd ='DUT') dut ON bas_dut=dut.u_cod
                            LEFT JOIN (SELECT u_cod,u_nm1 FROM yjk_unit_code WHERE u_grpcd ='MIL') mil ON bas_mil_mil=mil.u_cod
                            JOIN (SELECT u_cod,u_nm1 FROM yjk_unit_code WHERE u_grpcd ='BNK') bnk ON bas_acc_bank=bnk.u_cod 
                            LEFT JOIN (SELECT img_num,img_img,img_nam FROM yjk_img ) img ON bas_empno=img.img_num 
                            where bas_empno like :bas_empno and bas_name like :bas_name and bas_pos like :bas_pos and bas_dept like :bas_dept ";

        public static string
            CreateSQL = @"SELECT bas_empno, bas_resno, bas_name, bas_cname, bas_ename, bas_fix, bas_zip, bas_addr, bas_hdpno, bas_telno, substr(bas_email,instr(bas_email,'@')+1)as bas_email, substr(bas_email,1, instr(bas_email,'@')-1)as sub_email,
                                 bas_mil_sta, bas_mil_mil||':'||mil.u_nm1 as bas_mil_mil, bas_mil_rnk||':'||rnk.u_nm1 as bas_mil_rnk, bas_mar, bas_acc_bank||':'||bnk.u_nm1 as bas_acc_bank, bas_acc_name, bas_acc_no, bas_cont, bas_emp_sdate, 
                                 bas_emp_edate, bas_entdate, bas_resdate, bas_levdate, bas_reidate, bas_dptdate, bas_jkpdate, bas_posdate,bas_wsta, 
                                 bas_pos||':'||pos.u_nm1 as bas_pos, bas_dut||':'||dut.u_nm1 as bas_dut, bas_dept||':'||dept_name_detail as bas_dept, bas_rmk, datasys1, datasys2 as status, img.img_img as image, img.img_nam as imgnam
                            FROM yjk_bas 
                            JOIN yjk_dept ON bas_dept=dept_code 
                            JOIN (SELECT u_cod,u_nm1 FROM yjk_unit_code WHERE u_grpcd ='POS') pos ON bas_pos=pos.u_cod 
                            JOIN (SELECT u_cod,u_nm1 FROM yjk_unit_code WHERE u_grpcd ='RNK') rnk ON bas_mil_rnk=rnk.u_cod
                            JOIN (SELECT u_cod,u_nm1 FROM yjk_unit_code WHERE u_grpcd ='DUT') dut ON bas_dut=dut.u_cod
                            JOIN (SELECT u_cod,u_nm1 FROM yjk_unit_code WHERE u_grpcd ='MIL') mil ON bas_mil_mil=mil.u_cod
                            JOIN (SELECT u_cod,u_nm1 FROM yjk_unit_code WHERE u_grpcd ='BNK') bnk ON bas_acc_bank=bnk.u_cod 
                            JOIN (SELECT img_num,img_img,img_nam FROM yjk_img ) img ON bas_empno=img.img_num 
                                where rownum = 0 ";

        public static string
            InsertSQL = @"insert into yjk_bas(bas_empno, bas_resno, bas_name, bas_cname, bas_ename, bas_fix, bas_zip, bas_addr, bas_hdpno, bas_telno, bas_email, 
                                              bas_mil_sta, bas_mil_mil, bas_mil_rnk, bas_mar, bas_acc_bank, bas_acc_name, bas_acc_no, bas_cont, bas_emp_sdate, 
                                              bas_emp_edate, bas_entdate, bas_resdate, bas_levdate, bas_reidate, bas_dptdate, bas_jkpdate, bas_posdate, bas_wsta, 
                                              bas_pos, bas_dut, bas_dept, bas_rmk, datasys1)
                                       values(:bas_empno, :bas_resno, :bas_name, :bas_cname, :bas_ename, :bas_fix, :bas_zip, :bas_addr, :bas_hdpno, :bas_telno, :bas_email, 
                                              :bas_mil_sta, :bas_mil_mil, :bas_mil_rnk, :bas_mar, :bas_acc_bank, :bas_acc_name, :bas_acc_no, :bas_cont, :bas_emp_sdate, 
                                              :bas_emp_edate, :bas_entdate, :bas_resdate, :bas_levdate, :bas_reidate, :bas_dptdate, :bas_jkpdate, :bas_posdate, :bas_wsta, 
                                              :bas_pos, :bas_dut, :bas_dept, :bas_rmk, :datasys1) ";

        public static string
            UpdateSQL = @"update yjk_bas set bas_resno=:bas_resno, bas_name=:bas_name, bas_cname=:bas_cname, bas_ename=:bas_ename, bas_fix=:bas_fix, bas_zip=:bas_zip, bas_addr=:bas_addr, 
                                               bas_hdpno=:bas_hdpno, bas_telno=:bas_telno, bas_email=:bas_email, bas_mil_sta=:bas_mil_sta, bas_mil_mil=:bas_mil_mil, 
                                               bas_mil_rnk=:bas_mil_rnk, bas_mar=:bas_mar, bas_acc_bank=:bas_acc_bank, bas_acc_name=:bas_acc_name, bas_acc_no=:bas_acc_no, 
                                               bas_cont=:bas_cont, bas_emp_sdate=:bas_emp_sdate, bas_emp_edate=:bas_emp_edate, bas_entdate=:bas_entdate, bas_resdate=:bas_resdate, 
                                               bas_levdate=:bas_levdate, bas_reidate=:bas_reidate, bas_dptdate=:bas_dptdate, bas_jkpdate=:bas_jkpdate, bas_posdate=:bas_posdate, 
                                               bas_wsta=:bas_wsta, bas_pos=:bas_pos, bas_dut=:bas_dut, bas_dept=:bas_dept, bas_rmk=:bas_rmk, datasys1=:datasys1
                                         where bas_empno=:bas_empno";

        public static string
            DeleteSQL = @"delete from yjk_bas where bas_empno = :bas_empno ";

        public static string
           Encry_SelectSQL = @"select user_empno, user_enresno from yjk_encryption ";

        public static string
           Encry_InsertSQL = @"insert into yjk_encryption(user_empno, user_enresno)
                                                   values(:user_empno, :user_enresno) ";

        public static string
            Encry_UpdateSQL = @"update yjk_encryption set user_enresno=:user_enresno where user_empno=:user_empno";



        public static string
           test_SelectSQL = @"select id,pwd from yjk_test ";

        public static string
            test_InsertSQL = @"insert into yjk_test(id, pwd)
                                                   values(:id, :pwd) ";
        public static string
           test_UpdateSQL = @"update yjk_test set pwd=:pwd where id=:id ";
    }
}
