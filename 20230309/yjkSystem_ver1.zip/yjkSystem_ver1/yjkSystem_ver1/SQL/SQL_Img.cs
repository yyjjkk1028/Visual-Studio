﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yjkSystem_ver1.SQL
{
    class SQL_Img
    {
        public static string
            SelectSQL = @" select img_num, img_img from yjk_img";

        public static string
            InsertSQL = @"insert into yjk_img(img_num, img_img, img_nam)
                                       values(:img_num, :img_img, :img_nam) ";

        public static string
            UpdateSQL = @"update yjk_img set img_img=:img_img, img_nam=:img_nam where img_num = :img_num ";

        public static string
            DeleteSQL = @"delete from yjk_img where img_num = :img_num ";
    }
}
