﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yjkSystem_ver1.SQL
{
    class SQL_Dept
    {
        public static string
            SelectSQL = "select dept_code, dept_name, dept_name_detail, dept_use from yjk_dept where dept_code like :dept_code and dept_name like :dept_name ";

        public static string
            Select_DPT = "select dept_code, dept_name_detail from yjk_dept where dept_name_detail like :condition ";

        public static string
            InsertSQL = @"insert into yjk_dept(dept_code, dept_name, dept_name_detail, dept_use)
                                        values(:dept_code, :dept_name, :dept_name_detail, :dept_use) ";

        public static string
            UpdateSQL = @"update yjk_dept set dept_name = :dept_name, dept_name_detail = :dept_name_detail, dept_use = :dept_use where dept_code = :dept_code";

        public static string
            DeleteSQL = @"delete from yjk_dept where dept_code = :dept_code";
    }
}
