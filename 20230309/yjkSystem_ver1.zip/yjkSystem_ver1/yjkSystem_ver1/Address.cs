﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using System.Runtime.InteropServices;
using System.Net;
using System.Xml;

namespace yjkSystem_ver1
{
    public partial class Address : Form
    {
        string currentPage = "1"; //현재 페이지
        string countPerPage = "100"; // 페이지당 출력 수
        string confmKey = "devU01TX0FVVEgyMDIzMDMwNjA5MzMwNzExMzU2NDU="; // 인증키 (유효기간 : 23.03.06 ~ 23.06.04)
        string keyword = string.Empty;
        string apiurl = string.Empty;
        private string result_zip;
        private string result_addr;
        public string GetZip
        {
            get { return result_zip; }
        }
        public string GetAddr
        {
            get { return result_addr; }
        }
        Point point = new Point();

        public Address()
        {
            InitializeComponent();
        
        }
        #region (Event)Form그림자 생성
        //**************************************************************************
        //-- (Event)Form그림자 생성
        //**************************************************************************
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }
        #endregion

        #region (Event)둥근폼 제작시 필요한
        //**************************************************************************
        //-- (Event)동근폼 제작시 필요함
        //**************************************************************************
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(int nLeftRect
                                                      , int nTopRect
                                                      , int nRightRect
                                                      , int nBottomRect
                                                      , int nWidthEllipse
                                                      , int nHeightEllipse);
        #endregion
        #region (Event)폼 움직이기
        //**************************************************************************
        //-- (Event)폼 움직이기
        //**************************************************************************
        private void title_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }

        private void title_MouseMove(object sender, MouseEventArgs e)
        {
            if ((e.Button & MouseButtons.Left) == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (point.X - e.X),
                    this.Top - (point.Y - e.Y));
            }
        }
        #endregion


        #region 주소기반산업 폼 로딩
        private void Address_Load(object sender, EventArgs e)
        {
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.Width, this.Height, 20, 20));
        }


        #endregion

        private void btn_search_Click(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;

            try
            {
                if (string.IsNullOrEmpty(searchText.Text))
                {
                    MessageBox.Show("주소를 입력해주세요.");
                    return;
                }
                keyword = searchText.Text.Trim();
                apiurl = "http://www.juso.go.kr/addrlink/addrLinkApi.do?currentPage=" + currentPage + "&countPerPage=" + countPerPage + "&keyword=" + keyword + "&confmKey=" + confmKey;

                WebClient client = new WebClient();

                XmlReader reader = new XmlTextReader(client.OpenRead(apiurl));

                DataSet dset = new DataSet();

                dset.ReadXml(reader);

                DataRow[] drow = dset.Tables[0].Select();
                if(drow[0]["totalCount"].ToString() != "0")
                {
                    dataGridView1.DataSource = dset.Tables[1];
                }
                else
                {
                    MessageBox.Show("주소를 상세히 입력해 주시기 바랍니다.");
                    searchText.Focus();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows.Count == 0) return;
            r_zip.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            r_addr1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            result_zip = r_zip.Text;
            result_addr = r_addr1.Text + " " + r_addr2.Text;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                e.Handled = true;
                btn_search_Click(null, null);
            }
        }
    }
}
