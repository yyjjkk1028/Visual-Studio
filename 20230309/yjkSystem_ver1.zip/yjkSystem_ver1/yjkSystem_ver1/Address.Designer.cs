﻿
namespace yjkSystem_ver1
{
    partial class Address
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.zipNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roadAddrPart1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_search = new System.Windows.Forms.Button();
            this.searchText = new System.Windows.Forms.TextBox();
            this.r_zip = new System.Windows.Forms.TextBox();
            this.r_addr2 = new System.Windows.Forms.TextBox();
            this.r_addr1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.zipNo,
            this.roadAddrPart1});
            this.dataGridView1.Location = new System.Drawing.Point(19, 61);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(385, 344);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // zipNo
            // 
            this.zipNo.DataPropertyName = "zipNo";
            this.zipNo.HeaderText = "우편번호";
            this.zipNo.Name = "zipNo";
            this.zipNo.ReadOnly = true;
            // 
            // roadAddrPart1
            // 
            this.roadAddrPart1.DataPropertyName = "roadAddrPart1";
            this.roadAddrPart1.HeaderText = "주소";
            this.roadAddrPart1.Name = "roadAddrPart1";
            this.roadAddrPart1.ReadOnly = true;
            this.roadAddrPart1.Width = 275;
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.White;
            this.btn_search.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btn_search.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btn_search.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btn_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search.ForeColor = System.Drawing.Color.White;
            this.btn_search.Image = global::yjkSystem_ver1.Properties.Resources.search;
            this.btn_search.Location = new System.Drawing.Point(369, 22);
            this.btn_search.Margin = new System.Windows.Forms.Padding(0);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(35, 33);
            this.btn_search.TabIndex = 16;
            this.btn_search.Tag = "Search_Btn";
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // searchText
            // 
            this.searchText.BackColor = System.Drawing.SystemColors.Control;
            this.searchText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchText.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.searchText.Location = new System.Drawing.Point(19, 22);
            this.searchText.Name = "searchText";
            this.searchText.Size = new System.Drawing.Size(347, 32);
            this.searchText.TabIndex = 17;
            this.searchText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // r_zip
            // 
            this.r_zip.BackColor = System.Drawing.Color.White;
            this.r_zip.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r_zip.Font = new System.Drawing.Font("굴림", 13F);
            this.r_zip.Location = new System.Drawing.Point(19, 412);
            this.r_zip.Name = "r_zip";
            this.r_zip.Size = new System.Drawing.Size(100, 27);
            this.r_zip.TabIndex = 18;
            // 
            // r_addr2
            // 
            this.r_addr2.BackColor = System.Drawing.Color.White;
            this.r_addr2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r_addr2.Font = new System.Drawing.Font("굴림", 13F);
            this.r_addr2.Location = new System.Drawing.Point(19, 445);
            this.r_addr2.Name = "r_addr2";
            this.r_addr2.Size = new System.Drawing.Size(385, 27);
            this.r_addr2.TabIndex = 19;
            // 
            // r_addr1
            // 
            this.r_addr1.BackColor = System.Drawing.Color.White;
            this.r_addr1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.r_addr1.Font = new System.Drawing.Font("굴림", 13F);
            this.r_addr1.Location = new System.Drawing.Point(125, 412);
            this.r_addr1.Name = "r_addr1";
            this.r_addr1.Size = new System.Drawing.Size(279, 27);
            this.r_addr1.TabIndex = 20;
            // 
            // Address
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 490);
            this.Controls.Add(this.r_addr1);
            this.Controls.Add(this.r_addr2);
            this.Controls.Add(this.r_zip);
            this.Controls.Add(this.searchText);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Address";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Address";
            this.Load += new System.EventHandler(this.Address_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.TextBox searchText;
        private System.Windows.Forms.DataGridViewTextBoxColumn zipNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn roadAddrPart1;
        private System.Windows.Forms.TextBox r_zip;
        private System.Windows.Forms.TextBox r_addr2;
        private System.Windows.Forms.TextBox r_addr1;
    }
}