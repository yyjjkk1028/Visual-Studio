﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yjkSystem_ver1
{
    public class utility
    {
        static public Button[] buttons { get; set; } //기능 버튼
        public Label Info_Count { get; set; } // 검색건수
        static public OracleConnection conn = null;
        static public OracleCommand cmd;
        static public DataSet ds = new DataSet();
        static public DataTable table = null;
        static public DataTable img_table = null;
        static public string result_zip = ""; //우편번호
        static public string result_addr = ""; //주소
        //암호화 키와 IV
        /*static public byte[] key = Encoding.ASCII.GetBytes("1234567890123456");
        static public byte[] iv = Encoding.ASCII.GetBytes("abcdefghijklmnop");*/
        public static string user_nam = "";
        public static string user_grant = "";
        #region 오라클 연결
        static public OracleConnection SetOracleConnection()
        {
            try
            {
                // string connectString = "Data Source=222.237.134.74;port=1522;Database=ora7;Uid=sys;Pwd=sys;Charset=utf8";
                string connectString = "Data Source = 222.237.134.74:1522/ora7;User Id = edu;Password=edu1234";
                conn = new OracleConnection(connectString);
                conn.Open();

                return conn;
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
                return null;
            }
        }
        #endregion
        #region 버튼상태별 설정(활성화/비활성화)
        static public string SetFuncBtn(Button[] btn, string func)
        {
            if (btn.Length == 0) return "";

            //* 0: 조회, 1:입력, 2:수정, 3:삭제, 4:저장, 5:취소, 6:인쇄
            string wk_func = "0000000";

            if (func.Equals("0")) wk_func = "1000000";   //*---조회 Only 버튼 상태            
            if (func.Equals("E")) wk_func = "0000000";   //*---Only 종료 버튼 상태
            if (func.Equals("P")) wk_func = "1000001";   //*---조회 후 인쇄/엑셀 가능 상태
            if (func.Equals("1")) wk_func = "1100000";   //*---기본 상태
            if (func.Equals("2")) wk_func = "1101001";   //*---조회 후
            if (func.Equals("3")) wk_func = "0101110";   //*---수정 및 추가 후
            if (func.Equals("4")) wk_func = "1000110";   //*---조회 후 수정 발생(추가는 없음)
            if (func.Equals("EX1")) wk_func = "0000000";   //*---엑셀 Import 前

            SetFuncBtn2(btn, wk_func);
            return wk_func;  //버튼상태를 return;
        }
        static public string SetFuncBtn2(Button[] btn, string func)
        {
            if (btn.Length == 0) return "";
            if (string.IsNullOrEmpty(func)) return "";
            if (func.Length != 7) return "";

            //아스키코드 -> 바이트
            byte[] bytes = System.Text.Encoding.ASCII.GetBytes(func);


            //버튼을 1,0으로 구분하여 Enable 처리
            for (int i = 0; i < bytes.Length; i++)
            {
                /*if(bytes[i] == '1') { btn[i].Enabled = true; } else { btn[i].Enabled = false; }*/
                btn[i].Enabled = bytes[i] == '1' ? true : false;
            }
            return func;
        }
        #endregion
        #region 조회된 DataGridView 선택된 값 = Control.Text
        static public void SetGridViewValue(DataGridView grid, Control ctl)
        {
            DataGridViewRow row = grid.CurrentRow;
            if (row == null) return;

            string col_name = ctl.Name.Substring(2);
            //MessageBox.Show("현재 컨트롤러: "+ctl+" 불러올 이름: "+col_name);

            Type type = ctl.GetType(); //ctl 타입
            PropertyInfo pi = null; //ctl 속성
            if (ctl is CheckBox)
            {
                pi = type.GetProperty("Checked");
                if (pi != null)
                {
                    row.Cells[col_name].Value = pi.GetValue(ctl);
                    //MessageBox.Show("pi의 값: "+pi.ToString() + "그리드뷰에 불러올 값: " +pi.GetValue(ctl));
                }
                return;
            }
            pi = type.GetProperty("Text");
            if (pi != null)
            {
                row.Cells[col_name].Value = pi.GetValue(ctl);
                return;
            }
        }
        #endregion
        #region Control.Text = 조회된 DataGridView 선택된 값
        static public void SetControlValue(DataGridView grid, Control control)
        {
            if (grid.SelectedRows.Count == 0) return;

            Type type;
            PropertyInfo pi = null;
            Control ctl;
            for (int col = 0; col < grid.ColumnCount; col++)
            {
                ctl = GetControlByName(control, grid.Columns[col].Name);
                if (ctl == null) continue;

                type = ctl.GetType();
                if (ctl is CheckBox)
                {
                    pi = type.GetProperty("Checked");
                    if (pi != null)
                    {
                        pi.SetValue(ctl, ChangedBoolType(grid.SelectedRows[0].Cells[col].Value?.ToString()));
                        //MessageBox.Show(ctl.Name + "   " + grid.SelectedRows[0].Cells[col].Value?.ToString());
                    }
                    continue;
                }
                pi = type.GetProperty("Text");
                if (pi != null)
                {
                    pi.SetValue(ctl, grid.SelectedRows[0].Cells[col].Value?.ToString());
                }
            }
        }
        // Control.Name = DataGridView.Columns[].Name 
        static private Control GetControlByName(Control control, string name)
        {
            string ctl_name = "s_" + name;
            //MessageBox.Show(ctl_name);
            Control[] ctl = control.Controls.Find(ctl_name, true);
            return ctl.Length == 0 ? null : ctl[0];
        }
        #endregion
        #region Bool 형식 변경 Bool <-> ('1','0' / 'Y','N')
        static public bool ChangedBoolType(string text)
        {
            if (string.IsNullOrEmpty(text)) return false;
            if (text == "0") return false;
            if (text == "N") return false;
            return true;
        }
        static public string ChangedBoolType(object obj, string type)
        {
            if (type == "chkbox")
            {
                if (string.IsNullOrEmpty(obj?.ToString())) return "N";
                if ((bool)obj) return "Y";
                else return "N";
            }
            return "";
        }
        // True Or False 값을 Y Or False로 변경
        static public string ChangedBoolType_CheckBox(string obj)
        {
            string check = "";
            if (string.IsNullOrEmpty(obj?.ToString())) check = "N";
            if (obj == "False" || obj == "N") check = "N";
            if (obj == "True" || obj == "Y") check = "Y";
            return check;
        }
        #endregion
        #region Panel안의 컨트롤 초기화
        static public void Panel_Clear(Panel panel)
        {
            foreach (Control ctl in panel.Controls)
            {
                if (ctl is CheckBox)
                {
                    CheckBox chkbox = (CheckBox)ctl;
                    chkbox.Checked = false;
                }
                if (ctl is TextBox)
                {
                    TextBox textbox = (TextBox)ctl;
                    textbox.Text = "";
                }
                if (ctl is ComboBox)
                {
                    ComboBox combo = (ComboBox)ctl;
                    combo.SelectedIndex = 0;
                }
                if (ctl is MaskedTextBox)
                {
                    MaskedTextBox mtb = (MaskedTextBox)ctl;
                    mtb.Clear();
                }
                if (ctl is PictureBox)
                {
                    PictureBox ptb = (PictureBox)ctl;
                    ptb.Image = null;
                }
            }
        }
        #endregion
        #region ComBox Item에 각 그룹별 코드값 추가
        static public void ComBoxItemSet(ComboBox cb, string sql)
        {
            try
            {

                conn = SetOracleConnection();
                cmd = conn.CreateCommand();
                cmd.CommandText = sql;
                cmd.BindByName = true;
                OracleDataReader reader = cmd.ExecuteReader();
                cb.Items.Clear();
                cb.Items.Add("");
                while (reader.Read())
                {
                    cb.Items.Add(reader.GetString(0));
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            finally
            {
                if (conn != null) conn.Close();
            }
        }
        #endregion
        #region :기준으로 코드값만 Split 처리 (앞부분 코드만 들고오기)
        static public string GetCode(string code)
        {
            if (string.IsNullOrEmpty(code)) return "";
            string[] sp_code = code.Split(':');
            if (sp_code.Length == 0) return "";
            return sp_code[0];
        }
        #endregion
        #region 입력값 중 오류가 있는지 여부 확인
        static public Boolean InputErrorChk(DataGridView grid)
        {
            foreach (DataGridViewRow row in grid.Rows)
            {
                if (string.IsNullOrEmpty(row.ErrorText) == false)
                {
                    MessageBox.Show("입력한 자료 중 오류가 있습니다.", "오류확인", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }
            }
            return true;
        }
        #endregion
        #region 이메일 형식인지 확인
        static public bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }
        #endregion
        #region MaskedTextBox 관련 함수
        //***************************************
        //주민등록번호 빈 값인지 확인
        //***************************************
        static public bool Get_Resno_IsEmpty(string res)
        {
            // 비어있거나 replace시킨 값이 - 이면 true
            if (string.IsNullOrEmpty(res)) return true;
            if (res.Replace(" ", "").Equals("-")) return true;
            return false;
        }
        //***************************************
        //날짜형식의 MaskedTextBox 빈 값인지 확인
        //***************************************
        static public bool Get_Date_IsEmpty(string date)
        {
            // 비어있거나 replace시킨 값이 -- 이면 true
            if (string.IsNullOrEmpty(date)) return true;
            if (date.Replace(" ", "").Equals("--")) return true;
            return false;
        }
        //***************************************
        //MaskedTextBox '-' 제거 Replace
        //***************************************
        static public string Get_Date_Replace(string date)
        {
            // 비어있거나 replace시킨 값이 -- 이면 true
            if (string.IsNullOrEmpty(date)) return "";
            if (date.Replace(" ", "").Equals("-")) return "";
            if (date.Replace(" ", "").Equals("()-")) return "";
            if (date.Replace(" ", "").Equals("--")) return "";
            string rpdate = date.Replace("-", "");
            return rpdate;
        }
        //***************************************
        //MaskedTextBox 커서 맨앞으로 이동
        //***************************************
        static public void SetMaskedTextBox_Cursor(MaskedTextBox mtxt)
        {
            int index = Get_Date_Replace(mtxt.Text).Length;
            if (index == 0)
            {
                mtxt.SelectionStart = 0;
                mtxt.SelectionLength = 0;
            }
        }
        //***************************************
        //날짜형식 유효성 Check (yyyy-MM-dd)
        //***************************************
        static public bool Check_Date_YYYYMMDD(String date)
        {
            if (String.IsNullOrEmpty(date)) return true;
            if (date.Replace(" ", "").Equals("--")) return true;

            try
            {
                DateTime.ParseExact(date, "yyyy-MM-dd", null);
            }
            catch
            {
                return false;
            }

            return true;
        }
        #endregion

        #region 암호화 / 복호화 (ProtectedData)
        public static string Protect(string origin) //암호화
        {
            /*
            CurrentUser - 보호된 데이터가 현재 사용자에 연결되어 있음. 현재 사용자 컨텍스트에서 실행되는 스레드에서만 데이터를 보호 해제 가능.
            LocalMachine - 보호된 데이터가 컴퓨터 컨텍스트에 연결되어 있음. 컴퓨터에서 실행되는 모든 프로세스에서 데이터를 보호 해제 가능.
                           일반적으로 이 열거형 값은 신뢰되지 않는 사용자의 액세스가 허용되지 않는 서버에서 실행되는 서버 관련 애플리케이션에 사용.
            */
            var ResnoProtect = Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(origin), null, DataProtectionScope.LocalMachine));
            return ResnoProtect;
        }
        public static string UnProtect(string origin) //복호화
        {
            var ResnoUnProtect = Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(origin), null, DataProtectionScope.LocalMachine));
            return ResnoUnProtect;
        }
        #endregion
    }
}
