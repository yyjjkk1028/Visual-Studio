﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yjkSystem_ver1
{
    public partial class Launcher : Form
    {
        public string LoadingFormName;  // Loading 프로그램 Form Name
        public string LoadingPgmId;     // Loading 프로그램 Id
        public string LoadingPgmName;   // Loading 프로그램 이름
        public string UserId;           // 사용자 ID
        public Launcher()
        {
            InitializeComponent();
        }

        private void Launcher_Load(object sender, EventArgs e)
        {
            // 버튼 불러오기
            BtnControl bc = new BtnControl() { TopLevel = false, TopMost = true };
            btn_panel.Controls.Add(bc);
            bc.Show();
            bc.form_launcher = this.panel1;

            Type formType = Assembly.GetExecutingAssembly().GetTypes()
               .Where(a => a.BaseType == typeof(Form) && a.Name == LoadingFormName)
               .FirstOrDefault();
            if (formType == null)
            {
                return;
            }

            Form form = (Form)Activator.CreateInstance(formType);  // 동적생성(폼)
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            panel1.Controls.Add(form);
            form.Dock = DockStyle.Fill;
            form.Show();


        }
    }
}
