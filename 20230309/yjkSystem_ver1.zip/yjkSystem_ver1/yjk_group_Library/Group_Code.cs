﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yjk_group_Library
{
    public partial class Group_Code : UserControl
    {
        public Group_Code()
        {
            InitializeComponent();
        }

        private void Group_Code_Load(object sender, EventArgs e)
        {
            yjkSystem_ver1.utility.SetFuncBtn(yjkSystem_ver1.utility.buttons, "1");
        }
        public void Search_Btn()
        {
            try
            {
                string sql = "select dept_code, dept_name_detail from yjk_dept ";

                yjkSystem_ver1.utility.conn = yjkSystem_ver1.utility.SetOracleConnection();
                yjkSystem_ver1.utility.cmd = yjkSystem_ver1.utility.conn.CreateCommand();
                yjkSystem_ver1.utility.cmd.CommandText = sql;

                OracleDataAdapter da = new OracleDataAdapter(yjkSystem_ver1.utility.cmd);
                DataSet ds = new DataSet();
                da.Fill(ds, "TAB");
                dataGridView1.DataSource = ds.Tables["TAB"].DefaultView;
                MessageBox.Show("조회되었습니다.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (yjkSystem_ver1.utility.conn != null) yjkSystem_ver1.utility.conn.Close();
            }
        }
    }
}
